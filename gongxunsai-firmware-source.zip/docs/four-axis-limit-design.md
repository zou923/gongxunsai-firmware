# Four-axis limit switch design

## Intent

Extend the proven X-axis PB13 limit behavior to X, Y, Z, and S. Grounding a
limit input stops only its corresponding X42S motor, then queries and stores
that motor's actual position without changing the software ZERO origin.

## Confirmed mapping

| Axis | Motor address | Connector | IO MCU pin | IO status bit |
|---|---:|---|---|---:|
| X | 1 | CN6 | PB13 | 5 |
| Y | 2 | CN7 | PB14 | 6 |
| Z | 3 | CN3 | PA1 | 2 |
| S/camera | 4 | CN4 | PB1 | 3 |

CN5/PB12 (bit 4) remains spare and disabled.

## Behavior

- Every assigned input uses the board pull-up and is active when grounded.
- A newly asserted switch sends an immediate stop only to its mapped motor.
- After a short settling interval, MASTER sends `address 36 6B` and uses the
  valid reply to correct only that axis's software coordinate.
- The saved ZERO origin is never overwritten by a limit event.
- A timeout or malformed/wrong-address reply reports an error and never
  fabricates a coordinate.
- Limit handling has priority over ordinary movement commands. Simultaneous
  assertions are queued and processed one axis at a time on the shared UART.
- Existing temporary software-ZERO mode remains available while motors 1 and 2
  are disconnected.

## Approaches

1. Stop only: simplest, but software position drifts after an interrupted move.
2. Stop plus actual-position query: selected because it matches the proven X
   behavior and keeps HOME/XYZS coordinates consistent.

## Verification

Host tests cover pin-to-axis mapping, one-axis-only stop, queued simultaneous
limits, reply address validation, timeout, and preservation of ZERO origins.
Both MASTER and IO firmware must compile. Hardware validation grounds each
connector separately during motion and checks that only the mapped motor stops.
