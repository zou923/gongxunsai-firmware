# ESP32 摄像头工程设计

## 意图

在当前工作区中新建名为 `ESP32摄像头` 的独立 ESP-IDF 工程，供 ESP32-S3 摄像头程序后续开发使用。

## 范围

- 使用本机已有的 ESP-IDF 6.0 和 ESP32-S3 Xtensa 工具链。
- 创建最小、可编译的 ESP-IDF 工程骨架。
- 初始程序只输出启动日志，不预设具体摄像头型号或引脚。
- 目标芯片固定为 `esp32s3`。

## 方案

- 采用 ESP-IDF 原生 CMake 工程：与已安装工具链直接匹配，后续可引入 `esp32-camera` 组件。
- 不采用 Arduino 或 PlatformIO：本机当前未发现对应 CLI，且用户已确认使用现有 ESP32-S3 环境继续。

## 验收

- 工程目录和必要的 CMake、源文件存在。
- `idf.py set-target esp32s3` 成功。
- `idf.py build` 成功生成 ESP32-S3 固件。
