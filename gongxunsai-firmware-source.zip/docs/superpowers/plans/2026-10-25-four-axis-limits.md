# Four-axis Limits Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Extend the existing X limit behavior to confirmed X/Y/Z/S connector mappings.

**Architecture:** Enable the four IO input bits, add a host-tested mapping/queue module, and serialize per-axis stop and position-query transactions in MASTER. Preserve software ZERO origins.

**Tech Stack:** C11, STM32F103 CMSIS/HAL, SPI IO status, X42S UART.

**Spec:** `docs/four-axis-limit-design.md`

## Global Constraints

- X=PB13/address1, Y=PB14/address2, Z=PA1/address3, S=PB1/address4.
- Inputs are active-low and CN5/PB12 remains disabled.
- Stop only the mapped motor and never overwrite ZERO origin.

## Review Focus

- Simultaneous assertions must remain queued.
- Held switches must not retrigger continuously.
- Wrong-address replies must not update coordinates.
- UART timeout must release the queue without inventing position.

### Task 1: IO configuration and limit routing

**Files:** `Config/board_config.h`, `Master/Inc/four_axis_limits.h`, `Master/Src/four_axis_limits.c`, `tests/test_four_axis_limits.c`, `scripts/test.ps1`

- [ ] Add failing mapping, edge and queue tests.
- [ ] Implement active-low masks and deterministic X/Y/Z/S routing.
- [ ] Run host tests.

### Task 2: MASTER stop/query integration

**Files:** `Master/Src/main_master.c`, `CMakeLists.txt`, `README.md`

- [ ] Replace the X-only edge handler with queued four-axis handling.
- [ ] Stop the mapped motor, query its address after 50 ms, update only that axis when an origin is valid.
- [ ] Run all host tests and cross-build both firmware images.
