# Four-Axis Commissioning Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add synchronized `XYZS` absolute motion, `R3/R4` rotation tests, four-axis stopping, and atomic four-axis `ZERO` position capture on the existing X42S UART bus.

**Architecture:** Keep wire framing in `x42s_protocol`, add focused four-axis command and motion-state modules, and let `main_master` orchestrate non-blocking UART transactions. Existing XY and PB13 X-limit behavior remain available and use the same shared bus arbiter.

**Tech Stack:** C11, STM32F103 HAL/CMSIS, X42S Emm fixed-0x6B UART protocol, host tests built by `scripts/test.ps1`, CMake ARM cross-build.

**Spec:** `docs/four-axis-commissioning-design.md`

## Global Constraints

- Motor IDs are 1=X, 2=Y, 3=Z, 4=S/camera and must be unique.
- All axes use 12800 command counts/revolution and provisional 40000 um/revolution.
- `XYZS` coordinates are absolute and limited to 0..500000 um per axis.
- Z and S calibration is provisional; do not present it as installed-machine calibration.
- Preserve PB13 active-low X-limit stop and actual-position capture.
- No blocking delays in the main loop.

## Review Focus

- Partial UART transmission must not commit any software target; pin this in Task 3 tests.
- A malformed or wrong-address ZERO reply must leave all four prior origins unchanged; pin this in Task 4 tests.
- Zero-distance axes in `XYZS` must not divide by zero; pin this in Task 2 tests.
- `STOPALL` must address all four motors even when a prior transaction timed out; pin this in Task 3 tests.
- Commands arriving during ZERO or limit-position capture must return BUSY without corrupting the active transaction; pin this in Task 5 tests.

---

### Task 1: Four-Axis Command Parser

**Files:**
- Create: `Master/Inc/four_axis_command.h`
- Create: `Master/Src/four_axis_command.c`
- Create: `tests/test_four_axis_command.c`
- Modify: `scripts/test.ps1`

**Interfaces:**
- Produces `four_axis_command_parse(const char *, four_axis_command_t *)` for `XYZS`, `R3`, `R4`, `STOP3`, `STOP4`, and `STOPALL`.

- [ ] Write failing parser tests for valid integers/three-decimal values, missing/extra fields, negative XYZS, values above 500, zero rotations, rotations outside +/-5, and trailing garbage.
- [ ] Run `scripts/test.ps1`; expect the new test to fail to compile because the parser is absent.
- [ ] Implement the parser without heap allocation or floating point.
- [ ] Run `scripts/test.ps1`; expect all parser and existing tests to pass.

### Task 2: Four-Axis Motion Planning

**Files:**
- Create: `Master/Inc/four_axis_motion.h`
- Create: `Master/Src/four_axis_motion.c`
- Create: `tests/test_four_axis_motion.c`
- Modify: `scripts/test.ps1`
- Modify: `Config/board_config.h`

**Interfaces:**
- Consumes parsed absolute coordinates from Task 1.
- Produces `four_axis_plan_absolute(...)`, `four_axis_commit(...)`, and four-axis origin/position state.

- [ ] Write failing tests for 12800 counts/rev, 40000 um/rev, 0..500000 um limits, independent directions, proportional RPM, zero-distance axes, and no commit before success.
- [ ] Run host tests and confirm failure for missing planner.
- [ ] Implement integer-only four-axis planning with maximum 60 RPM and acceleration 10.
- [ ] Run host tests and confirm all pass.

### Task 3: Four-Motor Protocol Frames

**Files:**
- Modify: `Master/Inc/x42s_protocol.h`
- Modify: `Master/Src/x42s_protocol.c`
- Modify: `tests/test_x42s_protocol.c`

**Interfaces:**
- Produces `x42s_build_four_position(...)` and `x42s_build_stop_many(first_id, count, ...)` frames for the shared UART bus.

- [ ] Add failing byte-vector tests for four cached Emm position commands followed by one broadcast sync trigger, plus STOP3, STOP4 and STOPALL.
- [ ] Test buffer-too-small, duplicate/zero address, and construction failure without partial logical success.
- [ ] Implement the minimal frame builders using existing single-motor builders.
- [ ] Run `scripts/test.ps1`; expect all protocol vectors to pass.

### Task 4: Atomic Four-Axis ZERO Transaction

**Files:**
- Create: `Master/Inc/four_axis_zero.h`
- Create: `Master/Src/four_axis_zero.c`
- Create: `tests/test_four_axis_zero.c`
- Modify: `scripts/test.ps1`

**Interfaces:**
- Produces a non-blocking state machine that requests addresses 1 through 4 and publishes the origin array only after four valid `0x36` replies.

- [ ] Write failing tests for ordered success, timeout, wrong address, malformed reply, retry/reset, and preservation of the previous complete origin set on failure.
- [ ] Run host tests and confirm failure for missing state machine.
- [ ] Implement request/reply/timeout transitions without accessing hardware directly.
- [ ] Run host tests and confirm all pass.

### Task 5: MASTER Integration and Bus Arbitration

**Files:**
- Modify: `Master/Src/main_master.c`
- Modify: `CMakeLists.txt`
- Modify: `README.md`

**Interfaces:**
- Consumes Tasks 1-4 and existing debug UART, motor UART, XY planner, and PB13 limit state.
- Produces user-visible command responses and serialized access to the motor UART.

- [ ] Add a host-testable transaction-priority test proving PB13 limit capture > STOP commands > ZERO > ordinary movement, and BUSY rejection during active queries.
- [ ] Integrate `XYZS`, `R3/R4`, `STOP3/4/ALL`, and atomic `ZERO`; retain existing `XY`, `HOME`, and X-limit behavior.
- [ ] Update help/test instructions and clearly label Z/S values provisional.
- [ ] Run `scripts/test.ps1`; expect all host tests to pass.
- [ ] Run `scripts/build.ps1`; expect `sorter-master.elf` and `sorter-io.elf` to link within STM32F103C8 limits.
- [ ] Hardware sequence after flashing MASTER: `R3 0.25`, `STOP3`, `R4 0.25`, `STOP4`, `ZERO`, then `XYZS 10 10 10 10`.

