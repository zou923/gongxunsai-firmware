# X42S protocol and current motion behavior

This note describes the firmware in the repository. The local X42S manual and PCB netlist used during development are not redistributed here; see the source file names and SHA-256 fingerprint below to identify matching documents if you have them.

## Current firmware behavior

The master sends X42S packets from `Master/Src/main_master.c` through USART3. The separate `x42s_driver` API is initialized in `X42S_MODE_HARDWARE_LOCKED`, but the manual command path builds packets with `x42s_protocol` and writes them directly to the motor UART. Therefore the locked simulation API does **not** prevent the manual axis commands described in the README from transmitting.

Current motor-address convention is 1=X, 2=Y, 3=Z, 4=S. The implementation uses the fixed `0x6B` checksum format and position packet builders. Confirm each physical driver's firmware family, address, baud, checksum, response mode, and wiring before relying on that mapping; successful packet transmission alone does not prove that a motor accepted or completed a move.

`ZERO` records software coordinates. `HOME` sends a move to the saved software origin; it does not physically home every axis. A CN3/PA1 Z-limit edge sends a stop packet to motor 3 and assigns software Z=0 at the stopped location. XY limits in the motion planner are X=222 mm and Y=208 mm. Z/S use 0–500 mm software bounds. These are software guards, not physical safety devices.

`P0500` through `P1100` are forwarded to the IO board. `SERVO FORWARD QUEUED` reports queue/forwarding acceptance only; the current protocol does not confirm that the servo physically reached the requested position.

## Protocol details and limitations

The packet encoder follows the fixed `0x6B` checksum examples in the ZDT_X42S user manual revision V1.0.5 (2026-05-27). It includes position query, motor status query, immediate stop, homing packet, and X/Emm position modes. XOR, CRC8, and Modbus-RTU modes are not implemented. The physical drive variant and parameter settings have not been read back by this source package.

The motion model currently assumes 12800 command counts/revolution, 40 mm/revolution, and 60 RPM maximum. Those values require confirmation against the installed microstep setting and mechanics. X/Y motor direction inversion and the current travel limits reflect the present machine setup; recheck them after mechanical changes.

## Design-document references

- User manual referenced during development: `ZDT_X42S_User_Manual_V1.0.5_260527.pdf`; SHA and page notes from the original audit can be retained by the project maintainer outside this source archive.
- PCB netlist referenced during development: `Netlist_PCB1_2026-10-18.tel`; it confirmed U1 PB10/USART3_TX to CN2.7 and PB11/USART3_RX to CN2.8, but cannot establish the external driver's wiring or configuration.

The firmware has host-side protocol tests. They validate encoded bytes and parser behavior, not electrical signal quality, actual motor motion, switch repeatability, or emergency-stop performance.
