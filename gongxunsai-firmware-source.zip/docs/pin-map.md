# 引脚表（PCB 设计参考快照，2026-10-18）

审计日期：2026-10-18。连接源：`Netlist_PCB1_2026-10-18.tel（外部 PCB 设计资料，本仓库未包含）`。

SHA-256：`735A4BCF91104773FCA8214910C2339A2C1953F5EEC4332CD6A7456579791404`。

MCU 脚号/名称与型号来自旧工程 `ProPrj_工训赛_2026-10-11.epro` 的 `SYMBOL/853bb66d6004ea80.esym` 与 U1/U3 器件属性；两者设计型号均为 STM32F103C8T6。连接来自最新网表，不能据此认定实板已焊通或外设已接好。以下“未列”表示该端点没有出现在最新网表，不代表已经实测开路。

## 双 MCU 全部 48 脚

| 物理脚号 | MCU 引脚名称 | U1 / MASTER 网名 | U3 / IO 网名 |
| --- | --- | --- | --- |
| 1 | VBAT | `VCC3V3` | `VCC3V3` |
| 2 | PC13-TAMPER-RTC | `MPC13-TAMPER-RTC` | `SPC13-TAMPER-RTC` |
| 3 | PC14-OSC32_IN | `MPC14-OSC32_IN` | `SPC14-OSC32_IN` |
| 4 | PC15-OSC32_OUT | `MPC15-OSC32_OUT` | `SPC15-OSC32_OUT` |
| 5 | PD0-OSC_IN | `MPD0-OSC_IN` | `SPD0-OSC_IN` |
| 6 | PD1-OSC_OUT | `MPD1-OSC_OUT` | `SPD1-OSC_OUT` |
| 7 | NRST | `MNRST` | `SNRST` |
| 8 | VSSA | `GND` | `GND` |
| 9 | VDDA | `VCC3V3` | `VCC3V3` |
| 10 | PA0-WKUP | `MPA0_VBAT_ADC` | `SPA0-WKUP` |
| 11 | PA1 | `MPA1` | `SPA1_NC` |
| 12 | PA2 | `MPA2_TX` | `SPA2_TX` |
| 13 | PA3 | `MPA3_RX` | `SPA3_RX` |
| 14 | PA4 | `CS` | `CS` |
| 15 | PA5 | `MPA5` | `MPA5` |
| 16 | PA6 | `MPA6` | `MPA6` |
| 17 | PA7 | `MPA7` | `MPA7` |
| 18 | PB0 | `IO_IRQ` | `SPB0_START` |
| 19 | PB1 | `MPB1` | `SPB1_NC` |
| 20 | PB2 | `MPB2` | `SPB2` |
| 21 | PB10 | `MPB10_TX` | `SPB10_TX` |
| 22 | PB11 | `MPB11_RX` | `SPB11_RX` |
| 23 | VSS_1 | `GND` | `GND` |
| 24 | VDD_1 | `VCC3V3` | `VCC3V3` |
| 25 | PB12 | `MPB12` | `SPB12_NC` |
| 26 | PB13 | `MPB13` | `SPB13_NC` |
| 27 | PB14 | `MPB14` | `SPB14_NC` |
| 28 | PB15 | `MPB15` | `SPB15_STOP` |
| 29 | PA8 | `MPA8` | `$1N295` |
| 30 | PA9 | `MPA9_TX` | `SPA9_TX` |
| 31 | PA10 | `MPA10_RX` | `SPA10_RX` |
| 32 | PA11 | `MPA11` | `SPA11` |
| 33 | PA12 | `MPA12` | `SPA12` |
| 34 | PA13 | `MPA13` | `SPA13` |
| 35 | VSS_2 | `GND` | `GND` |
| 36 | VDD_2 | `VCC3V3` | `VCC3V3` |
| 37 | PA14 | `MPA14` | `SPA14` |
| 38 | PA15 | `MPA15` | `SPA15` |
| 39 | PB3 | `MPB3` | `SPB3` |
| 40 | PB4 | `MPB4` | `SPB4` |
| 41 | PB5 | `MPB5` | `IO_IRQ` |
| 42 | PB6 | `MPB6` | `SPB6` |
| 43 | PB7 | `MPB7` | `SPB7` |
| 44 | BOOT0 | `MBOOT0` | `SBOOT0` |
| 45 | PB8 | `MPB8` | `SPB8` |
| 46 | PB9 | `MPB9` | `SPB9` |
| 47 | VSS_3 | `GND` | `GND` |
| 48 | VDD_3 | `VCC3V3` | `VCC3V3` |

## 早期阶段 2 功能约定（历史记录）

| 功能 | MASTER | IO | 约束 |
| --- | --- | --- | --- |
| SPI1 NSS/CS | PA4 输出 | PA4 硬件 NSS 输入 | 原始网络名 CS；片选高时 IO 不应驱动 MISO |
| SPI1 SCK | PA5 输出 | PA5 输入 | 网络名 MPA5 |
| SPI1 MISO | PA6 输入 | PA6 复用输出 | 网络名 MPA6；IO 启用/复位时序与 NSS/DMA 由固件验证 |
| SPI1 MOSI | PA7 输出 | PA7 输入 | 网络名 MPA7 |
| IO_IRQ | PB0 输入 | PB5 开漏输出的固件当前约定 | 外部 R29=10K 上拉；网表证明互连，不证明通知极性 |
| 视觉 USART1 | PA9 TX / PA10 RX | 不分配 | CN1 历史标注摄像头串口；外部设备配置未验证 |
| 调试 USART2 | PA2 TX / PA3 RX，H3 | PA2 TX / PA3 RX，H6 | 两个接口均在旧工程调试串口框；固件当前配置 115200 8N1 |
| 电机 USART3 | PB10 TX / PB11 RX，CN2 | 不分配 | 当前固件用作 X42S USART3；参见 README 与 x42s-protocol-status.md |
| START 原始输入 | 不分配 | PB0，低电平表示 SW5 对地闭合 | 不触发自动运动 |
| STOP 原始输入 | 不分配 | PB15，CN8 | 外接 NO/NC 及停止有效语义待确认 |
| 未映射输入 | 不分配 | PA1、PB1、PB12、PB13、PB14 | 网名均带 NC；不得改称已确认 Z_HOME 或 X/Y 正负限位 |
| 状态 LED | PC13，低亮 | PC13，低亮 | LED2/LED4 的 A 接3V3，K 经510Ω到GPIO |
| 故障 LED | 不分配 | PB8，低亮 | 3V3 经R30=1K→LED5 A；LED5 C/K接PB8 |
| GRIP_PWM | 不分配 | PA8 经 R27=220Ω 到 H1.3 | R26=10K 对地下拉；当前 IO 固件提供舵机脉宽转发；实机安全范围需验证 |
| ADC 电压采样候选 | PA0 | 不分配 | R24=100K/R25=27K，未实测标定 |
| SWD | PA13/PA14 → H2 | PA13/PA14 → H4 | 调试保留；不用作普通输出 |

各通信引脚外设名是固件功能分配；网表记录的是电连接。GPIO 复用配置、时钟、实际通信能力应由固件和后续实测另行验证。

## P1~P4 排针逐脚

| 针号 | P1 / IO | P2 / IO | P3 / MASTER | P4 / MASTER |
| --- | --- | --- | --- | --- |
| 1 | `VCC3V3` | `VCC3V3` | `VCC3V3` | `VCC3V3` |
| 2 | `SPC13-TAMPER-RTC` | `GND` | `MPC13-TAMPER-RTC` | `GND` |
| 3 | `SPC14-OSC32_IN` | `5V_OUT` | `MPC14-OSC32_IN` | `5V_OUT` |
| 4 | `SPC15-OSC32_OUT` | `SPB9` | `MPC15-OSC32_OUT` | `MPB9` |
| 5 | `SPA0-WKUP` | `SPB8` | `MPA0_VBAT_ADC` | `MPB8` |
| 6 | `SPA1_NC` | `SPB7` | `MPA1` | `MPB7` |
| 7 | `SPA2_TX` | `SPB6` | `MPA2_TX` | `MPB6` |
| 8 | `SPA3_RX` | `IO_IRQ` | `MPA3_RX` | `MPB5` |
| 9 | `CS` | `SPB4` | `未列` | `MPB4` |
| 10 | `MPA5` | `SPB3` | `未列` | `MPB3` |
| 11 | `MPA6` | `SPA15` | `未列` | `MPA15` |
| 12 | `MPA7` | `SPA12` | `未列` | `MPA12` |
| 13 | `SPB0_START` | `SPA11` | `IO_IRQ` | `MPA11` |
| 14 | `SPB1_NC` | `SPA10_RX` | `MPB1` | `MPA10_RX` |
| 15 | `SPB10_TX` | `SPA9_TX` | `MPB10_TX` | `MPA9_TX` |
| 16 | `SPB11_RX` | `SPA8_GRIP_PWM` | `MPB11_RX` | `MPA8` |
| 17 | `SNRST` | `SPB15_STOP` | `MNRST` | `MPB15` |
| 18 | `VCC3V3` | `SPB14_NC` | `VCC3V3` | `MPB14` |
| 19 | `GND` | `SPB13_NC` | `GND` | `MPB13` |
| 20 | `GND` | `SPB12_NC` | `GND` | `MPB12` |

P3.9/.10/.11/.12 在旧 10-10 原理图网表中分别连接 CS/MPA5/MPA6/MPA7，在最新 PCB 网表中均未列；不能按旧图承诺这些测试点可用。

## 外接和调试接口逐脚

| 接口 | 针号 → 最新网名 | 说明 |
| --- | --- | --- |
| CN1 | 1=`GND`；2=`MPA10_RX`；3=`MPA9_TX` | 旧图摄像头串口 |
| CN2 | 1=`12V_OUT`；2=`GND`；3=`未列`；4=`MPB1`；5=`未列`；6=`未列`；7=`MPB10_TX`；8=`MPB11_RX` | 步进接口区域；3/5/6脚无当前连接证据；4脚PB1用途未定 |
| CN3 | 1=`GND`；2=`SPA1_NC` | PA1/CN3 当前配置为 Z 向上参考开关；实机极性与重复性需验证 |
| CN4 | 1=`GND`；2=`SPB1_NC` | PB1未映射输入 |
| CN5 | 1=`GND`；2=`SPB12_NC` | PB12未映射输入 |
| CN6 | 1=`GND`；2=`SPB13_NC` | PB13未映射输入 |
| CN7 | 1=`GND`；2=`SPB14_NC` | PB14未映射输入 |
| CN8 | 1=`GND`；2=`SPB15_STOP` | STOP接口，NO/NC待确认 |
| H1 | 1=`GND`；2=`$1N426`；3=`SPA8_GRIP_PWM` | 舵机接口；2脚独立电源网，非5V_OUT |
| H2 | 1=`MNRST`；2=`GND`；3=`MPA14`；4=`MPA13`；5=`VCC3V3` | MASTER：1 NRST / 2 GND / 3 SWCLK / 4 SWDIO / 5 3V3 |
| H3 | 1=`MPA2_TX`；2=`MPA3_RX` | MASTER 调试串口；接口自身不带GND |
| H4 | 1=`SNRST`；2=`GND`；3=`SPA14`；4=`SPA13`；5=`VCC3V3` | IO：1 NRST / 2 GND / 3 SWCLK / 4 SWDIO / 5 3V3 |
| H5 | 1=`5V_OUT`；2=`5V_OUT`；3=`5V_OUT`；4=`5V_OUT`；5=`5V_OUT`；6=`5V_OUT` | 5V_OUT 测试/引出 |
| H6 | 1=`SPA2_TX`；2=`SPA3_RX` | IO 调试串口；接口自身不带GND |
| H7 | 1=`VCC3V3`；2=`VCC3V3`；3=`VCC3V3`；4=`VCC3V3`；5=`VCC3V3`；6=`VCC3V3` | 3V3 测试/引出 |
| H8 | 1=`GND`；2=`GND`；3=`GND`；4=`GND`；5=`GND`；6=`GND` | GND 测试/引出 |
| H9 | 1=`SPA9_TX`；2=`SPA10_RX` | IO USART1 备用 |
| H10 | 1=`SPB10_TX`；2=`SPB11_RX` | IO USART3 备用 |
| J1 | 1=`VCC3V3`；2=`VCC3V3`；3=`$1N135`；4=`$1N134`；5=`GND`；6=`GND` | MASTER 启动模式跳线；必须结合R2/R3/R14解释 |
| J2 | 1=`VCC3V3`；2=`VCC3V3`；3=`$1N273`；4=`$1N272`；5=`GND`；6=`GND` | IO 启动模式跳线；必须结合R12/R13/R22解释 |
| U4 | 1=`12V_IN`；2=`GND` | 12V 输入端 |
| U6 | 1=`12V_OUT`；2=`GND` | 12V_OUT 输出端 |
| U7 | 1=`GND`；2=`VCC3V3`；3=`MPB6`；4=`MPB7` | MASTER OLED接口的历史设计意图；PB6/PB7 |
| U8 | 1=`GND`；2=`VCC3V3`；3=`SPB6`；4=`SPB7` | IO OLED接口的历史设计意图；PB6/PB7 |
| U9 | 1=`$1N426`；2=`GND` | H1.2独立电源接口 |

## 关键外围端点

| 信号 | 最新网表中的全部端点 |
| --- | --- |
| `CS` | P1.9, U1.14, U3.14 |
| `MPA5` | P1.10, U1.15, U3.15 |
| `MPA6` | P1.11, U1.16, U3.16 |
| `MPA7` | P1.12, U1.17, U3.17 |
| `IO_IRQ` | P2.8, P3.13, R29.1, U1.18, U3.41 |
| `SPA1_NC` | C40.2, CN3.2, P1.6, R28.1, U3.11 |
| `SPB0_START` | C31.2, P1.13, R17.1, SW5.2, U3.18 |
| `SPB1_NC` | C32.2, CN4.2, P1.14, R18.1, U3.19 |
| `SPB12_NC` | C33.2, CN5.2, P2.20, R19.1, U3.25 |
| `SPB13_NC` | C34.2, CN6.2, P2.19, R20.1, U3.26 |
| `SPB14_NC` | C35.2, CN7.2, P2.18, R21.1, U3.27 |
| `SPB15_STOP` | C36.2, CN8.2, P2.17, R23.1, U3.28 |
| `$1N295` | R27.2, U3.29 |
| `SPA8_GRIP_PWM` | H1.3, P2.16, R26.2, R27.1 |
| `$1N426` | C38.2, C39.1, H1.2, U9.1 |
| `MPC13-TAMPER-RTC` | P3.2, R5.2, U1.2 |
| `SPC13-TAMPER-RTC` | P1.2, R16.2, U3.2 |
| `SPB8` | LED5.1, P2.5, U3.45 |
| `$1N451` | LED5.2, R30.2 |

注意 PA8 本体位于 `$1N295`，经串联电阻 R27 才到名为 `SPA8_GRIP_PWM` 的接口网；不能只按网名搜索而遗漏 MCU。H1.2 的 `$1N426` 连接 C38.2、C39.1、H1.2、U9.1，电压尚未确认。

安全状态、LED 极性证据、BOM/机械缺口见 [hardware-audit.md](hardware-audit.md)；协议来源与三轴未知项见 [x42s-protocol-status.md](x42s-protocol-status.md)。
