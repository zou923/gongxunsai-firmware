#ifndef SORTER_BOARD_H
#define SORTER_BOARD_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

typedef enum { BOARD_UART_VISION, BOARD_UART_DEBUG, BOARD_UART_MOTOR } board_uart_t;
typedef struct {
    volatile uint32_t uart_rx_overflow, uart_errors, uart_tx_dropped;
    volatile uint32_t spi_errors, spi_timeouts, spi_short_frames;
    volatile uint32_t spi_nss_starts, spi_rx_complete;
} board_diagnostics_t;
extern board_diagnostics_t board_diagnostics;

void board_init(void);
uint32_t board_millis(void);
void board_service(uint32_t now);
bool board_uart_read(board_uart_t port, uint8_t *byte);
bool board_uart_write(board_uart_t port, const uint8_t *data, size_t length);
bool board_spi_master_start(const uint8_t tx[32], uint32_t now);
bool board_spi_slave_arm(const uint8_t tx[32]);
bool board_spi_take(uint8_t rx[32]);
bool board_io_ready(void);
uint16_t board_read_inputs(void);
void board_force_safe_outputs(void);
bool board_servo_write_us(uint16_t pulse_us);
void board_status_led(bool on);
#endif
