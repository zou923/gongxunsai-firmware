#include "board.h"
#include "board_config.h"
#include "stm32f1xx_hal.h"
#include <string.h>

#define RING_SIZE 256U
typedef struct {
    USART_TypeDef *reg;
    volatile uint16_t rx_head, rx_tail, tx_head, tx_tail;
    uint8_t rx[RING_SIZE], tx[RING_SIZE];
    bool enabled;
} uart_ring_t;
static uart_ring_t vision_uart, debug_uart, motor_uart;
board_diagnostics_t board_diagnostics;
static uint8_t spi_tx[32], spi_rx[32];
static volatile bool dma_done, spi_error, nss_started, nss_ended;
static volatile uint32_t nss_started_at;
static volatile uint16_t nss_received;
static bool spi_armed, spi_pending;
#if defined(FIRMWARE_IO)
static uint16_t servo_hw_us;
#endif
#if defined(FIRMWARE_MASTER)
static uint32_t spi_started_at;
#endif

static void gpio(GPIO_TypeDef *port, uint32_t pins, uint32_t mode, uint32_t pull)
{
    GPIO_InitTypeDef cfg = {0};
    cfg.Pin = pins; cfg.Mode = mode; cfg.Pull = pull;
    cfg.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(port, &cfg);
}

static void uart_init(uart_ring_t *ring, USART_TypeDef *reg, IRQn_Type irq)
{
    ring->reg = reg;
    /* All buses run at HSI 8 MHz. BRR is the rounded oversampling-by-16 divisor. */
    reg->BRR = (BOARD_CLOCK_HZ + BOARD_UART_BAUD / 2U) / BOARD_UART_BAUD;
    reg->CR2 = 0;
    reg->CR3 = 0;
    reg->CR1 = USART_CR1_UE | USART_CR1_TE | USART_CR1_RE | USART_CR1_RXNEIE;
    ring->enabled = true;
    HAL_NVIC_SetPriority(irq, 3, 0);
    HAL_NVIC_EnableIRQ(irq);
}

static void uart_irq(uart_ring_t *ring)
{
    const uint32_t status = ring->reg->SR;
    if (status & (USART_SR_RXNE | USART_SR_ORE | USART_SR_FE | USART_SR_NE)) {
        const uint8_t byte = (uint8_t)ring->reg->DR;
        if (status & (USART_SR_ORE | USART_SR_FE | USART_SR_NE)) {
            board_diagnostics.uart_errors++;
        } else {
            const uint16_t next = (uint16_t)((ring->rx_head + 1U) & (RING_SIZE - 1U));
            if (next == ring->rx_tail) board_diagnostics.uart_rx_overflow++;
            else { ring->rx[ring->rx_head] = byte; __DMB(); ring->rx_head = next; }
        }
    }
    if ((status & USART_SR_TXE) && (ring->reg->CR1 & USART_CR1_TXEIE)) {
        if (ring->tx_head == ring->tx_tail) ring->reg->CR1 &= ~USART_CR1_TXEIE;
        else {
            ring->reg->DR = ring->tx[ring->tx_tail];
            ring->tx_tail = (uint16_t)((ring->tx_tail + 1U) & (RING_SIZE - 1U));
        }
    }
}

void USART1_IRQHandler(void) { uart_irq(&vision_uart); }
void USART2_IRQHandler(void) { uart_irq(&debug_uart); }
void USART3_IRQHandler(void) { uart_irq(&motor_uart); }
void SysTick_Handler(void) { HAL_IncTick(); }

bool board_uart_read(board_uart_t port, uint8_t *byte)
{
    uart_ring_t *ring = port == BOARD_UART_VISION ? &vision_uart :
                        port == BOARD_UART_MOTOR ? &motor_uart : &debug_uart;
    if (!ring->enabled || byte == NULL) return false;
    const uint32_t primask=__get_PRIMASK();
    __disable_irq();
    if (ring->rx_tail != ring->rx_head) {
        *byte = ring->rx[ring->rx_tail];
        __DMB(); ring->rx_tail = (uint16_t)((ring->rx_tail + 1U) & (RING_SIZE - 1U));
        if(!primask)__enable_irq();
        return true;
    }
    /* Polling fallback keeps debug RX alive even if an IRQ edge is missed. */
    const uint32_t status=ring->reg->SR;
    if(status&(USART_SR_RXNE|USART_SR_ORE|USART_SR_FE|USART_SR_NE)){
        const uint8_t received=(uint8_t)ring->reg->DR;
        if(!primask)__enable_irq();
        if(status&(USART_SR_ORE|USART_SR_FE|USART_SR_NE)){
            board_diagnostics.uart_errors++;return false;
        }
        *byte=received;return true;
    }
    if(!primask)__enable_irq();
    return false;
}

bool board_uart_write(board_uart_t port, const uint8_t *data, size_t length)
{
    uart_ring_t *ring = port == BOARD_UART_VISION ? &vision_uart :
                        port == BOARD_UART_MOTOR ? &motor_uart : &debug_uart;
    if (!ring->enabled || data == NULL || length > RING_SIZE - 1U) return false;
    const uint16_t available = (uint16_t)((ring->tx_tail - ring->tx_head - 1U) & (RING_SIZE - 1U));
    if (length > available) { board_diagnostics.uart_tx_dropped++; return false; }
    uint16_t head = ring->tx_head;
    for (size_t i = 0; i < length; ++i) {
        ring->tx[head] = data[i]; head = (uint16_t)((head + 1U) & (RING_SIZE - 1U));
    }
    __DMB(); ring->tx_head = head;
    ring->reg->CR1 |= USART_CR1_TXEIE;
    return true;
}

static void spi_stop(void)
{
    SPI1->CR2 = 0;
    DMA1_Channel2->CCR = 0;
    DMA1_Channel3->CCR = 0;
    SPI1->CR1 = 0;
    DMA1->IFCR = DMA_IFCR_CGIF2 | DMA_IFCR_CGIF3;
    __HAL_RCC_SPI1_FORCE_RESET();
    __HAL_RCC_SPI1_RELEASE_RESET();
    spi_armed = false;
#if defined(FIRMWARE_MASTER)
    GPIOA->BSRR = GPIO_PIN_4;
#else
    GPIOB->BSRR = GPIO_PIN_5; /* Open-drain high = not ready. */
#endif
}

#if defined(FIRMWARE_IO)
static void spi_arm(const uint8_t tx[32])
{
    spi_stop();
    memcpy(spi_tx, tx, sizeof spi_tx);
    memset(spi_rx, 0, sizeof spi_rx);
    dma_done = false; spi_error = false; nss_started = false; nss_ended = false;
    nss_received = 0;
    DMA1_Channel2->CPAR = (uint32_t)&SPI1->DR;
    DMA1_Channel2->CMAR = (uint32_t)spi_rx;
    DMA1_Channel2->CNDTR = 32;
    DMA1_Channel2->CCR = DMA_CCR_MINC | DMA_CCR_PL_1 | DMA_CCR_TCIE | DMA_CCR_TEIE;
    DMA1_Channel3->CPAR = (uint32_t)&SPI1->DR;
    DMA1_Channel3->CMAR = (uint32_t)spi_tx;
    DMA1_Channel3->CNDTR = 32;
    DMA1_Channel3->CCR = DMA_CCR_MINC | DMA_CCR_DIR | DMA_CCR_PL_1 | DMA_CCR_TEIE;
#if defined(FIRMWARE_MASTER)
    SPI1->CR1 = SPI_CR1_MSTR | SPI_CR1_SSM | SPI_CR1_SSI |
                SPI_CR1_BR_2 | SPI_CR1_BR_1 | SPI_CR1_BR_0; /* 8 MHz / 256 */
    GPIOA->BRR = GPIO_PIN_4;
#else
    SPI1->CR1 = 0; /* Mode 0, MSB first, 8 bits, hardware NSS. */
#endif
    DMA1_Channel2->CCR |= DMA_CCR_EN;
    DMA1_Channel3->CCR |= DMA_CCR_EN;
    SPI1->CR2 = SPI_CR2_RXDMAEN | SPI_CR2_TXDMAEN | SPI_CR2_ERRIE;
    spi_armed = true;
    SPI1->CR1 |= SPI_CR1_SPE;
#if defined(FIRMWARE_IO)
    GPIOB->BRR = GPIO_PIN_5; /* Packet loaded: MASTER may start a transfer. */
#endif
}
#endif

void DMA1_Channel2_IRQHandler(void)
{
    const uint32_t flags = DMA1->ISR;
    DMA1->IFCR = DMA_IFCR_CGIF2;
    if (flags & DMA_ISR_TEIF2) spi_error = true;
    if (flags & DMA_ISR_TCIF2) {
        dma_done = true;
        board_diagnostics.spi_rx_complete++;
    }
}
void DMA1_Channel3_IRQHandler(void)
{
    if (DMA1->ISR & DMA_ISR_TEIF3) spi_error = true;
    DMA1->IFCR = DMA_IFCR_CGIF3;
}
void SPI1_IRQHandler(void)
{
    spi_error = true;
    SPI1->CR2 &= ~SPI_CR2_ERRIE; /* Recovery is performed in the main loop. */
}
void EXTI4_IRQHandler(void)
{
    if (!(EXTI->PR & EXTI_PR_PR4)) return;
    EXTI->PR = EXTI_PR_PR4;
#if defined(FIRMWARE_IO)
    if (!(GPIOA->IDR & GPIO_PIN_4)) {
        nss_started = true; nss_started_at = HAL_GetTick();
        board_diagnostics.spi_nss_starts++;
        GPIOB->BSRR = GPIO_PIN_5;
    } else if (nss_started) {
        nss_received = (uint16_t)(32U - DMA1_Channel2->CNDTR);
        if (SPI1->SR & (SPI_SR_OVR | SPI_SR_RXNE)) spi_error = true;
        nss_ended = true;
    }
#endif
}

void board_service(uint32_t now)
{
    if (!spi_armed) return;
#if defined(FIRMWARE_MASTER)
    if (dma_done && !(SPI1->SR & SPI_SR_BSY) && !spi_error) {
        spi_stop(); spi_pending = true;
    } else if (spi_error || (uint32_t)(now - spi_started_at) >= BOARD_SPI_TRANSFER_TIMEOUT_MS) {
        if (!spi_error) board_diagnostics.spi_timeouts++;
        board_diagnostics.spi_errors++; spi_stop();
        memset(spi_rx, 0, sizeof spi_rx);
        spi_pending = true; /* Deliver an invalid frame so the app clears in-flight state. */
    }
#else
    /* RX DMA completion proves that all 32 clocks arrived. Do not depend only
     * on the PA4 EXTI rising edge: hardware NSS can complete a valid frame
     * even when that GPIO edge interrupt is missed. */
    if (dma_done && !(SPI1->SR & SPI_SR_BSY) && !spi_error) {
        spi_stop();
        spi_pending = true;
    } else if (nss_ended) {
        const bool complete = nss_received == 32U && !spi_error;
        if (!complete) { board_diagnostics.spi_short_frames++; board_diagnostics.spi_errors++; }
        spi_stop();
        if (!complete) memset(spi_rx, 0, sizeof spi_rx);
        spi_pending = true; /* App records rejection, builds status and rearms. */
    } else if (spi_error || (nss_started && (uint32_t)(now - nss_started_at) >= BOARD_SPI_TRANSFER_TIMEOUT_MS)) {
        if (!spi_error) board_diagnostics.spi_timeouts++;
        board_diagnostics.spi_errors++; spi_stop();
        memset(spi_rx, 0, sizeof spi_rx);
        spi_pending = true;
    }
#endif
}

bool board_spi_master_start(const uint8_t tx[32], uint32_t now)
{
#if defined(FIRMWARE_MASTER)
    if (spi_armed || spi_pending) return false;
    /* A completed DMA RX with an all-zero slave request proved that clocks were
     * generated while MOSI data was not reaching the wire.  Use explicit
     * 8-bit DR accesses on the master; the 32-byte transfer takes about 8 ms at
     * 31.25 kHz and remains below the configured transfer timeout. */
    spi_stop();
    memcpy(spi_tx, tx, sizeof spi_tx);
    memset(spi_rx, 0, sizeof spi_rx);
    spi_started_at = now;
    SPI1->CR1 = SPI_CR1_MSTR | SPI_CR1_SSM | SPI_CR1_SSI |
                SPI_CR1_BR_2 | SPI_CR1_BR_1 | SPI_CR1_BR_0;
    SPI1->CR1 |= SPI_CR1_SPE;
    GPIOA->BRR = GPIO_PIN_4;
    for (uint32_t i = 0; i < sizeof spi_tx; ++i) {
        while (!(SPI1->SR & SPI_SR_TXE)) {
            if ((uint32_t)(HAL_GetTick() - now) >= BOARD_SPI_TRANSFER_TIMEOUT_MS) goto timeout;
        }
        *(__IO uint8_t *)&SPI1->DR = spi_tx[i];
        while (!(SPI1->SR & SPI_SR_RXNE)) {
            if ((uint32_t)(HAL_GetTick() - now) >= BOARD_SPI_TRANSFER_TIMEOUT_MS) goto timeout;
        }
        spi_rx[i] = *(__IO uint8_t *)&SPI1->DR;
    }
    while (SPI1->SR & SPI_SR_BSY) {
        if ((uint32_t)(HAL_GetTick() - now) >= BOARD_SPI_TRANSFER_TIMEOUT_MS) goto timeout;
    }
    GPIOA->BSRR = GPIO_PIN_4;
    SPI1->CR1 = 0;
    board_diagnostics.spi_rx_complete++;
    spi_pending = true;
    return true;

timeout:
    board_diagnostics.spi_timeouts++;
    board_diagnostics.spi_errors++;
    spi_stop();
    memset(spi_rx, 0, sizeof spi_rx);
    spi_pending = true;
    return true;
#else
    (void)tx; (void)now; return false;
#endif
}
bool board_spi_slave_arm(const uint8_t tx[32])
{
#if defined(FIRMWARE_IO)
    if (spi_armed || spi_pending || !(GPIOA->IDR & GPIO_PIN_4)) return false;
    spi_arm(tx); return true;
#else
    (void)tx; return false;
#endif
}
bool board_spi_take(uint8_t rx[32])
{
    if (!spi_pending) return false;
    memcpy(rx, spi_rx, sizeof spi_rx); spi_pending = false; return true;
}
bool board_io_ready(void)
{
#if defined(FIRMWARE_MASTER)
    return !(GPIOB->IDR & GPIO_PIN_0);
#else
    return false;
#endif
}
uint16_t board_read_inputs(void)
{
    const uint32_t a = GPIOA->IDR, b = GPIOB->IDR;
    return (uint16_t)(((b >> 0) & 1U) | (((b >> 15) & 1U) << 1) |
        (((a >> 1) & 1U) << 2) | (((b >> 1) & 1U) << 3) |
        (((b >> 12) & 1U) << 4) | (((b >> 13) & 1U) << 5) | (((b >> 14) & 1U) << 6));
}
void board_force_safe_outputs(void)
{
#if defined(FIRMWARE_IO)
    /* PA8 external 10K pull-down holds the servo signal inactive. No PWM starts. */
    TIM1->CCER = 0;
    TIM1->BDTR = 0;
    TIM1->CR1 = 0;
    servo_hw_us = 0u;
    gpio(GPIOA, GPIO_PIN_8, GPIO_MODE_ANALOG, GPIO_NOPULL);
    /* No MOS/alarm pin has been established, so no unknown pin is driven. */
#endif
}

bool board_servo_write_us(uint16_t pulse_us)
{
#if defined(FIRMWARE_IO)
    if (pulse_us < 500u || pulse_us > 1100u) return false;
    if (servo_hw_us == pulse_us && (TIM1->CR1 & TIM_CR1_CEN)) return true;
    if (servo_hw_us != 0u && (TIM1->CR1 & TIM_CR1_CEN)) {
        TIM1->CCR1 = pulse_us;
        servo_hw_us = pulse_us;
        return true;
    }
    __HAL_RCC_TIM1_CLK_ENABLE();
    gpio(GPIOA, GPIO_PIN_8, GPIO_MODE_AF_PP, GPIO_NOPULL);
    TIM1->CR1 = 0;
    TIM1->PSC = 7u;       /* 8 MHz / 8 = 1 MHz: one timer count per us. */
    TIM1->ARR = 19999u;   /* 20 ms / 50 Hz servo frame. */
    TIM1->CCR1 = pulse_us;
    TIM1->CCMR1 = TIM_CCMR1_OC1M_2 | TIM_CCMR1_OC1M_1 | TIM_CCMR1_OC1PE;
    TIM1->EGR = TIM_EGR_UG;
    TIM1->CCER = TIM_CCER_CC1E;
    TIM1->BDTR = TIM_BDTR_MOE;
    TIM1->CR1 = TIM_CR1_ARPE | TIM_CR1_CEN;
    servo_hw_us = pulse_us;
    return true;
#else
    (void)pulse_us;
    return false;
#endif
}
void board_status_led(bool on)
{
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, on ? GPIO_PIN_RESET : GPIO_PIN_SET);
}
uint32_t board_millis(void) { return HAL_GetTick(); }

void board_init(void)
{
    HAL_Init();
    __HAL_RCC_AFIO_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE(); __HAL_RCC_GPIOB_CLK_ENABLE(); __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_DMA1_CLK_ENABLE(); __HAL_RCC_SPI1_CLK_ENABLE();
    /* PB5 is an ordinary GPIO; leave SWD/JTAG configuration unchanged. */
    GPIOC->BSRR = GPIO_PIN_13;
    gpio(GPIOC, GPIO_PIN_13, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL);
#if defined(FIRMWARE_MASTER)
    GPIOA->BSRR = GPIO_PIN_4;
    gpio(GPIOA, GPIO_PIN_4, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL);
    gpio(GPIOA, GPIO_PIN_5 | GPIO_PIN_7, GPIO_MODE_AF_PP, GPIO_NOPULL);
    gpio(GPIOA, GPIO_PIN_6, GPIO_MODE_INPUT, GPIO_NOPULL);
    gpio(GPIOB, GPIO_PIN_0, GPIO_MODE_INPUT, GPIO_PULLUP);
#else
    GPIOB->BSRR = GPIO_PIN_5;
    gpio(GPIOB, GPIO_PIN_5, GPIO_MODE_OUTPUT_OD, GPIO_NOPULL);
    gpio(GPIOA, GPIO_PIN_4, GPIO_MODE_IT_RISING_FALLING, GPIO_PULLUP);
    gpio(GPIOA, GPIO_PIN_5 | GPIO_PIN_7, GPIO_MODE_INPUT, GPIO_NOPULL);
    gpio(GPIOA, GPIO_PIN_6, GPIO_MODE_AF_PP, GPIO_NOPULL);
    gpio(GPIOA, GPIO_PIN_1, GPIO_MODE_INPUT, GPIO_NOPULL);
    gpio(GPIOB, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_12 | GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15,
         GPIO_MODE_INPUT, GPIO_NOPULL); /* All seven inputs have external pull-ups. */
    gpio(GPIOA, GPIO_PIN_8, GPIO_MODE_ANALOG, GPIO_NOPULL);
    HAL_NVIC_SetPriority(EXTI4_IRQn, 1, 0); HAL_NVIC_EnableIRQ(EXTI4_IRQn);
#endif
#if BOARD_VISION_UART_ENABLED && defined(FIRMWARE_MASTER)
    __HAL_RCC_USART1_CLK_ENABLE();
    gpio(GPIOA, GPIO_PIN_9, GPIO_MODE_AF_PP, GPIO_NOPULL);
    gpio(GPIOA, GPIO_PIN_10, GPIO_MODE_INPUT, GPIO_PULLUP);
    uart_init(&vision_uart, USART1, USART1_IRQn);
#endif
#if BOARD_DEBUG_UART_ENABLED
    __HAL_RCC_USART2_CLK_ENABLE();
    gpio(GPIOA, GPIO_PIN_2, GPIO_MODE_AF_PP, GPIO_NOPULL);
    gpio(GPIOA, GPIO_PIN_3, GPIO_MODE_INPUT, GPIO_PULLUP);
    uart_init(&debug_uart, USART2, USART2_IRQn);
#endif
#if defined(FIRMWARE_MASTER)
    /* X42S commissioning UART: PB10 TX, PB11 RX, 115200 baud. */
    __HAL_RCC_USART3_CLK_ENABLE();
    gpio(GPIOB, GPIO_PIN_10, GPIO_MODE_AF_PP, GPIO_NOPULL);
    gpio(GPIOB, GPIO_PIN_11, GPIO_MODE_INPUT, GPIO_PULLUP);
    uart_init(&motor_uart, USART3, USART3_IRQn);
#endif
    HAL_NVIC_SetPriority(DMA1_Channel2_IRQn, 2, 0); HAL_NVIC_EnableIRQ(DMA1_Channel2_IRQn);
    HAL_NVIC_SetPriority(DMA1_Channel3_IRQn, 2, 0); HAL_NVIC_EnableIRQ(DMA1_Channel3_IRQn);
    HAL_NVIC_SetPriority(SPI1_IRQn, 2, 0); HAL_NVIC_EnableIRQ(SPI1_IRQn);
    board_force_safe_outputs();
}
