#include "four_axis_zero.h"
#include <string.h>
void four_axis_zero_init(four_axis_zero_t *z){if(z)memset(z,0,sizeof *z);}void four_axis_zero_begin(four_axis_zero_t *z,uint32_t now){(void)now;if(z){memset(z->pending,0,sizeof z->pending);z->next=0;z->active=true;z->failed=false;}}
uint8_t four_axis_zero_expected_address(const four_axis_zero_t *z){return z&&z->active&&z->next<4?(uint8_t)(z->next+1U):0U;}
bool four_axis_zero_accept(four_axis_zero_t *z,uint8_t a,int64_t raw){if(!z||!z->active||a!=z->next+1U){if(z){z->active=false;z->failed=true;}return false;}z->pending[z->next++]=raw;if(z->next==4)z->active=false;return true;}
void four_axis_zero_timeout(four_axis_zero_t *z){if(z){z->active=false;z->failed=true;}}bool four_axis_zero_failed(const four_axis_zero_t *z){return z&&z->failed;}
bool four_axis_zero_commit(four_axis_zero_t *z,int64_t o[4]){if(!z||!o||z->active||z->failed||z->next!=4)return false;memcpy(o,z->pending,sizeof z->pending);return true;}
