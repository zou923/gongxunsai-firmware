#include "app_state.h"
#include "board.h"
#include "board_config.h"
#include "debug_uart.h"
#include "debug_trigger.h"
#include "io_spi.h"
#include "motion.h"
#include "master_display.h"
#include "OLED.h"
#include "protocol.h"
#include "vision_uart.h"
#include "x42s_protocol.h"
#include "corexy_command.h"
#include "corexy_motion.h"
#include "four_axis_command.h"
#include "four_axis_motion.h"
#include "four_axis_zero.h"
#include "four_axis_limits.h"
#include "servo_command.h"
#include "stm32f1xx.h"
#include <string.h>

typedef enum { POSITION_QUERY_NONE, POSITION_QUERY_ZERO, POSITION_QUERY_LIMIT }
    position_query_action_t;

static position_query_action_t position_query_action;
static int64_t x_origin_raw;
static bool x_origin_valid;
static bool origin_valid[4];
static four_axis_limits_t axis_limits;
static bool limit_waiting_to_query;
static uint8_t limit_query_axis;
static uint32_t limit_query_at;
static uint8_t motor_reply[8];
static uint8_t motor_reply_length;
static uint32_t motor_deadline;
static four_axis_zero_t zero_query;
static int64_t four_origins[4];
static bool four_zero_active;

static bool start_position_query_address(uint8_t address,uint32_t now)
{
    uint8_t frame[3];size_t length=0U;uint8_t byte;
    if(!x42s_build_query_position(address,frame,sizeof frame,&length))return false;
    while(board_uart_read(BOARD_UART_MOTOR,&byte)){}
    motor_reply_length=0U;
    if(!board_uart_write(BOARD_UART_MOTOR,frame,length))return false;
    motor_deadline=now+120U;return true;
}

static bool start_position_query(position_query_action_t action,uint32_t now)
{
    if(!start_position_query_address(action==POSITION_QUERY_LIMIT?
       four_axis_limit_motor_for_axis(limit_query_axis):BOARD_COREXY_MOTOR1_ID,now))return false;
    position_query_action=action;return true;
}

static char hex_digit(uint8_t value)
{
    static const char digits[] = "0123456789ABCDEF";
    value &= 0x0FU;
    return digits[value];
}

static void report_motor_reply(const uint8_t *data, uint8_t length)
{
    char text[48] = "MOTOR RX:";
    uint8_t position = 9U;
    for (uint8_t i = 0U; i < length && position + 3U < sizeof text; ++i) {
        text[position++] = ' ';
        text[position++] = hex_digit((uint8_t)(data[i] >> 4));
        text[position++] = hex_digit(data[i]);
    }
    text[position++] = '\r';
    text[position++] = '\n';
    text[position] = '\0';
    debug_uart_log(text);
}

static bool send_corexy_plan(corexy_motion_t *corexy,int32_t x_um,int32_t y_um,
    const char *success_text)
{
    corexy_plan_t plan;uint8_t frame[40];size_t frame_length=0U;
    corexy_result_t result=corexy_plan_absolute(corexy,x_um,y_um,&plan);
    if(result==COREXY_NOT_HOMED){debug_uart_log("XY REJECT: SEND ZERO FIRST\r\n");return false;}
    if(result==COREXY_OUT_OF_RANGE){debug_uart_log("XY REJECT: RANGE\r\n");return false;}
    if(result!=COREXY_OK){debug_uart_log("XY REJECT: CONFIG\r\n");return false;}
    if(!x42s_build_dual_emm_position(BOARD_COREXY_MOTOR1_ID,plan.motor1_ccw,
       plan.motor1_rpm,BOARD_COREXY_ACCELERATION,plan.motor1_pulses,
       BOARD_COREXY_MOTOR2_ID,plan.motor2_ccw,plan.motor2_rpm,
       BOARD_COREXY_ACCELERATION,plan.motor2_pulses,frame,sizeof frame,&frame_length)||
       !board_uart_write(BOARD_UART_MOTOR,frame,frame_length)){
        debug_uart_log("MOTOR UART BUSY\r\n");return false;
    }
    corexy_commit(corexy,&plan);debug_uart_log(success_text);return true;
}

static bool send_four_axis_plan(four_axis_motion_t *motion,const int32_t target[4])
{
    four_axis_plan_t plan;x42s_position_request_t request[4];uint8_t frame[64];size_t length=0U;
    four_axis_result_t result=four_axis_plan_absolute(motion,target,&plan);
    if(result==FOUR_AXIS_NOT_HOMED){debug_uart_log("XYZS REJECT: SEND ZERO FIRST\r\n");return false;}
    if(result==FOUR_AXIS_OUT_OF_RANGE){debug_uart_log("XYZS REJECT: RANGE\r\n");return false;}
    if(result!=FOUR_AXIS_OK){debug_uart_log("XYZS REJECT: CONFIG\r\n");return false;}
    for(uint8_t i=0;i<4U;i++)request[i]=(x42s_position_request_t){(uint8_t)(i+1U),plan.axis[i].ccw,
        plan.axis[i].rpm,BOARD_COREXY_ACCELERATION,plan.axis[i].pulses};
    if(!x42s_build_four_position(request,frame,sizeof frame,&length)||!board_uart_write(BOARD_UART_MOTOR,frame,length)){
        debug_uart_log("MOTOR UART BUSY\r\n");return false;}
    four_axis_commit(motion,&plan);debug_uart_log("XYZS MOVE TX\r\n");return true;
}

static bool send_rotation(uint8_t address,int32_t turns_milli)
{
    uint8_t frame[13];size_t length=0U;uint32_t magnitude=(uint32_t)(turns_milli<0?-turns_milli:turns_milli);
    uint32_t pulses=(uint32_t)(((uint64_t)magnitude*BOARD_COREXY_PULSES_PER_REV+500U)/1000U);
    bool ccw = turns_milli < 0;
    if(address == 3U) ccw = !ccw; /* Keep R3 consistent with the inverted Z axis. */
    if(!x42s_build_emm_position(address,ccw,30U,BOARD_COREXY_ACCELERATION,pulses,
       X42S_POSITION_REL_CURRENT,false,frame,sizeof frame,&length)||!board_uart_write(BOARD_UART_MOTOR,frame,length))return false;
    debug_uart_log(address==3U?"R3 MOVE TX\r\n":"R4 MOVE TX\r\n");return true;
}

static void execute_corexy_line(char *line,corexy_motion_t *corexy,four_axis_motion_t *four,uint32_t now)
{
    four_axis_command_t four_command;
    corexy_command_t command;
    if(four_axis_command_parse(line,&four_command)){
        if(four_zero_active||position_query_action!=POSITION_QUERY_NONE||limit_waiting_to_query){debug_uart_log("MOTOR BUSY: POSITION QUERY\r\n");return;}
        if(four_command.kind==FOUR_AXIS_CMD_XYZS){if(send_four_axis_plan(four,four_command.value_um)){corexy_set_position(corexy,four->position_um[0],four->position_um[1]);}return;}
        if(four_command.kind==FOUR_AXIS_CMD_R3||four_command.kind==FOUR_AXIS_CMD_R4){
            uint8_t axis=four_command.kind==FOUR_AXIS_CMD_R3?2U:3U;
            if(send_rotation((uint8_t)(axis+1U),four_command.turns_milli)){
                int64_t next=(int64_t)four->position_um[axis]+(int64_t)four_command.turns_milli*40000/1000;
                if(four->homed&&next>=0&&next<=500000)four->position_um[axis]=(int32_t)next;
                else four_axis_clear_zero(four);
            }else debug_uart_log("MOTOR UART BUSY\r\n");return;}
        {uint8_t frame[32];size_t length=0U;uint8_t first=four_command.kind==FOUR_AXIS_CMD_STOP3?3U:four_command.kind==FOUR_AXIS_CMD_STOP4?4U:1U;uint8_t count=four_command.kind==FOUR_AXIS_CMD_STOPALL?4U:1U;
         if(x42s_build_stop_many(first,count,frame,sizeof frame,&length)&&board_uart_write(BOARD_UART_MOTOR,frame,length))debug_uart_log("STOP TX\r\n");else debug_uart_log("MOTOR UART BUSY\r\n");return;}
    }
    if(!corexy_command_parse(line,&command))return;
    if(!BOARD_COREXY_CONFIG_CONFIRMED){debug_uart_log("COREXY LOCKED: CONFIG TODO\r\n");return;}
    if(position_query_action!=POSITION_QUERY_NONE||limit_waiting_to_query){
        debug_uart_log("XY BUSY: POSITION QUERY\r\n");return;
    }
    if(command.kind==COREXY_CMD_ZERO){
        corexy_clear_homed(corexy);
        four_axis_clear_zero(four);
#if BOARD_FOUR_AXIS_ZERO_QUERY_ENABLED
        four_axis_zero_begin(&zero_query,now);four_zero_active=true;
        if(start_position_query_address(1U,now))debug_uart_log("ZERO AXIS 1 QUERY TX\r\n");
        else {four_zero_active=false;four_axis_zero_timeout(&zero_query);debug_uart_log("MOTOR UART BUSY\r\n");}
#else
        (void)now;
        four_axis_set_zero(four);corexy_set_homed(corexy);
        x_origin_raw=0;x_origin_valid=false;memset(origin_valid,0,sizeof origin_valid);
        debug_uart_log("ZERO OK; SOFTWARE ORIGIN 0,0,0,0\r\n");
#endif
        return;
    }
    if(command.kind==COREXY_CMD_HOME){
        const int32_t home[4]={0,0,0,0};
        if(send_four_axis_plan(four,home)){
            corexy_set_position(corexy,0,0);
            debug_uart_log("HOME MOVE TX: 0,0,0,0\r\n");
        }
        return;
    }
    if(command.kind==COREXY_CMD_XY)
        if(send_corexy_plan(corexy,command.x_um,command.y_um,"XY MOVE TX\r\n")){four->position_um[0]=command.x_um;four->position_um[1]=command.y_um;}
}

int main(void)
{
    app_state_t app;
    io_link_t io;
    vision_receiver_t vision;
    uint8_t spi_request[PROTOCOL_FRAME_SIZE];
    uint8_t spi_reply[PROTOCOL_FRAME_SIZE];
    uint32_t next_poll = 0;
    uint32_t next_status = 0;
    uint32_t next_display = 0;
    bool reported_io_online = false;
    bool io_report_initialized = false;
    bool spi_in_flight = false;
    app_state_id_t reported_state = APP_FINISHED;
    debug_trigger_t debug_trigger;
    uint8_t motor_command_state = 0U;
    bool motor2_ccw = false;
    char command_line[48];
    uint8_t command_line_length = 0U;
    uint32_t command_line_deadline = 0U;
    bool debug_rx_seen = false;
    servo_command_t servo_command;
    uint16_t servo_target_us = 0u;
    bool servo_command_pending = false;
    const corexy_config_t corexy_config = {
        BOARD_COREXY_PULSES_PER_REV, BOARD_COREXY_TRAVEL_UM_PER_REV,
        BOARD_COREXY_MAX_RPM, BOARD_COREXY_ACCELERATION,
        BOARD_COREXY_X_MAX_UM, BOARD_COREXY_Y_MAX_UM,
        BOARD_COREXY_MOTOR1_INVERT != 0, BOARD_COREXY_MOTOR2_INVERT != 0
    };
    corexy_motion_t corexy;
    four_axis_motion_t four_axis;

    board_init();
    debug_trigger_init(&debug_trigger);
    app_state_init(&app, board_millis());
    io_link_init(&io);
    servo_command_init(&servo_command);
    vision_receiver_init(&vision);
    x42s_driver_init(X42S_MODE_HARDWARE_LOCKED);
    corexy_init(&corexy, &corexy_config);
    four_axis_init(&four_axis);four_axis_zero_init(&zero_query);four_axis_limits_init(&axis_limits);
#if !BOARD_FOUR_AXIS_ZERO_QUERY_ENABLED
    four_axis_set_zero(&four_axis);corexy_set_homed(&corexy);
#endif
    debug_uart_log("MASTER XY AXES MANUAL READY\r\n");
    OLED_Init();
    OLED_Clear();

    for (;;) {
        uint8_t byte;
        uint8_t debug_byte;
        uint32_t now = board_millis();
        board_service(now);

        while (board_uart_read(BOARD_UART_DEBUG, &debug_byte)) {
            bool motor_command_consumed = false;
            if(!debug_rx_seen){debug_rx_seen=true;debug_uart_log("UART RX OK\r\n");}
            if (debug_byte == (uint8_t)'P' || servo_command_active(&servo_command)) {
                if (servo_command_feed(&servo_command, debug_byte, &servo_target_us)) {
                    servo_command_pending = true;
                    debug_uart_log(servo_target_us == 0u ? "SERVO FORWARD OFF\r\n" :
                                                        "SERVO FORWARD QUEUED\r\n");
                }
                continue;
            }
            if (debug_byte == '\r' || debug_byte == '\n') {
                if (command_line_length != 0U) {
                    command_line[command_line_length] = '\0';
                    execute_corexy_line(command_line,&corexy,&four_axis,now);
                    command_line_length=0U;
                }
            } else if (command_line_length + 1U < sizeof command_line) {
                command_line[command_line_length++] = (char)debug_byte;
                command_line_deadline=now+30U;
                if((command_line_length==4U&&memcmp(command_line,"ZERO",4U)==0)||
                   (command_line_length==4U&&memcmp(command_line,"HOME",4U)==0)){
                    command_line[command_line_length]='\0';
                    execute_corexy_line(command_line,&corexy,&four_axis,now);
                    command_line_length=0U;
                }
            } else {
                command_line_length=0U;
                debug_uart_log("COMMAND TOO LONG\r\n");
            }
            if (motor_command_state == 0U && debug_byte == (uint8_t)'M') {
                motor_command_state = 1U;
                motor_command_consumed = true;
            } else if (motor_command_state == 0U && debug_byte == (uint8_t)'J') {
                motor_command_state = 6U;
                motor_command_consumed = true;
            } else if (motor_command_state == 6U && debug_byte == (uint8_t)'2') {
                motor_command_state = 11U;
                motor_command_consumed = true;
            } else if (motor_command_state == 11U &&
                       (debug_byte == (uint8_t)'+' || debug_byte == (uint8_t)'-')) {
                motor2_ccw = debug_byte == (uint8_t)'+';
                motor_command_state = 12U;
                motor_command_consumed = true;
            } else if (motor_command_state == 12U && debug_byte == (uint8_t)'J') {
                motor_command_state = 13U;
                motor_command_consumed = true;
            } else if (motor_command_state == 13U && debug_byte == (uint8_t)'1') {
                motor_command_state = 14U;
                motor_command_consumed = true;
            } else if (motor_command_state == 14U &&
                       (debug_byte == (uint8_t)'+' || debug_byte == (uint8_t)'-')) {
                uint8_t command[25];
                size_t motor2_length = 0U;
                size_t motor1_length = 0U;
                size_t trigger_length = 0U;
                const bool motor1_ccw = debug_byte == (uint8_t)'+';
                motor_command_state = 0U;
                motor_command_consumed = true;
                command[0]=0x00U;command[1]=0xAAU;command[2]=0x00U;command[3]=0x15U;
                if (x42s_build_emm_velocity(2U,motor2_ccw,60U,10U,true,command+4U,8U,
                                             &motor2_length) &&
                    x42s_build_emm_velocity(1U,motor1_ccw,60U,10U,true,command+12U,8U,
                                             &motor1_length) &&
                    motor2_length==8U && motor1_length==8U &&
                    (command[20]=0x6BU,
                     x42s_build_sync_trigger(command+21U,4U,&trigger_length)) &&
                    trigger_length==4U) {
                    motor_reply_length = 0U;
                    while (board_uart_read(BOARD_UART_MOTOR, &byte)) { }
                    if (board_uart_write(BOARD_UART_MOTOR, command, sizeof command)) {
                        corexy_clear_homed(&corexy); /* Continuous motion has unknown distance. */
                        x_origin_valid=false;
                        motor_deadline = now + 200U;
                        if (motor2_ccw) {
                            debug_uart_log(motor1_ccw ?
                                "RUN J2+ J1+ 60RPM SYNC TX\r\n" :
                                "RUN J2+ J1- 60RPM SYNC TX\r\n");
                        } else {
                            debug_uart_log(motor1_ccw ?
                                "RUN J2- J1+ 60RPM SYNC TX\r\n" :
                                "RUN J2- J1- 60RPM SYNC TX\r\n");
                        }
                    } else {
                        debug_uart_log("MOTOR UART BUSY\r\n");
                    }
                }
            } else if (motor_command_state == 0U && debug_byte == (uint8_t)'S') {
                motor_command_state = 8U;
                motor_command_consumed = true;
            } else if (motor_command_state == 8U && debug_byte == (uint8_t)'T') {
                motor_command_state = 9U;
                motor_command_consumed = true;
            } else if (motor_command_state == 9U && debug_byte == (uint8_t)'O') {
                motor_command_state = 10U;
                motor_command_consumed = true;
            } else if (motor_command_state == 10U && debug_byte == (uint8_t)'P') {
                uint8_t command[15];
                size_t command_length = 0U;
                motor_command_state = 0U;
                motor_command_consumed = true;
                if (x42s_build_dual_stop(1U,2U,command,sizeof command,&command_length)) {
                    motor_reply_length = 0U;
                    while (board_uart_read(BOARD_UART_MOTOR, &byte)) { }
                    if (board_uart_write(BOARD_UART_MOTOR, command,command_length)) {
                        corexy_clear_homed(&corexy);
                        x_origin_valid=false;
                        motor_deadline = now + 200U;
                        debug_uart_log("STOP 1+2 TX\r\n");
                    } else {
                        debug_uart_log("MOTOR UART BUSY\r\n");
                    }
                }
            } else if (motor_command_state == 1U && debug_byte == (uint8_t)'S') {
                motor_command_state = 2U;
                motor_command_consumed = true;
            } else if (motor_command_state == 1U && debug_byte == (uint8_t)'F') {
                motor_command_state = 5U;
                motor_command_consumed = true;
            } else if (motor_command_state == 5U &&
                       (debug_byte == (uint8_t)'1' || debug_byte == (uint8_t)'2')) {
                uint8_t query_firmware[] = {
                    (uint8_t)(debug_byte - (uint8_t)'0'), 0x1AU, 0x6BU
                };
                const char *tx_text = debug_byte == (uint8_t)'1' ?
                    "MOTOR TX: 01 1A 6B\r\n" : "MOTOR TX: 02 1A 6B\r\n";
                motor_command_state = 0U;
                motor_command_consumed = true;
                motor_reply_length = 0U;
                while (board_uart_read(BOARD_UART_MOTOR, &byte)) { }
                if (board_uart_write(BOARD_UART_MOTOR, query_firmware,
                                     sizeof query_firmware)) {
                    motor_deadline = now + 100U;
                    debug_uart_log(tx_text);
                } else {
                    debug_uart_log("MOTOR UART BUSY\r\n");
                }
            } else if (motor_command_state == 2U && debug_byte == (uint8_t)'E') {
                motor_command_state = 3U;
                motor_command_consumed = true;
            } else if (motor_command_state == 3U && debug_byte == (uint8_t)'T') {
                motor_command_state = 4U;
                motor_command_consumed = true;
            } else if (motor_command_state == 4U && debug_byte == (uint8_t)'2') {
                static const uint8_t set_id_2[] = {
                    0x01U, 0xAEU, 0x4BU, 0x01U, 0x02U, 0x6BU
                };
                motor_command_state = 0U;
                motor_command_consumed = true;
                motor_reply_length = 0U;
                while (board_uart_read(BOARD_UART_MOTOR, &byte)) { }
                if (board_uart_write(BOARD_UART_MOTOR, set_id_2, sizeof set_id_2)) {
                    motor_deadline = now + 100U;
                    debug_uart_log("MOTOR SET ID TX: 01 AE 4B 01 02 6B\r\n");
                } else {
                    debug_uart_log("MOTOR UART BUSY\r\n");
                }
            } else if (motor_command_state == 1U &&
                       (debug_byte == (uint8_t)'?' || debug_byte == (uint8_t)'1' ||
                        debug_byte == (uint8_t)'2')) {
                uint8_t query[3] = {0x00U, 0x15U, 0x6BU};
                const char *tx_text = "MOTOR TX: 00 15 6B\r\n";
                if (debug_byte == (uint8_t)'1' || debug_byte == (uint8_t)'2') {
                    query[0] = (uint8_t)(debug_byte - (uint8_t)'0');
                    query[1] = 0x3AU; /* Read motor status; no movement or parameter write. */
                    tx_text = debug_byte == (uint8_t)'1' ?
                        "MOTOR TX: 01 3A 6B\r\n" : "MOTOR TX: 02 3A 6B\r\n";
                }
                motor_command_state = 0U;
                motor_command_consumed = true;
                motor_reply_length = 0U;
                while (board_uart_read(BOARD_UART_MOTOR, &byte)) { }
                if (board_uart_write(BOARD_UART_MOTOR, query, sizeof query)) {
                    motor_deadline = now + 100U;
                    debug_uart_log(tx_text);
                } else {
                    debug_uart_log("MOTOR UART BUSY\r\n");
                }
            } else {
                motor_command_state = debug_byte == (uint8_t)'M' ? 1U : 0U;
            }
            if (!motor_command_consumed && command_line_length==1U &&
                command_line[0]=='1' &&
                debug_trigger_feed(&debug_trigger, debug_byte, now)) {
                debug_uart_log("LED ON 1s\r\n");
            }
        }
        if(command_line_length!=0U&&(int32_t)(now-command_line_deadline)>=0){
            command_line[command_line_length]='\0';
            execute_corexy_line(command_line,&corexy,&four_axis,now);
            command_line_length=0U;
        }

        while (board_uart_read(BOARD_UART_MOTOR, &byte)) {
            if (motor_reply_length < sizeof motor_reply) {
                motor_reply[motor_reply_length++] = byte;
            }
            motor_deadline = now + 20U;
        }
        if (motor_reply_length != 0U && (int32_t)(now - motor_deadline) >= 0) {
            x42s_reply_t reply;
            if(four_zero_active&&x42s_parse_reply(motor_reply,motor_reply_length,&reply)&&
               reply.kind==X42S_REPLY_POSITION&&
               four_axis_zero_accept(&zero_query,reply.address,reply.position_raw)){
                uint8_t next=four_axis_zero_expected_address(&zero_query);
                if(next!=0U){
                    if(start_position_query_address(next,now))debug_uart_log("ZERO NEXT AXIS QUERY TX\r\n");
                    else {four_axis_zero_timeout(&zero_query);four_zero_active=false;debug_uart_log("ZERO FAIL: UART BUSY\r\n");}
                }else if(four_axis_zero_commit(&zero_query,four_origins)){
                    four_zero_active=false;x_origin_raw=four_origins[0];x_origin_valid=true;
                    for(uint8_t i=0;i<4U;i++)origin_valid[i]=true;
                    four_axis_set_zero(&four_axis);corexy_set_homed(&corexy);
                    debug_uart_log("ZERO OK; AXES 1-4 ORIGIN SAVED\r\n");
                }
            }else if(four_zero_active){
                four_axis_zero_timeout(&zero_query);four_zero_active=false;debug_uart_log("ZERO FAIL: BAD REPLY\r\n");
            }else if(position_query_action!=POSITION_QUERY_NONE&&
               x42s_parse_reply(motor_reply,motor_reply_length,&reply)&&
               reply.kind==X42S_REPLY_POSITION&&
               reply.address==(position_query_action==POSITION_QUERY_LIMIT?
                   four_axis_limit_motor_for_axis(limit_query_axis):BOARD_COREXY_MOTOR1_ID)){
                if(position_query_action==POSITION_QUERY_ZERO){
                    x_origin_raw=reply.position_raw;x_origin_valid=true;
                    corexy_set_homed(&corexy);
                    debug_uart_log("ZERO OK; ORIGIN 0,0\r\n");
                }else if(origin_valid[limit_query_axis]){
                    int32_t coordinate=corexy_emm_position_to_um(four_origins[limit_query_axis],reply.position_raw,
                        BOARD_COREXY_TRAVEL_UM_PER_REV);
                    if(limit_query_axis==0U&&BOARD_COREXY_MOTOR1_INVERT)coordinate=-coordinate;
                    if(limit_query_axis==1U&&BOARD_COREXY_MOTOR2_INVERT)coordinate=-coordinate;
                    if(coordinate<0)coordinate=0;
                    if(coordinate>500000)coordinate=500000;
                    four_axis.position_um[limit_query_axis]=coordinate;
                    if(limit_query_axis<2U)corexy_set_position(&corexy,four_axis.position_um[0],four_axis.position_um[1]);
                    debug_uart_log("AXIS LIMIT STOP; POSITION SAVED\r\n");
                }
                position_query_action=POSITION_QUERY_NONE;
            }else report_motor_reply(motor_reply, motor_reply_length);
            motor_reply_length = 0U;
            if(!four_zero_active)motor_deadline = 0U;
        } else if (motor_reply_length == 0U && motor_deadline != 0U &&
                   (int32_t)(now - motor_deadline) >= 0) {
            if(four_zero_active){
                four_axis_zero_timeout(&zero_query);four_zero_active=false;debug_uart_log("ZERO FAIL: TIMEOUT\r\n");
            }else if(position_query_action!=POSITION_QUERY_NONE){
                debug_uart_log("POSITION QUERY TIMEOUT\r\n");
                position_query_action=POSITION_QUERY_NONE;
            }else debug_uart_log("MOTOR RX TIMEOUT\r\n");
            motor_deadline = 0U;
        }

        while (board_uart_read(BOARD_UART_VISION, &byte)) {
            if (vision_receiver_feed(&vision, byte, now)) {
                debug_uart_log("VISION item accepted\r\n");
            }
        }
        if (board_spi_take(spi_reply)) {
            spi_in_flight = false;
            if (io_link_accept(&io, spi_reply, now)) {
                (void)debug_trigger_sync_toggle(&debug_trigger,
                    (io.status.events & IO_EVENT_DEBUG_LED_TOGGLE) != 0u, now);
            }
        }
        four_axis_limits_update(&axis_limits,io.status_valid?(uint16_t)(io.status.active&io.status.valid):0U);
        if(position_query_action==POSITION_QUERY_NONE&&!limit_waiting_to_query&&!four_zero_active){
            int axis=four_axis_limits_pop(&axis_limits);
            if(axis>=0){uint8_t stop_frame[5];size_t stop_length=0U;uint8_t motor=four_axis_limit_motor_for_axis((uint8_t)axis);
                if(x42s_build_stop(motor,false,stop_frame,sizeof stop_frame,&stop_length)&&board_uart_write(BOARD_UART_MOTOR,stop_frame,stop_length)){
                    limit_query_axis=(uint8_t)axis;
                    /* Z/CN3 is the upward reference switch: the first
                     * asserted edge stops motor 3 and establishes the
                     * software Z origin at the stopped position.  Do not
                     * query the encoder here; the switch is the reference
                     * requested by the operator. */
                    if (axis==2){
                        four_axis.position_um[2]=0;
                        four_axis.homed=true;
                        origin_valid[2]=true;
                        limit_waiting_to_query=false;
                        debug_uart_log("Z LIMIT: STOPPED; ZERO SET\r\n");
                    } else {
                        limit_waiting_to_query=origin_valid[limit_query_axis];
                    }
                    limit_query_at=now+50U;
                    debug_uart_log("AXIS LIMIT: MOTOR STOP TX\r\n");
                    if(!limit_waiting_to_query&&axis!=2){four_axis_clear_zero(&four_axis);if(axis<2)corexy_clear_homed(&corexy);debug_uart_log("AXIS LIMIT: POSITION UNKNOWN (SOFTWARE ZERO)\r\n");}
                }else four_axis_limits_requeue(&axis_limits,(uint8_t)axis);
            }
        }
        if(limit_waiting_to_query&&(int32_t)(now-limit_query_at)>=0){
            if(start_position_query(POSITION_QUERY_LIMIT,now)){
                limit_waiting_to_query=false;
                debug_uart_log("AXIS LIMIT POSITION QUERY TX\r\n");
            }
        }
        if (!spi_in_flight && (int32_t)(now - next_poll) >= 0 &&
            (servo_command_pending ? io_link_build_servo(&io,servo_target_us,spi_request) :
                                     io_link_build(&io, PROTO_IO_QUERY, spi_request)) &&
            board_spi_master_start(spi_request, now)) {
            io_link_mark_sent(&io);
            servo_command_pending = false;
            spi_in_flight = true;
            next_poll = now + BOARD_SPI_POLL_MS;
        }

        const bool io_fresh_now=io_link_fresh(&io,now,BOARD_LINK_TIMEOUT_MS);
        app_health_t health = {
            .configuration_ok = BOARD_MACHINE_COMMISSIONED ? motion_ready() :
                                (BOARD_COREXY_CONFIG_CONFIRMED != 0),
            /* Manual CoreXY remains usable while IO MCU resets. */
            .io_fresh = BOARD_MACHINE_COMMISSIONED ? io_fresh_now : true,
            .vision_fresh = true, /* Vision is not required until stage-4 WAIT_VISION. */
            .execution_available = false,
            .io_faults = io_link_reported_faults(BOARD_MACHINE_COMMISSIONED != 0,
                                                 io.status_valid,
                                                 io.status.faults)
        };
        const bool start = io.status_valid && (io.status.events & 1U) != 0U;
        const bool stop = io.status_valid && (io.status.active & 2U) != 0U;
        app_state_tick(&app, &health, BOARD_MACHINE_COMMISSIONED && start,
                       stop, false, false, now);
        if (app.stop_requested) (void)motion_stop_all();
        if (reported_state != app.state) {
            reported_state = app.state;
            debug_uart_log(app_state_name(app.state));
            debug_uart_log("\r\n");
        }
        if ((int32_t)(now - next_status) >= 0) {
            protocol_frame_t status = {0};
            uint8_t wire[PROTOCOL_FRAME_SIZE];
            status.type = PROTO_APP_STATUS;
            status.sequence = (uint16_t)(now / 200U);
            status.length = 16;
            status.payload[0] = (uint8_t)app.state;
            status.payload[1] = app_motion_permitted(&app) ? 1U : 0U;
            protocol_write_u32(status.payload + 4, app.faults);
            protocol_write_u32(status.payload + 8, 0U); /* No completed sort in stage 2. */
            protocol_write_u32(status.payload + 12,
                io.status_valid ? (uint32_t)(now - io.last_rx_ms) : UINT32_MAX);
            if (protocol_encode(&status, wire)) {
                (void)board_uart_write(BOARD_UART_VISION, wire, sizeof wire);
            }
            next_status = now + 200U;
        }
        if ((int32_t)(now - next_display) >= 0) {
            master_display_t display;
            master_display_build(&display, io_fresh_now, app.faults);
            OLED_ShowString6x8(1U, 1U, display.title);
            OLED_ShowString6x8(3U, 1U, display.link);
            OLED_ShowString6x8(5U, 1U, display.fault);
            next_display = now + 250U;
        }
        if(!io_report_initialized||reported_io_online!=io_fresh_now){
            reported_io_online=io_fresh_now;io_report_initialized=true;
            debug_uart_log(io_fresh_now ? "IO ONLINE\r\n" : "IO OFFLINE\r\n");
        }
        board_status_led(debug_trigger_led_active(&debug_trigger, now) ||
                         app.state == APP_IDLE);
        __WFI();
    }
}
