#include "sort_manager.h"
/* Invalid calibration placeholders, never usable as actual movement targets. */
const sort_target_t sort_box_targets[6] = {{false,0,0,0},{false,0,0,0},{false,0,0,0},
                                        {false,0,0,0},{false,0,0,0},{false,0,0,0}};
const char *sort_class_name(uint16_t id)
{
    static const char *const names[6] = {"class_0","class_1","class_2","class_3","class_4","class_5"};
    return id < 6U ? names[id] : "unknown";
}
