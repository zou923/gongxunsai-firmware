#include "fault_manager.h"
void fault_manager_raise(fault_manager_t *faults, uint32_t mask, uint32_t now)
{
    if (mask && !faults->latched) faults->first_ms = now;
    faults->latched |= mask;
}
