#include "app_state.h"

static void enter(app_state_t *app, app_state_id_t state, uint32_t now)
{ app->state = state; app->entered_ms = now; }

static uint32_t health_faults(const app_health_t *h)
{
    return (!h->configuration_ok ? MASTER_FAULT_CONFIG : 0U) |
           (!h->io_fresh ? MASTER_FAULT_IO_LINK : 0U) |
           (h->io_faults ? MASTER_FAULT_IO : 0U) |
           (!h->vision_fresh ? MASTER_FAULT_VISION : 0U);
}

void app_state_init(app_state_t *app, uint32_t now)
{
    *app = (app_state_t){APP_INIT, now, 0, false};
}
void app_state_tick(app_state_t *app, const app_health_t *health, bool start,
                    bool stop, bool emergency_stop, bool manual_reset, uint32_t now)
{
    const uint32_t faults = health_faults(health);
    if (emergency_stop) {
        app->faults |= MASTER_FAULT_ESTOP; app->stop_requested = true;
        enter(app, APP_E_STOP, now); return;
    }
    if (app->state == APP_E_STOP || app->state == APP_FAULT || app->state == APP_PAUSED) {
        if (manual_reset && !start && !stop && faults == 0U) {
            app->faults = 0; app->stop_requested = false;
            enter(app, APP_SELF_CHECK, now);
        }
        return;
    }
    if (stop) {
        app->stop_requested = true; enter(app, APP_STOPPING, now); return;
    }
    if (app->state == APP_STOPPING) { enter(app, APP_PAUSED, now); return; }
    if (app->state == APP_INIT) { enter(app, APP_SELF_CHECK, now); return; }
    if (app->state == APP_SELF_CHECK) {
        if (faults == 0U) enter(app, APP_IDLE, now);
        else if ((uint32_t)(now - app->entered_ms) >= 1000U) {
            app->faults |= faults; app->stop_requested = true; enter(app, APP_FAULT, now);
        }
        return;
    }
    if (faults != 0U) {
        app->faults |= faults; app->stop_requested = true; enter(app, APP_FAULT, now); return;
    }
    if (app->state == APP_IDLE && start) {
        /* Stage 3/4 executors do not exist yet. No setting can bypass this gate. */
        app->faults |= MASTER_FAULT_NOT_IMPLEMENTED;
        app->stop_requested = true; enter(app, APP_FAULT, now);
    }
}
/* Stages 1/2 have no motion executor, including in an otherwise healthy system. */
bool app_motion_permitted(const app_state_t *app) { (void)app; return false; }
const char *app_state_name(app_state_id_t state)
{
    static const char *const names[] = {"INIT","SELF_CHECK","IDLE","HOMING","WAIT_VISION",
        "PLAN","MOVE_TO_PICK","GRAB","LIFT","MOVE_TO_CHUTE","SORT","VERIFY","REPORT",
        "NEXT_ITEM","PAUSED","STOPPING","FAULT","E_STOP","FINISHED"};
    return (unsigned)state < sizeof names / sizeof names[0] ? names[state] : "INVALID";
}
