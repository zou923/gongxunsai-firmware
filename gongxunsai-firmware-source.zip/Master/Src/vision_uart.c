#include "vision_uart.h"
#include <string.h>
void vision_receiver_init(vision_receiver_t *r)
{ memset(r, 0, sizeof *r); protocol_stream_init(&r->stream); }
bool vision_receiver_feed(vision_receiver_t *r, uint8_t byte, uint32_t now)
{
    protocol_frame_t f; vision_item_t item;
    if (!protocol_stream_feed(&r->stream, byte, now, &f)) return false;
    if (!vision_decode_item(&f, &item)) { r->rejected++; return false; }
    /* Recognition IDs increase during one session; peer restart requires reset. */
    if (r->has_item && item.recognition_id <= r->item.recognition_id) { r->duplicates++; return false; }
    if (!protocol_seq_accept(f.sequence, &r->last_sequence, &r->sequence_initialized)) {
        r->duplicates++; return false;
    }
    r->item = item; r->has_item = true; r->last_rx_ms = now; return true;
}
