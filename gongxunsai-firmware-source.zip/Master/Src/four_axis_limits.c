#include "four_axis_limits.h"
static const uint16_t masks[4]={0x20U,0x40U,0x04U,0x08U};
void four_axis_limits_init(four_axis_limits_t *l){if(l){l->previous=0U;l->pending_axes=0U;}}
uint16_t four_axis_limit_mask_for_axis(uint8_t axis){return axis<4U?masks[axis]:0U;}
uint8_t four_axis_limit_motor_for_axis(uint8_t axis){return axis<4U?(uint8_t)(axis+1U):0U;}
void four_axis_limits_update(four_axis_limits_t *l,uint16_t active){if(!l)return;for(uint8_t i=0;i<4U;i++)if((active&masks[i])!=0U&&(l->previous&masks[i])==0U)l->pending_axes|=(uint8_t)(1U<<i);l->previous=active;}
int four_axis_limits_pop(four_axis_limits_t *l){if(!l)return -1;for(uint8_t i=0;i<4U;i++)if(l->pending_axes&(1U<<i)){l->pending_axes&=(uint8_t)~(1U<<i);return i;}return -1;}
void four_axis_limits_requeue(four_axis_limits_t *l,uint8_t axis){if(l&&axis<4U)l->pending_axes|=(uint8_t)(1U<<axis);}
