#include "io_spi.h"
#include <string.h>
void io_link_init(io_link_t *link) { memset(link, 0, sizeof *link); link->next_sequence = 1; }
bool io_link_build(const io_link_t *link, uint8_t command, uint8_t wire[32])
{
    if (command != PROTO_IO_QUERY && command != PROTO_IO_SAFE && command != PROTO_IO_RESET) return false;
    protocol_frame_t f = {0}; f.type = command; f.sequence = link->next_sequence;
    return protocol_encode(&f, wire);
}
bool io_link_build_servo(const io_link_t *link, uint16_t pulse_us, uint8_t wire[32])
{
    if (pulse_us != 0u && (pulse_us < 500u || pulse_us > 1100u)) return false;
    protocol_frame_t f = {0};
    f.type = PROTO_IO_SERVO;
    f.sequence = link->next_sequence;
    f.length = 2u;
    protocol_write_u16(f.payload, pulse_us);
    return protocol_encode(&f, wire);
}
void io_link_mark_sent(io_link_t *link)
{
    link->has_previous_request = link->sent_any; link->sent_any = true;
    link->last_sent = link->next_sequence++;
}
bool io_link_accept(io_link_t *link, const uint8_t wire[32], uint32_t now)
{
    protocol_frame_t f;
    if (!protocol_decode(wire, &f) || f.type != PROTO_IO_STATUS || f.length != 22U) {
        link->errors++; return false;
    }
    if (!link->has_previous_request || f.sequence != (uint16_t)(link->last_sent - 1U)) {
        link->replay_errors++; return false;
    }
    io_status_t s;
    s.raw = protocol_read_u16(f.payload); s.active = protocol_read_u16(f.payload + 2);
    s.valid = protocol_read_u16(f.payload + 4); s.events = protocol_read_u16(f.payload + 6);
    s.faults = protocol_read_u32(f.payload + 8); s.outputs = protocol_read_u16(f.payload + 12);
    s.servo_us = protocol_read_u16(f.payload + 14); s.safety_state = f.payload[16];
    s.result = f.payload[17]; s.uptime_ms = protocol_read_u32(f.payload + 18);
    if ((s.raw | s.valid) & ~0x7FU ||
        (s.events & (uint16_t)~(0x7FU | IO_EVENT_DEBUG_LED_TOGGLE)) ||
        (s.active & ~s.valid) || s.outputs ||
        (s.servo_us != 0U && (s.servo_us < 500U || s.servo_us > 1100U))) {
        link->errors++; return false;
    }
    if (!protocol_seq_accept(f.sequence, &link->last_rx, &link->rx_initialized)) {
        link->replay_errors++; return false;
    }
    link->status = s; link->status_valid = true; link->last_rx_ms = now; return true;
}
bool io_link_fresh(const io_link_t *link, uint32_t now, uint32_t timeout_ms)
{ return link->status_valid && (uint32_t)(now - link->last_rx_ms) < timeout_ms; }
uint32_t io_link_reported_faults(bool machine_commissioned, bool status_valid,
                                 uint32_t reported_faults)
{
    return machine_commissioned && status_valid ? reported_faults : 0U;
}
