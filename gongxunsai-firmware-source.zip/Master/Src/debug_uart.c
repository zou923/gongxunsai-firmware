#include "debug_uart.h"
#include "board.h"
#include <string.h>
char debug_last_line[160];
uint32_t debug_dropped_lines;
void debug_uart_log(const char *text)
{
    size_t length = strlen(text);
    if (length >= sizeof debug_last_line) length = sizeof debug_last_line - 1U;
    memcpy(debug_last_line, text, length); debug_last_line[length] = '\0';
    if (!board_uart_write(BOARD_UART_DEBUG, (const uint8_t *)debug_last_line, length)) debug_dropped_lines++;
}
