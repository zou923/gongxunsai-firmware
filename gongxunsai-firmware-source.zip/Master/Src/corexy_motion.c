#include "corexy_motion.h"
#include <limits.h>

static uint32_t magnitude_i64(int64_t value){return (uint32_t)(value<0?-value:value);}
static uint32_t distance_to_pulses(int64_t um,const corexy_config_t *c)
{
    uint64_t value=(uint64_t)(um<0?-um:um)*(uint64_t)c->pulses_per_motor_rev;
    return (uint32_t)((value+c->travel_um_per_motor_rev/2U)/c->travel_um_per_motor_rev);
}
void corexy_init(corexy_motion_t *m,const corexy_config_t *c)
{if(m&&c)*m=(corexy_motion_t){*c,0,0,false};}
void corexy_set_homed(corexy_motion_t *m){if(m){m->x_um=0;m->y_um=0;m->homed=true;}}
void corexy_clear_homed(corexy_motion_t *m){if(m)m->homed=false;}
void corexy_set_position(corexy_motion_t *m,int32_t x,int32_t y)
{if(m){m->x_um=x;m->y_um=y;m->homed=true;}}
int32_t corexy_emm_position_to_um(int64_t origin,int64_t position,uint32_t travel)
{
    const int64_t delta=position-origin;
    const int64_t scaled=delta*(int64_t)travel;
    return (int32_t)(scaled>=0?(scaled+32768)/65536:(scaled-32768)/65536);
}
corexy_result_t corexy_plan_absolute(const corexy_motion_t *m,int32_t x,int32_t y,corexy_plan_t *p)
{
    if(!m||!p||m->config.pulses_per_motor_rev==0U||m->config.travel_um_per_motor_rev==0U||
       m->config.maximum_rpm==0U)return COREXY_INVALID;
    if(!m->homed)return COREXY_NOT_HOMED;
    if(x<0||
       (int64_t)x>(int64_t)m->config.x_max_um||
       y<0||
       (int64_t)y>(int64_t)m->config.y_max_um)return COREXY_OUT_OF_RANGE;
    const int64_t dx=(int64_t)x-m->x_um,dy=(int64_t)y-m->y_um;
    const int64_t a=dx,b=dy;
    const uint32_t am=magnitude_i64(a),bm=magnitude_i64(b),largest=am>bm?am:bm;
    *p=(corexy_plan_t){.target_x_um=x,.target_y_um=y,
        .motor1_pulses=distance_to_pulses(a,&m->config),
        .motor2_pulses=distance_to_pulses(b,&m->config),
        .motor1_ccw=(a<0)^m->config.motor1_invert,
        .motor2_ccw=(b<0)^m->config.motor2_invert};
    if(largest!=0U){
        p->motor1_rpm=am==0U?0U:(uint16_t)(((uint64_t)m->config.maximum_rpm*am+largest-1U)/largest);
        p->motor2_rpm=bm==0U?0U:(uint16_t)(((uint64_t)m->config.maximum_rpm*bm+largest-1U)/largest);
    }
    return COREXY_OK;
}
void corexy_commit(corexy_motion_t *m,const corexy_plan_t *p)
{if(m&&p){m->x_um=p->target_x_um;m->y_um=p->target_y_um;}}
