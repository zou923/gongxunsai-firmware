#include "corexy_command.h"
#include <stddef.h>
#include <string.h>

static void spaces(const char **p){while(**p==' '||**p=='\t')++*p;}
static bool millimetres(const char **p,int32_t *um)
{
    int64_t whole=0,frac=0,scale=100; bool any=false,negative=false;
    spaces(p);if(**p=='-'||**p=='+'){negative=**p=='-';++*p;}
    while(**p>='0'&&**p<='9'){any=true;whole=whole*10+(**p-'0');if(whole>2147483)return false;++*p;}
    if(**p=='.'){
        ++*p;
        for(unsigned digits=0;digits<3U&&**p>='0'&&**p<='9';++digits,++*p){frac+=(**p-'0')*scale;scale/=10;any=true;}
        if(**p>='0'&&**p<='9')return false;
    }
    if(!any)return false;
    int64_t value=whole*1000+frac;if(negative)value=-value;
    *um=(int32_t)value;return true;
}
bool corexy_command_parse(const char *line,corexy_command_t *c)
{
    if(!line||!c)return false;
    *c=(corexy_command_t){0};spaces(&line);
    if(strcmp(line,"ZERO")==0){c->kind=COREXY_CMD_ZERO;return true;}
    if(strcmp(line,"HOME")==0){c->kind=COREXY_CMD_HOME;return true;}
    if(line[0]!='X'||line[1]!='Y'||(line[2]!=' '&&line[2]!='\t'))return false;
    line+=2;if(!millimetres(&line,&c->x_um)||!millimetres(&line,&c->y_um))return false;
    spaces(&line);if(*line!='\0')return false;c->kind=COREXY_CMD_XY;return true;
}
