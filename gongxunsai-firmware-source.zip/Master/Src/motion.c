#include "motion.h"
static bool elapsed(uint32_t now,uint32_t start,uint32_t duration){return (uint32_t)(now-start)>=duration;}
void motion_init(motion_controller_t *m){*m=(motion_controller_t){MOTION_IDLE,MOTION_FAULT_NONE,0U,0U,5000U};}
void motion_set_home_timeout(motion_controller_t *m,uint32_t timeout_ms){m->home_timeout_ms=timeout_ms;}
x42s_result_t motion_start_homing(motion_controller_t *m,uint32_t now_ms)
{
    if(!m)return X42S_INVALID_ARGUMENT;
    x42s_driver_tick(now_ms);
    x42s_result_t r=x42s_home(0U);
    if(r!=X42S_OK)return r;
    m->state=MOTION_HOMING;
    m->fault=MOTION_FAULT_NONE;
    m->homing_axis=0U;
    m->axis_started_ms=now_ms;
    return X42S_OK;
}
void motion_tick(motion_controller_t *m,uint32_t now_ms)
{
    x42s_status_t status;
    if(!m||m->state!=MOTION_HOMING)return;
    x42s_driver_tick(now_ms);
    if(elapsed(now_ms,m->axis_started_ms,m->home_timeout_ms)){(void)motion_stop_all();m->fault=MOTION_FAULT_HOME_TIMEOUT;m->state=MOTION_FAULT;return;}
    if(x42s_get_status(m->homing_axis,&status)!=X42S_OK){m->fault=MOTION_FAULT_DRIVER;m->state=MOTION_FAULT;return;}
    if(status.motion!=X42S_MOTION_IDLE||!status.homed)return;
    ++m->homing_axis; if(m->homing_axis>=X42S_AXIS_COUNT){m->state=MOTION_READY;return;}
    m->axis_started_ms=now_ms;
    if(x42s_home(m->homing_axis)!=X42S_OK){m->fault=MOTION_FAULT_DRIVER;m->state=MOTION_FAULT;}
}
motion_state_t motion_state(const motion_controller_t *m){return m->state;}
motion_fault_t motion_fault(const motion_controller_t *m){return m->fault;}
unsigned motion_homing_axis(const motion_controller_t *m){return m->homing_axis;}
bool motion_ready_controller(const motion_controller_t *m){return m&&m->state==MOTION_READY;}
bool motion_ready(void){return false;}
x42s_result_t motion_stop_all(void)
{
    x42s_result_t result=X42S_OK;
    for(unsigned i=0U;i<X42S_AXIS_COUNT;++i){x42s_result_t r=x42s_stop(i);if(r!=X42S_OK)result=r;}
    return result;
}
