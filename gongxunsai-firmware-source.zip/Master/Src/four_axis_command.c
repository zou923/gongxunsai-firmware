#include "four_axis_command.h"
#include <string.h>
static void skip(const char **p){while(**p==' '||**p=='\t')++*p;}
static bool fixed3(const char **p,int32_t *out,bool allow_negative){
 int64_t whole=0,frac=0,scale=100;bool any=false,neg=false;skip(p);
 if(**p=='+'||**p=='-'){neg=**p=='-';if(neg&&!allow_negative)return false;++*p;}
 while(**p>='0'&&**p<='9'){any=true;whole=whole*10+(**p-'0');if(whole>1000000)return false;++*p;}
 if(**p=='.'){++*p;unsigned d=0;while(d<3&&**p>='0'&&**p<='9'){any=true;frac+=(**p-'0')*scale;scale/=10;++d;++*p;}if(**p>='0'&&**p<='9')return false;}
 if(!any)return false;
 int64_t v=whole*1000+frac;
 if(neg)v=-v;
 if(v>2147483647LL||v<-2147483647LL)return false;
 *out=(int32_t)v;return true;}
bool four_axis_command_parse(const char *line,four_axis_command_t *c){if(!line||!c)return false;*c=(four_axis_command_t){0};skip(&line);
 if(strcmp(line,"STOP3")==0){c->kind=FOUR_AXIS_CMD_STOP3;return true;}if(strcmp(line,"STOP4")==0){c->kind=FOUR_AXIS_CMD_STOP4;return true;}if(strcmp(line,"STOPALL")==0){c->kind=FOUR_AXIS_CMD_STOPALL;return true;}
 if(strncmp(line,"XYZS",4)==0&&(line[4]==' '||line[4]=='\t')){line+=4;for(unsigned i=0;i<4;i++)if(!fixed3(&line,&c->value_um[i],false)||c->value_um[i]>500000)return false;skip(&line);if(*line)return false;c->kind=FOUR_AXIS_CMD_XYZS;return true;}
 if((line[0]=='R')&&(line[1]=='3'||line[1]=='4')&&(line[2]==' '||line[2]=='\t')){char axis=line[1];line+=2;if(!fixed3(&line,&c->turns_milli,true))return false;skip(&line);if(*line||c->turns_milli==0||c->turns_milli>5000||c->turns_milli<-5000)return false;c->kind=axis=='3'?FOUR_AXIS_CMD_R3:FOUR_AXIS_CMD_R4;return true;}
 return false;}
