#include "x42s_protocol.h"
#include <string.h>
static bool begin(uint8_t address,uint8_t *out,size_t cap,size_t need,size_t *length)
{ if(address==0U||!out||!length||cap<need)return false;*length=need;return true; }
static void put16(uint8_t *p,uint16_t v){p[0]=(uint8_t)(v>>8);p[1]=(uint8_t)v;}
static void put32(uint8_t *p,uint32_t v){p[0]=(uint8_t)(v>>24);p[1]=(uint8_t)(v>>16);p[2]=(uint8_t)(v>>8);p[3]=(uint8_t)v;}
static uint32_t get32(const uint8_t *p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static bool query(uint8_t address,uint8_t code,uint8_t *out,size_t cap,size_t *length)
{if(!begin(address,out,cap,3U,length))return false;out[0]=address;out[1]=code;out[2]=X42S_CHECK_FIXED_6B;return true;}
bool x42s_build_query_position(uint8_t a,uint8_t *o,size_t c,size_t *n){return query(a,0x36U,o,c,n);}
bool x42s_build_query_status(uint8_t a,uint8_t *o,size_t c,size_t *n){return query(a,0x3AU,o,c,n);}
bool x42s_build_query_home_status(uint8_t a,uint8_t *o,size_t c,size_t *n){return query(a,0x3BU,o,c,n);}
bool x42s_build_query_combined(uint8_t a,uint8_t *o,size_t c,size_t *n){return query(a,0x3CU,o,c,n);}
bool x42s_build_stop(uint8_t a,bool sync,uint8_t *o,size_t c,size_t *n)
{if(!begin(a,o,c,5U,n))return false;o[0]=a;o[1]=0xFE;o[2]=0x98;o[3]=sync?1U:0U;o[4]=0x6B;return true;}
bool x42s_build_home(uint8_t a,x42s_home_mode_t mode,bool sync,uint8_t *o,size_t c,size_t *n)
{if(mode>X42S_HOME_POWER_LOSS||!begin(a,o,c,5U,n))return false;o[0]=a;o[1]=0x9A;o[2]=(uint8_t)mode;o[3]=sync?1U:0U;o[4]=0x6B;return true;}
bool x42s_build_emm_position(uint8_t a,bool ccw,uint16_t rpm,uint8_t accel,uint32_t pulses,x42s_position_mode_t mode,bool sync,uint8_t *o,size_t c,size_t *n)
{
    if(rpm>3000U||mode>X42S_POSITION_REL_CURRENT||!begin(a,o,c,13U,n))return false;
    o[0]=a;o[1]=0xFD;o[2]=ccw?1U:0U;put16(o+3,rpm);o[5]=accel;put32(o+6,pulses);
    o[10]=(uint8_t)mode;o[11]=sync?1U:0U;o[12]=0x6B;return true;
}
bool x42s_build_emm_velocity(uint8_t a,bool ccw,uint16_t rpm,uint8_t accel,bool sync,uint8_t *o,size_t c,size_t *n)
{
    if(rpm>3000U||!begin(a,o,c,8U,n))return false;
    o[0]=a;o[1]=0xF6U;o[2]=ccw?1U:0U;put16(o+3,rpm);o[5]=accel;
    o[6]=sync?1U:0U;o[7]=0x6BU;return true;
}
bool x42s_build_sync_trigger(uint8_t *o,size_t c,size_t *n)
{
    if(!o||!n||c<4U)return false;
    *n=4U;o[0]=0U;o[1]=0xFFU;o[2]=0x66U;o[3]=0x6BU;return true;
}
bool x42s_build_dual_stop(uint8_t a,uint8_t b,uint8_t *o,size_t c,size_t *n)
{
    size_t n1=0U,n2=0U;
    if(a==0U||b==0U||a==b||!o||!n||c<15U)return false;
    o[0]=0U;o[1]=0xAAU;o[2]=0U;o[3]=15U;
    if(!x42s_build_stop(a,false,o+4U,5U,&n1)||
       !x42s_build_stop(b,false,o+9U,5U,&n2)||n1!=5U||n2!=5U)return false;
    o[14]=0x6BU;*n=15U;return true;
}
bool x42s_build_set_single_turn_zero(uint8_t a,bool store,uint8_t *o,size_t c,size_t *n)
{
    if(!begin(a,o,c,5U,n))return false;
    o[0]=a;o[1]=0x93U;o[2]=0x88U;o[3]=store?1U:0U;o[4]=0x6BU;return true;
}
bool x42s_build_dual_home_nearest(uint8_t a,uint8_t b,uint8_t *o,size_t c,size_t *n)
{
    size_t n1=0U,n2=0U,nt=0U;
    if(a==0U||b==0U||a==b||!o||!n||c<19U)return false;
    o[0]=0U;o[1]=0xAAU;o[2]=0U;o[3]=15U;
    if(!x42s_build_home(a,X42S_HOME_NEAREST,true,o+4U,5U,&n1)||
       !x42s_build_home(b,X42S_HOME_NEAREST,true,o+9U,5U,&n2)||
       n1!=5U||n2!=5U)return false;
    o[14]=0x6BU;
    if(!x42s_build_sync_trigger(o+15U,c-15U,&nt)||nt!=4U)return false;
    *n=19U;return true;
}
bool x42s_build_dual_set_single_turn_zero(uint8_t a,uint8_t b,bool store,uint8_t *o,size_t c,size_t *n)
{
    size_t n1=0U,n2=0U;
    if(a==0U||b==0U||a==b||!o||!n||c<15U)return false;
    o[0]=0U;o[1]=0xAAU;o[2]=0U;o[3]=15U;
    if(!x42s_build_set_single_turn_zero(a,store,o+4U,5U,&n1)||
       !x42s_build_set_single_turn_zero(b,store,o+9U,5U,&n2)||n1!=5U||n2!=5U)return false;
    o[14]=0x6BU;*n=15U;return true;
}
bool x42s_build_dual_emm_position(uint8_t a,bool a_ccw,uint16_t a_rpm,
    uint8_t a_acc,uint32_t a_pulses,uint8_t b,bool b_ccw,uint16_t b_rpm,
    uint8_t b_acc,uint32_t b_pulses,uint8_t *o,size_t c,size_t *n)
{
    size_t n1=0U,n2=0U,nt=0U;
    if(a==0U||b==0U||a==b||!o||!n||c<35U)return false;
    o[0]=0U;o[1]=0xAAU;o[2]=0U;o[3]=31U;
    if(!x42s_build_emm_position(a,a_ccw,a_rpm,a_acc,a_pulses,
        X42S_POSITION_REL_CURRENT,true,o+4U,13U,&n1)||
       !x42s_build_emm_position(b,b_ccw,b_rpm,b_acc,b_pulses,
        X42S_POSITION_REL_CURRENT,true,o+17U,13U,&n2)||
       n1!=13U||n2!=13U)return false;
    o[30]=0x6BU;
    if(!x42s_build_sync_trigger(o+31U,c-31U,&nt)||nt!=4U)return false;
    *n=35U;return true;
}
bool x42s_build_four_position(const x42s_position_request_t r[4],uint8_t *o,size_t c,size_t *n)
{
    size_t part=0U,trigger=0U;
    if(!r||!o||!n||c<61U)return false;
    for(unsigned i=0;i<4U;i++)for(unsigned j=0;j<i;j++)
        if(r[i].address==0U||r[i].address==r[j].address)return false;
    if(r[0].address==0U)return false;
    o[0]=0U;o[1]=0xAAU;o[2]=0U;o[3]=57U;
    for(unsigned i=0;i<4U;i++){
        if(!x42s_build_emm_position(r[i].address,r[i].ccw,r[i].rpm,r[i].acceleration,
            r[i].pulses,X42S_POSITION_REL_CURRENT,true,o+4U+13U*i,13U,&part)||part!=13U)return false;
    }
    o[56]=0x6BU;
    if(!x42s_build_sync_trigger(o+57U,c-57U,&trigger)||trigger!=4U)return false;
    *n=61U;return true;
}
bool x42s_build_stop_many(uint8_t first,uint8_t count,uint8_t *o,size_t c,size_t *n)
{
    size_t part=0U;size_t need=5U+(size_t)count*5U;
    if(first==0U||count==0U||(uint16_t)first+count-1U>255U||!o||!n||c<need)return false;
    o[0]=0U;o[1]=0xAAU;o[2]=0U;o[3]=(uint8_t)need;
    for(uint8_t i=0;i<count;i++)if(!x42s_build_stop((uint8_t)(first+i),false,o+4U+5U*i,5U,&part)||part!=5U)return false;
    o[need-1U]=0x6BU;*n=need;return true;
}
bool x42s_build_x_position(uint8_t a,bool ccw,uint16_t accel,uint16_t decel,uint16_t speed,uint32_t angle,x42s_position_mode_t mode,bool sync,uint8_t *o,size_t c,size_t *n)
{
    if(speed>30000U||mode>X42S_POSITION_REL_CURRENT||!begin(a,o,c,16U,n))return false;
    o[0]=a;o[1]=0xFD;o[2]=ccw?1U:0U;put16(o+3,accel);put16(o+5,decel);put16(o+7,speed);put32(o+9,angle);
    o[13]=(uint8_t)mode;o[14]=sync?1U:0U;o[15]=0x6B;return true;
}
bool x42s_parse_reply(const uint8_t *d,size_t n,x42s_reply_t *r)
{
    if(!d||!r||n<4U||d[0]==0U||d[n-1U]!=0x6B)return false;
    memset(r,0,sizeof *r);r->address=d[0];r->code=d[1];r->kind=X42S_REPLY_UNKNOWN;
    if(d[1]==0x3AU&&n==4U){r->motor_flags=d[2];r->kind=X42S_REPLY_STATUS;return true;}
    if(d[1]==0x3BU&&n==4U){r->home_flags=d[2];r->kind=X42S_REPLY_HOME_STATUS;return true;}
    if(d[1]==0x3CU&&n==5U){r->home_flags=d[2];r->motor_flags=d[3];r->kind=X42S_REPLY_COMBINED;return true;}
    if(n==4U){r->status=d[2];r->accepted=d[2]==0x02U;r->completed=d[2]==0x9FU;r->kind=X42S_REPLY_ACK;return true;}
    if(d[1]==0x36U&&n==8U){int64_t magnitude=(int64_t)get32(d+3);r->position_raw=d[2]?-magnitude:magnitude;r->kind=X42S_REPLY_POSITION;return true;}
    return false;
}
