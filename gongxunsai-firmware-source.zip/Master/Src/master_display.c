#include "master_display.h"
#include <string.h>

static char hex_digit(uint8_t value)
{
    return value < 10u ? (char)('0' + (char)value)
                       : (char)('A' + (char)(value - 10u));
}

void master_display_build(master_display_t *display, bool io_online, uint32_t faults)
{
    static const char prefix[] = "FAULT: ";
    unsigned i;
    if (display == 0) return;
    memcpy(display->title, "MASTER", 7u);
    /* ONLINE is one character shorter; the trailing blank erases the final E
     * left on the OLED after an OFFLINE -> ONLINE transition. */
    strcpy(display->link, io_online ? "IO: ONLINE " : "IO: OFFLINE");
    memcpy(display->fault, prefix, sizeof prefix - 1u);
    for (i = 0u; i < 8u; ++i) {
        display->fault[7u + i] = hex_digit((uint8_t)(faults >> (28u - 4u * i)) & 0x0fu);
    }
    display->fault[15] = '\0';
}
