#include "x42s_driver.h"
#include "board_config.h"

const x42s_axis_t x42s_axes[X42S_AXIS_COUNT] = {
    {BOARD_MOTOR_ID_UNASSIGNED, AXIS_UNKNOWN, 0U, 0U},
    {BOARD_MOTOR_ID_UNASSIGNED, AXIS_UNKNOWN, 0U, 0U},
    {BOARD_MOTOR_ID_UNASSIGNED, AXIS_UNKNOWN, 0U, 0U}
};
typedef struct { x42s_status_t status; int32_t target; uint32_t speed;
    uint32_t acceleration; uint32_t complete_at_ms; uint32_t completion_ms; } simulated_axis_t;
static x42s_mode_t driver_mode;
static uint32_t driver_now_ms;
static simulated_axis_t simulated[X42S_AXIS_COUNT];
static bool valid_axis(unsigned axis) { return axis < X42S_AXIS_COUNT; }
static bool time_reached(uint32_t now, uint32_t deadline) { return (int32_t)(now-deadline)>=0; }
static x42s_result_t command_gate(unsigned axis)
{
    if (!valid_axis(axis)) return X42S_INVALID_ARGUMENT;
    if (driver_mode != X42S_MODE_SIMULATED) return X42S_PROTOCOL_UNAVAILABLE;
    if (simulated[axis].status.motion == X42S_MOTION_FAULT) return X42S_DRIVER_FAULT;
    return X42S_OK;
}
void x42s_driver_init(x42s_mode_t mode)
{
    driver_mode=mode; driver_now_ms=0U;
    for(unsigned i=0U;i<X42S_AXIS_COUNT;++i){
        simulated[i]=(simulated_axis_t){0};
        simulated[i].status.motion=X42S_MOTION_IDLE;
        simulated[i].completion_ms=50U;
    }
}
void x42s_driver_tick(uint32_t now_ms)
{
    driver_now_ms=now_ms;
    if(driver_mode!=X42S_MODE_SIMULATED)return;
    for(unsigned i=0U;i<X42S_AXIS_COUNT;++i){
        simulated_axis_t *a=&simulated[i];
        if((a->status.motion==X42S_MOTION_MOVING||a->status.motion==X42S_MOTION_HOMING)&&time_reached(now_ms,a->complete_at_ms)){
            if(a->status.motion==X42S_MOTION_HOMING)a->status.homed=true;
            a->status.position=a->target; a->status.motion=X42S_MOTION_IDLE;
        }
    }
}
x42s_mode_t x42s_driver_mode(void){return driver_mode;}
x42s_result_t x42s_set_parameters(unsigned axis,uint32_t speed,uint32_t acceleration)
{
    x42s_result_t r=command_gate(axis); if(r!=X42S_OK)return r;
    if(speed==0U||acceleration==0U)return X42S_INVALID_ARGUMENT;
    simulated[axis].speed=speed; simulated[axis].acceleration=acceleration; return X42S_OK;
}
x42s_result_t x42s_move(unsigned axis,int32_t position,int relative)
{
    x42s_result_t r=command_gate(axis); if(r!=X42S_OK)return r;
    if(simulated[axis].status.motion!=X42S_MOTION_IDLE)return X42S_BUSY;
    simulated[axis].target=relative?simulated[axis].status.position+position:position;
    simulated[axis].status.motion=X42S_MOTION_MOVING;
    simulated[axis].complete_at_ms=driver_now_ms+simulated[axis].completion_ms; return X42S_OK;
}
x42s_result_t x42s_home(unsigned axis)
{
    x42s_result_t r=command_gate(axis); if(r!=X42S_OK)return r;
    if(simulated[axis].status.motion!=X42S_MOTION_IDLE)return X42S_BUSY;
    simulated[axis].status.homed=false; simulated[axis].target=0;
    simulated[axis].status.motion=X42S_MOTION_HOMING;
    simulated[axis].complete_at_ms=driver_now_ms+simulated[axis].completion_ms; return X42S_OK;
}
x42s_result_t x42s_stop(unsigned axis)
{
    x42s_result_t r=command_gate(axis); if(r!=X42S_OK)return r;
    simulated[axis].target=simulated[axis].status.position;
    simulated[axis].status.motion=X42S_MOTION_STOPPED; return X42S_OK;
}
x42s_result_t x42s_query(unsigned axis){return command_gate(axis);}
x42s_result_t x42s_get_status(unsigned axis,x42s_status_t *status)
{
    if(!status||!valid_axis(axis))return X42S_INVALID_ARGUMENT;
    if(driver_mode!=X42S_MODE_SIMULATED)return X42S_PROTOCOL_UNAVAILABLE;
    *status=simulated[axis].status; return X42S_OK;
}
void x42s_sim_set_completion_ms(unsigned axis,uint32_t completion_ms)
{if(valid_axis(axis)&&driver_mode==X42S_MODE_SIMULATED)simulated[axis].completion_ms=completion_ms;}
