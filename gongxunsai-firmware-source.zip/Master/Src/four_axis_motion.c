#include "four_axis_motion.h"
#include <string.h>
#define X_AXIS_DIRECTION_INVERT 1U
#define Y_AXIS_DIRECTION_INVERT 1U
#define Z_AXIS_DIRECTION_INVERT 1U
#define PPR 12800U
#define TRAVEL_UM 40000U
#define MAX_X_UM 222000
#define MAX_Y_UM 208000
#define MAX_Z_UM 500000
#define MAX_S_UM 500000
#define MAX_RPM 60U
void four_axis_init(four_axis_motion_t *m){if(m)memset(m,0,sizeof *m);}void four_axis_set_zero(four_axis_motion_t *m){if(m){memset(m->position_um,0,sizeof m->position_um);m->homed=true;}}void four_axis_clear_zero(four_axis_motion_t *m){if(m)m->homed=false;}
four_axis_result_t four_axis_plan_absolute(const four_axis_motion_t *m,const int32_t t[4],four_axis_plan_t *p){if(!m||!t||!p)return FOUR_AXIS_INVALID;if(!m->homed)return FOUR_AXIS_NOT_HOMED;uint32_t dist[4],largest=0;memset(p,0,sizeof *p);
 const int32_t max_um[4]={MAX_X_UM,MAX_Y_UM,MAX_Z_UM,MAX_S_UM};
 for(unsigned i=0;i<4;i++){if(t[i]<0||t[i]>max_um[i])return FOUR_AXIS_OUT_OF_RANGE;int64_t d=(int64_t)t[i]-m->position_um[i];uint64_t mag=(uint64_t)(d<0?-d:d);dist[i]=(uint32_t)mag;if(dist[i]>largest)largest=dist[i];p->target_um[i]=t[i];p->axis[i].ccw=(d<0)^((i==0U)&&(X_AXIS_DIRECTION_INVERT!=0))^((i==1U)&&(Y_AXIS_DIRECTION_INVERT!=0))^((i==2U)&&(Z_AXIS_DIRECTION_INVERT!=0));p->axis[i].pulses=(uint32_t)((mag*PPR+TRAVEL_UM/2U)/TRAVEL_UM);}
 if(largest){
  for(unsigned i=0;i<4;i++)if(dist[i])
   p->axis[i].rpm=(uint16_t)(((uint64_t)MAX_RPM*dist[i]+largest-1U)/largest);
 }
 return FOUR_AXIS_OK;}
void four_axis_commit(four_axis_motion_t *m,const four_axis_plan_t *p){if(m&&p)memcpy(m->position_um,p->target_um,sizeof m->position_um);}
