#ifndef X42S_DRIVER_H
#define X42S_DRIVER_H
#include <stdbool.h>
#include <stdint.h>
#define X42S_AXIS_COUNT 3U
typedef enum { X42S_OK=0, X42S_BUSY=1, X42S_UNCONFIGURED=-1,
    X42S_NOT_IMPLEMENTED=-2, X42S_INVALID_ARGUMENT=-3,
    X42S_PROTOCOL_UNAVAILABLE=-4, X42S_DRIVER_FAULT=-5 } x42s_result_t;
typedef enum { AXIS_UNKNOWN, AXIS_X, AXIS_Y, AXIS_Z, AXIS_CHUTE } axis_role_t;
typedef enum { X42S_MODE_HARDWARE_LOCKED, X42S_MODE_SIMULATED } x42s_mode_t;
typedef enum { X42S_MOTION_IDLE, X42S_MOTION_MOVING, X42S_MOTION_HOMING,
    X42S_MOTION_STOPPED, X42S_MOTION_FAULT } x42s_motion_t;
typedef struct { uint8_t id; axis_role_t role; uint32_t max_speed, acceleration; } x42s_axis_t;
typedef struct { x42s_motion_t motion; int32_t position; bool homed; uint32_t error; } x42s_status_t;
extern const x42s_axis_t x42s_axes[X42S_AXIS_COUNT];
void x42s_driver_init(x42s_mode_t mode);
void x42s_driver_tick(uint32_t now_ms);
x42s_mode_t x42s_driver_mode(void);
x42s_result_t x42s_set_parameters(unsigned axis, uint32_t speed, uint32_t acceleration);
x42s_result_t x42s_move(unsigned axis, int32_t position, int relative);
x42s_result_t x42s_home(unsigned axis);
x42s_result_t x42s_stop(unsigned axis);
x42s_result_t x42s_query(unsigned axis);
x42s_result_t x42s_get_status(unsigned axis, x42s_status_t *status);
/* Simulation-only control. No USART bytes are emitted. */
void x42s_sim_set_completion_ms(unsigned axis, uint32_t completion_ms);
#endif
