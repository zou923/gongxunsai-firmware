#ifndef FOUR_AXIS_ZERO_H
#define FOUR_AXIS_ZERO_H
#include <stdbool.h>
#include <stdint.h>
typedef struct {int64_t pending[4];uint8_t next;bool active;bool failed;} four_axis_zero_t;
void four_axis_zero_init(four_axis_zero_t *z);void four_axis_zero_begin(four_axis_zero_t *z,uint32_t now);
uint8_t four_axis_zero_expected_address(const four_axis_zero_t *z);bool four_axis_zero_accept(four_axis_zero_t *z,uint8_t address,int64_t raw);
void four_axis_zero_timeout(four_axis_zero_t *z);bool four_axis_zero_failed(const four_axis_zero_t *z);bool four_axis_zero_commit(four_axis_zero_t *z,int64_t origins[4]);
#endif
