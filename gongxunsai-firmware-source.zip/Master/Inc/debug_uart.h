#ifndef SORTER_DEBUG_UART_H
#define SORTER_DEBUG_UART_H
#include <stdint.h>
extern char debug_last_line[160];
extern uint32_t debug_dropped_lines;
void debug_uart_log(const char *text);
#endif
