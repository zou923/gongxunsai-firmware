#ifndef X42S_PROTOCOL_H
#define X42S_PROTOCOL_H
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#define X42S_FRAME_MAX 18U
#define X42S_CHECK_FIXED_6B 0x6BU
typedef enum { X42S_HOME_NEAREST=0, X42S_HOME_DIRECTION=1, X42S_HOME_COLLISION=2,
    X42S_HOME_LIMIT=3, X42S_HOME_ABSOLUTE_ZERO=4, X42S_HOME_POWER_LOSS=5 } x42s_home_mode_t;
typedef enum { X42S_POSITION_REL_TARGET=0, X42S_POSITION_ABSOLUTE=1,
    X42S_POSITION_REL_CURRENT=2 } x42s_position_mode_t;
typedef enum { X42S_REPLY_ACK, X42S_REPLY_POSITION, X42S_REPLY_STATUS,
    X42S_REPLY_HOME_STATUS, X42S_REPLY_COMBINED, X42S_REPLY_UNKNOWN } x42s_reply_kind_t;
typedef struct { x42s_reply_kind_t kind; uint8_t address,code,status;
    bool accepted,completed; int64_t position_raw; uint8_t home_flags,motor_flags; } x42s_reply_t;
typedef struct {uint8_t address;bool ccw;uint16_t rpm;uint8_t acceleration;uint32_t pulses;} x42s_position_request_t;
bool x42s_build_query_position(uint8_t address,uint8_t *out,size_t cap,size_t *length);
bool x42s_build_query_status(uint8_t address,uint8_t *out,size_t cap,size_t *length);
bool x42s_build_query_home_status(uint8_t address,uint8_t *out,size_t cap,size_t *length);
bool x42s_build_query_combined(uint8_t address,uint8_t *out,size_t cap,size_t *length);
bool x42s_build_stop(uint8_t address,bool synchronized,uint8_t *out,size_t cap,size_t *length);
bool x42s_build_home(uint8_t address,x42s_home_mode_t mode,bool synchronized,uint8_t *out,size_t cap,size_t *length);
bool x42s_build_emm_position(uint8_t address,bool ccw,uint16_t rpm,uint8_t acceleration,
    uint32_t pulses,x42s_position_mode_t mode,bool synchronized,uint8_t *out,size_t cap,size_t *length);
bool x42s_build_emm_velocity(uint8_t address,bool ccw,uint16_t rpm,uint8_t acceleration,
    bool synchronized,uint8_t *out,size_t cap,size_t *length);
bool x42s_build_sync_trigger(uint8_t *out,size_t cap,size_t *length);
bool x42s_build_dual_stop(uint8_t first_address,uint8_t second_address,
    uint8_t *out,size_t cap,size_t *length);
bool x42s_build_set_single_turn_zero(uint8_t address,bool store,
    uint8_t *out,size_t cap,size_t *length);
bool x42s_build_dual_home_nearest(uint8_t first_address,uint8_t second_address,
    uint8_t *out,size_t cap,size_t *length);
bool x42s_build_dual_set_single_turn_zero(uint8_t first_address,uint8_t second_address,
    bool store,uint8_t *out,size_t cap,size_t *length);
bool x42s_build_dual_emm_position(uint8_t first_address,bool first_ccw,
    uint16_t first_rpm,uint8_t acceleration,uint32_t first_pulses,
    uint8_t second_address,bool second_ccw,uint16_t second_rpm,
    uint8_t second_acceleration,uint32_t second_pulses,
    uint8_t *out,size_t cap,size_t *length);
bool x42s_build_four_position(const x42s_position_request_t request[4],uint8_t *out,size_t cap,size_t *length);
bool x42s_build_stop_many(uint8_t first_address,uint8_t count,uint8_t *out,size_t cap,size_t *length);
bool x42s_build_x_position(uint8_t address,bool ccw,uint16_t accel,uint16_t decel,
    uint16_t speed_tenth_rpm,uint32_t angle_tenth_deg,x42s_position_mode_t mode,
    bool synchronized,uint8_t *out,size_t cap,size_t *length);
bool x42s_parse_reply(const uint8_t *data,size_t length,x42s_reply_t *reply);
#endif
