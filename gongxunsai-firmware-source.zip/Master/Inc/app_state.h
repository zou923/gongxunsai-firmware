#ifndef MASTER_APP_STATE_H
#define MASTER_APP_STATE_H
#include <stdbool.h>
#include <stdint.h>
typedef enum {
    APP_INIT, APP_SELF_CHECK, APP_IDLE, APP_HOMING, APP_WAIT_VISION, APP_PLAN,
    APP_MOVE_TO_PICK, APP_GRAB, APP_LIFT, APP_MOVE_TO_CHUTE, APP_SORT,
    APP_VERIFY, APP_REPORT, APP_NEXT_ITEM, APP_PAUSED, APP_STOPPING,
    APP_FAULT, APP_E_STOP, APP_FINISHED
} app_state_id_t;
enum { MASTER_FAULT_CONFIG=1U, MASTER_FAULT_IO_LINK=2U, MASTER_FAULT_IO=4U,
       MASTER_FAULT_NOT_IMPLEMENTED=8U, MASTER_FAULT_VISION=16U,
       MASTER_FAULT_TRANSPORT=32U, MASTER_FAULT_ESTOP=64U };
typedef struct {
    bool configuration_ok, io_fresh, vision_fresh, execution_available;
    uint32_t io_faults;
} app_health_t;
typedef struct { app_state_id_t state; uint32_t entered_ms, faults; bool stop_requested; } app_state_t;
void app_state_init(app_state_t *app, uint32_t now);
void app_state_tick(app_state_t *app, const app_health_t *health, bool start,
                    bool stop, bool emergency_stop, bool manual_reset, uint32_t now);
bool app_motion_permitted(const app_state_t *app);
const char *app_state_name(app_state_id_t state);
#endif
