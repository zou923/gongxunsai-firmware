#ifndef MASTER_VISION_UART_H
#define MASTER_VISION_UART_H
#include "protocol.h"
#include "vision_protocol.h"
typedef struct {
    protocol_stream_t stream;
    vision_item_t item;
    uint16_t last_sequence;
    bool sequence_initialized, has_item;
    uint32_t last_rx_ms, rejected, duplicates;
} vision_receiver_t;
void vision_receiver_init(vision_receiver_t *receiver);
bool vision_receiver_feed(vision_receiver_t *receiver, uint8_t byte, uint32_t now);
#endif
