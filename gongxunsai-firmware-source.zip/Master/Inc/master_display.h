#ifndef MASTER_DISPLAY_H
#define MASTER_DISPLAY_H
#include <stdbool.h>
#include <stdint.h>
typedef struct {
    char title[7];
    char link[12];
    char fault[16];
} master_display_t;
void master_display_build(master_display_t *display, bool io_online, uint32_t faults);
#endif
