#ifndef SORTER_FAULT_MANAGER_H
#define SORTER_FAULT_MANAGER_H
#include <stdint.h>
typedef struct { uint32_t latched, first_ms; } fault_manager_t;
void fault_manager_raise(fault_manager_t *faults, uint32_t mask, uint32_t now);
#endif
