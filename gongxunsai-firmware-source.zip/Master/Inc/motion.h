#ifndef SORTER_MOTION_H
#define SORTER_MOTION_H
#include <stdbool.h>
#include <stdint.h>
#include "x42s_driver.h"
typedef enum { MOTION_IDLE, MOTION_HOMING, MOTION_READY, MOTION_STOPPING, MOTION_FAULT } motion_state_t;
typedef enum { MOTION_FAULT_NONE, MOTION_FAULT_DRIVER, MOTION_FAULT_HOME_TIMEOUT } motion_fault_t;
typedef struct { motion_state_t state; motion_fault_t fault; unsigned homing_axis;
    uint32_t axis_started_ms; uint32_t home_timeout_ms; } motion_controller_t;
void motion_init(motion_controller_t *motion);
void motion_set_home_timeout(motion_controller_t *motion,uint32_t timeout_ms);
x42s_result_t motion_start_homing(motion_controller_t *motion,uint32_t now_ms);
void motion_tick(motion_controller_t *motion,uint32_t now_ms);
motion_state_t motion_state(const motion_controller_t *motion);
motion_fault_t motion_fault(const motion_controller_t *motion);
unsigned motion_homing_axis(const motion_controller_t *motion);
bool motion_ready_controller(const motion_controller_t *motion);
bool motion_ready(void);
x42s_result_t motion_stop_all(void);
#endif
