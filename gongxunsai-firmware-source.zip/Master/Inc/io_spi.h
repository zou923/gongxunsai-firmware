#ifndef MASTER_IO_SPI_H
#define MASTER_IO_SPI_H
#include "protocol.h"
#include <stdbool.h>
#include <stdint.h>
typedef struct {
    uint16_t raw, active, valid, events, outputs, servo_us;
    uint32_t faults, uptime_ms;
    uint8_t safety_state, result;
} io_status_t;
typedef struct {
    io_status_t status;
    uint16_t next_sequence, last_sent, last_rx;
    bool rx_initialized, has_previous_request, sent_any, status_valid;
    uint32_t last_rx_ms, errors, replay_errors;
} io_link_t;
void io_link_init(io_link_t *link);
bool io_link_build(const io_link_t *link, uint8_t command, uint8_t wire[32]);
bool io_link_build_servo(const io_link_t *link, uint16_t pulse_us, uint8_t wire[32]);
void io_link_mark_sent(io_link_t *link);
bool io_link_accept(io_link_t *link, const uint8_t wire[32], uint32_t now);
bool io_link_fresh(const io_link_t *link, uint32_t now, uint32_t timeout_ms);
uint32_t io_link_reported_faults(bool machine_commissioned, bool status_valid,
                                 uint32_t reported_faults);
#endif
