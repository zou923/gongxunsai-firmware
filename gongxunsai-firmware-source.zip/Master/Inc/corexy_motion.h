#ifndef COREXY_MOTION_H
#define COREXY_MOTION_H
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    uint32_t pulses_per_motor_rev;
    uint32_t travel_um_per_motor_rev;
    uint16_t maximum_rpm;
    uint8_t acceleration;
    int32_t x_max_um;
    int32_t y_max_um;
    bool motor1_invert;
    bool motor2_invert;
} corexy_config_t;

typedef struct { corexy_config_t config; int32_t x_um,y_um; bool homed; } corexy_motion_t;
typedef struct {
    int32_t target_x_um,target_y_um;
    uint32_t motor1_pulses,motor2_pulses;
    uint16_t motor1_rpm,motor2_rpm;
    bool motor1_ccw,motor2_ccw;
} corexy_plan_t;
typedef enum { COREXY_OK,COREXY_INVALID,COREXY_NOT_HOMED,COREXY_OUT_OF_RANGE } corexy_result_t;

void corexy_init(corexy_motion_t *motion,const corexy_config_t *config);
void corexy_set_homed(corexy_motion_t *motion);
void corexy_clear_homed(corexy_motion_t *motion);
void corexy_set_position(corexy_motion_t *motion,int32_t x_um,int32_t y_um);
int32_t corexy_emm_position_to_um(int64_t origin_raw,int64_t position_raw,
    uint32_t travel_um_per_rev);
corexy_result_t corexy_plan_absolute(const corexy_motion_t *motion,int32_t x_um,
    int32_t y_um,corexy_plan_t *plan);
void corexy_commit(corexy_motion_t *motion,const corexy_plan_t *plan);
#endif
