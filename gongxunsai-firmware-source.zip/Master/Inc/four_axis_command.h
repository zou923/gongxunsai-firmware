#ifndef FOUR_AXIS_COMMAND_H
#define FOUR_AXIS_COMMAND_H
#include <stdbool.h>
#include <stdint.h>
typedef enum { FOUR_AXIS_CMD_NONE,FOUR_AXIS_CMD_XYZS,FOUR_AXIS_CMD_R3,FOUR_AXIS_CMD_R4,
 FOUR_AXIS_CMD_STOP3,FOUR_AXIS_CMD_STOP4,FOUR_AXIS_CMD_STOPALL } four_axis_command_kind_t;
typedef struct { four_axis_command_kind_t kind; int32_t value_um[4]; int32_t turns_milli; } four_axis_command_t;
bool four_axis_command_parse(const char *line,four_axis_command_t *command);
#endif
