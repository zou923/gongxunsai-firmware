#ifndef COREXY_COMMAND_H
#define COREXY_COMMAND_H
#include <stdbool.h>
#include <stdint.h>
typedef enum { COREXY_CMD_NONE,COREXY_CMD_ZERO,COREXY_CMD_HOME,COREXY_CMD_XY } corexy_command_kind_t;
typedef struct { corexy_command_kind_t kind; int32_t x_um,y_um; } corexy_command_t;
bool corexy_command_parse(const char *line,corexy_command_t *command);
#endif
