#ifndef FOUR_AXIS_MOTION_H
#define FOUR_AXIS_MOTION_H
#include <stdbool.h>
#include <stdint.h>
#define FOUR_AXIS_COUNT 4U
typedef struct {uint32_t pulses;uint16_t rpm;bool ccw;} four_axis_move_t;
typedef struct {int32_t target_um[4];four_axis_move_t axis[4];} four_axis_plan_t;
typedef struct {int32_t position_um[4];bool homed;} four_axis_motion_t;
typedef enum {FOUR_AXIS_OK,FOUR_AXIS_INVALID,FOUR_AXIS_NOT_HOMED,FOUR_AXIS_OUT_OF_RANGE} four_axis_result_t;
void four_axis_init(four_axis_motion_t *motion);void four_axis_set_zero(four_axis_motion_t *motion);void four_axis_clear_zero(four_axis_motion_t *motion);
four_axis_result_t four_axis_plan_absolute(const four_axis_motion_t *motion,const int32_t target_um[4],four_axis_plan_t *plan);
void four_axis_commit(four_axis_motion_t *motion,const four_axis_plan_t *plan);
#endif
