#ifndef FOUR_AXIS_LIMITS_H
#define FOUR_AXIS_LIMITS_H
#include <stdint.h>
typedef struct {uint16_t previous;uint8_t pending_axes;} four_axis_limits_t;
void four_axis_limits_init(four_axis_limits_t *limits);
uint16_t four_axis_limit_mask_for_axis(uint8_t axis);
uint8_t four_axis_limit_motor_for_axis(uint8_t axis);
void four_axis_limits_update(four_axis_limits_t *limits,uint16_t active_inputs);
int four_axis_limits_pop(four_axis_limits_t *limits);
void four_axis_limits_requeue(four_axis_limits_t *limits,uint8_t axis);
#endif
