#ifndef SORT_MANAGER_H
#define SORT_MANAGER_H
#include "vision_protocol.h"
typedef struct { vision_item_t vision; const char *name; uint8_t sort_status; } material_t;
typedef struct { bool calibrated; int32_t x_um, y_um, mechanism_position; } sort_target_t;
extern const sort_target_t sort_box_targets[6];
const char *sort_class_name(uint16_t class_id);
#endif
