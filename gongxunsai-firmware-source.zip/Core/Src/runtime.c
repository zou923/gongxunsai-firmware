/* Newlib calls _init from __libc_init_array; no CRT startup is linked. */
void _init(void)
{
}
