# Open commissioning items

Software behavior currently configured in source:

- [x] CoreXY motor directions inverted for the installed axis orientation.
- [x] XY software travel limits set to X=222 mm and Y=208 mm.
- [x] CN3/PA1 rising assertion sends a stop to motor 3 and establishes software Z=0.
- [x] Gripper command pulse range limited to 500–1100 us.

Before relying on this firmware for unattended motion:

- [ ] Verify the X42S firmware variant, motor addresses, checksum/reply settings, baud rate, microstep setting, and actual wiring against each driver.
- [ ] Measure real XY/Z/S travel and ensure the configured software bounds leave mechanical margin.
- [ ] Verify every limit switch polarity, cable-fault behavior, debounce, and axis mapping; software limits do not replace a hardware emergency stop.
- [ ] Confirm the Z reference switch stops safely at the desired physical point and remains repeatable after power cycling.
- [ ] Tune motor speed/acceleration, servo endpoints, and the gripper's mechanical clearance on the assembled mechanism.
- [ ] Validate visual coordinates, item classes, and pick/place sequence with the perception team.
- [ ] Document the board revision, wiring, driver parameters, and reproducible full-system test results.

Do not infer that a serial acknowledgement proves motion completed. In particular, `SERVO FORWARD QUEUED` means the request entered the forwarding path, not that the gripper reached its target.
