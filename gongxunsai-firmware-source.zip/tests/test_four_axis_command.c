#include "four_axis_command.h"
#include <assert.h>
#include <stdio.h>
int main(void){four_axis_command_t c;
 assert(four_axis_command_parse("XYZS 1 2.5 3.125 500",&c)&&c.kind==FOUR_AXIS_CMD_XYZS&&c.value_um[1]==2500&&c.value_um[3]==500000);
 assert(!four_axis_command_parse("XYZS -1 2 3 4",&c)); assert(!four_axis_command_parse("XYZS 1 2 3 501",&c));
 assert(!four_axis_command_parse("XYZS 1 2 3",&c)); assert(!four_axis_command_parse("XYZS 1 2 3 4 5",&c));
 assert(four_axis_command_parse("R3 -0.500",&c)&&c.kind==FOUR_AXIS_CMD_R3&&c.turns_milli==-500);
 assert(four_axis_command_parse("R4 5",&c)&&c.kind==FOUR_AXIS_CMD_R4&&c.turns_milli==5000);
 assert(!four_axis_command_parse("R3 0",&c)); assert(!four_axis_command_parse("R4 5.001",&c));
 assert(four_axis_command_parse("STOP3",&c)&&c.kind==FOUR_AXIS_CMD_STOP3);
 assert(four_axis_command_parse("STOP4",&c)&&c.kind==FOUR_AXIS_CMD_STOP4);
 assert(four_axis_command_parse("STOPALL",&c)&&c.kind==FOUR_AXIS_CMD_STOPALL);
 assert(!four_axis_command_parse("STOPALL x",&c)); puts("four-axis commands: PASS"); return 0;}
