#include "servo_command.h"
#include <assert.h>
#include <stdio.h>

static bool send(servo_command_t *parser, const char *text, uint16_t *pulse)
{
    bool ready = false;
    while (*text != '\0') ready |= servo_command_feed(parser, (uint8_t)*text++, pulse);
    return ready;
}

int main(void)
{
    servo_command_t parser;
    uint16_t pulse = 999u;
    servo_command_init(&parser);
    assert(!servo_command_active(&parser));
    assert(!servo_command_feed(&parser, 'P', &pulse));
    assert(servo_command_active(&parser));
    servo_command_init(&parser);
    assert(send(&parser, "P0800", &pulse) && pulse == 800u);
    assert(!servo_command_active(&parser));
    assert(send(&parser, "\r\nP0500\n", &pulse) && pulse == 500u);
    assert(send(&parser, "P1100", &pulse) && pulse == 1100u);
    assert(send(&parser, "P0000", &pulse) && pulse == 0u);
    assert(!send(&parser, "P0499", &pulse));
    assert(!send(&parser, "P1101", &pulse));
    assert(!send(&parser, "P2500", &pulse));
    assert(!send(&parser, "X1500", &pulse));
    assert(send(&parser, "noiseP0750", &pulse) && pulse == 750u);
    assert(servo_output_permitted(1400u,false,false));
    assert(!servo_output_permitted(1400u,false,true));
    assert(servo_output_permitted(1400u,true,true));
    assert(!servo_output_permitted(0u,true,false));
    assert(servo_slew_step(500u,1100u,5u)==505u);
    assert(servo_slew_step(1100u,500u,5u)==1095u);
    assert(servo_slew_step(1098u,1100u,5u)==1100u);
    puts("servo command: P0500..P1100 and P0000 PASS");
    return 0;
}
