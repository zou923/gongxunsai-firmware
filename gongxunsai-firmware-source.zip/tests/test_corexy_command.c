#include "corexy_command.h"
#include <assert.h>
#include <stdio.h>
int main(void)
{
    corexy_command_t c;
    assert(corexy_command_parse("ZERO",&c)&&c.kind==COREXY_CMD_ZERO);
    assert(corexy_command_parse("HOME",&c)&&c.kind==COREXY_CMD_HOME);
    assert(corexy_command_parse("XY 100 50",&c)&&c.kind==COREXY_CMD_XY&&c.x_um==100000&&c.y_um==50000);
    assert(corexy_command_parse("XY 12.345 6.7",&c)&&c.x_um==12345&&c.y_um==6700);
    assert(!corexy_command_parse("XY 1.2345 2",&c));
    assert(!corexy_command_parse("XY 1",&c));
    puts("corexy serial commands: PASS");return 0;
}
