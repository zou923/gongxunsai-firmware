#include "vision_protocol.h"

#include <limits.h>
#include <stdio.h>
#include <string.h>

#define CHECK(condition) do { \
    if (!(condition)) { \
        fprintf(stderr, "%s:%d: %s\n", __FILE__, __LINE__, #condition); \
        return 1; \
    } \
} while (0)

int main(void)
{
    /* Independent fixture: id 0x12345678, class 5, x -1000, y 2000, 1000/1000, status 2. */
    const uint8_t payload[17] = {
        0x78, 0x56, 0x34, 0x12, 0x05, 0,
        0x18, 0xFC, 0xFF, 0xFF, 0xD0, 0x07, 0, 0, 0xE8, 0x03, 0x02
    };
    protocol_frame_t frame = {0};
    protocol_frame_t encoded;
    vision_item_t item;
    vision_item_t before;
    uint8_t bytes[32];
    size_t i;
    frame.type = PROTO_VISION_ITEM;
    frame.length = VISION_ITEM_PAYLOAD_SIZE;
    frame.sequence = 0x3456;
    memcpy(frame.payload, payload, sizeof(payload));
    CHECK(vision_decode_item(&frame, &item));
    CHECK(item.recognition_id == 0x12345678 && item.class_id == 5);
    CHECK(item.x_um == -1000 && item.y_um == 2000);
    CHECK(item.confidence_permille == 1000 && item.recognition_status == 2);
    CHECK(vision_encode_item(&item, 0x3456, &encoded));
    CHECK(encoded.type == PROTO_VISION_ITEM && encoded.sequence == 0x3456);
    CHECK(encoded.length == 17 && encoded.flags == 0);
    CHECK(memcmp(encoded.payload, payload, 17) == 0);
    for (i = 17; i < sizeof(encoded.payload); ++i) CHECK(encoded.payload[i] == 0);

    /* Full wire path must preserve signed two's-complement boundary values. */
    item.x_um = INT32_MIN;
    item.y_um = INT32_MAX;
    item.class_id = 0;
    item.confidence_permille = 0;
    item.recognition_status = 0;
    CHECK(vision_encode_item(&item, 65535, &encoded));
    CHECK(protocol_encode(&encoded, bytes));
    CHECK(protocol_decode(bytes, &encoded));
    CHECK(vision_decode_item(&encoded, &item));
    CHECK(item.x_um == INT32_MIN && item.y_um == INT32_MAX);
    CHECK(item.class_id == 0 && item.confidence_permille == 0 && item.recognition_status == 0);

    memset(&item, 0xC3, sizeof(item));
    before = item;
    for (i = 0; i < 7; ++i) {
        protocol_frame_t invalid = frame;
        switch (i) {
        case 0: invalid.type = PROTO_IO_STATUS; break;
        case 1: invalid.length = 16; break;
        case 2: invalid.length = 18; break;
        case 3: invalid.payload[4] = 6; break;
        case 4: invalid.payload[14] = 0xE9; break;
        case 5: invalid.payload[16] = 3; break;
        default: invalid.flags = 1; break;
        }
        CHECK(!vision_decode_item(&invalid, &item));
        CHECK(memcmp(&item, &before, sizeof(item)) == 0);
    }
    CHECK(!vision_decode_item(NULL, &item));
    CHECK(!vision_decode_item(&frame, NULL));
    CHECK(!vision_encode_item(NULL, 0, &encoded));
    CHECK(!vision_encode_item(&item, 0, NULL));
    CHECK(vision_decode_item(&frame, &item));
    item.class_id = 6;
    CHECK(!vision_encode_item(&item, 0, &encoded));
    item.class_id = 5;
    item.confidence_permille = 1001;
    CHECK(!vision_encode_item(&item, 0, &encoded));
    item.confidence_permille = 1000;
    item.recognition_status = 3;
    CHECK(!vision_encode_item(&item, 0, &encoded));
    puts("vision: wire fixture, signed boundaries and field validation PASS");
    return 0;
}
