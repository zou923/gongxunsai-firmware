#include "four_axis_motion.h"
#include <assert.h>
#include <stdio.h>
int main(void){four_axis_motion_t m;four_axis_plan_t p;four_axis_init(&m);four_axis_set_zero(&m);
 int32_t a[4]={222000,208000,0,100000};assert(four_axis_plan_absolute(&m,a,&p)==FOUR_AXIS_OK&&p.axis[0].ccw&&p.axis[1].ccw);
 assert(p.axis[0].pulses==71040&&p.axis[1].pulses==66560&&p.axis[2].pulses==0&&p.axis[3].pulses==32000);
 assert(p.axis[0].rpm==60&&p.axis[1].rpm==57&&p.axis[2].rpm==0&&p.axis[3].rpm==28);
 assert(m.position_um[0]==0);four_axis_commit(&m,&p);assert(m.position_um[0]==222000);
 int32_t z_up[4]={222000,208000,100000,100000};
 assert(four_axis_plan_absolute(&m,z_up,&p)==FOUR_AXIS_OK&&p.axis[2].ccw);
 int32_t b[4]={0,208000,0,100000};assert(four_axis_plan_absolute(&m,b,&p)==FOUR_AXIS_OK&&!p.axis[0].ccw);
 int32_t bad[4]={222001,0,0,0};assert(four_axis_plan_absolute(&m,bad,&p)==FOUR_AXIS_OUT_OF_RANGE);
 four_axis_clear_zero(&m);assert(four_axis_plan_absolute(&m,a,&p)==FOUR_AXIS_NOT_HOMED);
 puts("four-axis motion: PASS");return 0;}
