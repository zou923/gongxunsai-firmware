#include "x42s_protocol.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

static void expect_frame(const uint8_t *actual,size_t actual_len,const uint8_t *expected,size_t expected_len)
{ assert(actual_len==expected_len); assert(memcmp(actual,expected,expected_len)==0); }

int main(void)
{
    uint8_t frame[X42S_FRAME_MAX]; size_t n=0U;
    const uint8_t position[]={0x01,0x36,0x6B};
    const uint8_t status[]={0x02,0x3A,0x6B};
    const uint8_t combined[]={0x03,0x3C,0x6B};
    const uint8_t stop[]={0x01,0xFE,0x98,0x00,0x6B};
    const uint8_t home[]={0x01,0x9A,0x03,0x00,0x6B};
    const uint8_t emm_move[]={0x01,0xFD,0x01,0x05,0xDC,0x00,0x00,0x00,0x7D,0x00,0x00,0x00,0x6B};
    const uint8_t x_move[]={0x01,0xFD,0x01,0x01,0xFF,0x01,0xFA,0x27,0x10,0x00,0x00,0x8C,0xA0,0x00,0x00,0x6B};
    assert(x42s_build_query_position(1,frame,sizeof frame,&n)); expect_frame(frame,n,position,sizeof position);
    assert(x42s_build_query_status(2,frame,sizeof frame,&n)); expect_frame(frame,n,status,sizeof status);
    assert(x42s_build_query_combined(3,frame,sizeof frame,&n)); expect_frame(frame,n,combined,sizeof combined);
    assert(x42s_build_stop(1,false,frame,sizeof frame,&n)); expect_frame(frame,n,stop,sizeof stop);
    assert(x42s_build_home(1,X42S_HOME_LIMIT,false,frame,sizeof frame,&n)); expect_frame(frame,n,home,sizeof home);
    assert(x42s_build_emm_position(1,true,1500,0,32000,X42S_POSITION_REL_TARGET,false,frame,sizeof frame,&n));
    expect_frame(frame,n,emm_move,sizeof emm_move);
    assert(x42s_build_x_position(1,true,511,506,10000,36000,X42S_POSITION_REL_TARGET,false,frame,sizeof frame,&n));
    expect_frame(frame,n,x_move,sizeof x_move);
    assert(!x42s_build_query_status(0,frame,sizeof frame,&n));
    assert(!x42s_build_emm_position(1,false,3001,0,1,X42S_POSITION_REL_TARGET,false,frame,sizeof frame,&n));
    assert(x42s_build_emm_velocity(2,false,60,10,true,frame,sizeof frame,&n));
    expect_frame(frame,n,(uint8_t[]){2,0xF6,0,0,60,10,1,0x6B},8);
    assert(x42s_build_sync_trigger(frame,sizeof frame,&n));
    expect_frame(frame,n,(uint8_t[]){0,0xFF,0x66,0x6B},4);
    assert(x42s_build_dual_stop(1,2,frame,sizeof frame,&n));
    expect_frame(frame,n,(uint8_t[]){0,0xAA,0,15,
        1,0xFE,0x98,0,0x6B,2,0xFE,0x98,0,0x6B,0x6B},15);
    assert(!x42s_build_emm_velocity(1,false,3001,10,false,frame,sizeof frame,&n));
    assert(x42s_build_set_single_turn_zero(1,true,frame,sizeof frame,&n));
    expect_frame(frame,n,(uint8_t[]){1,0x93,0x88,1,0x6B},5);

    uint8_t group[40];
    assert(x42s_build_dual_home_nearest(1,2,group,sizeof group,&n));
    expect_frame(group,n,(uint8_t[]){0,0xAA,0,15,
        1,0x9A,0,1,0x6B,2,0x9A,0,1,0x6B,0x6B,
        0,0xFF,0x66,0x6B},19);
    assert(x42s_build_dual_set_single_turn_zero(1,2,true,group,sizeof group,&n));
    expect_frame(group,n,(uint8_t[]){0,0xAA,0,15,
        1,0x93,0x88,1,0x6B,2,0x93,0x88,1,0x6B,0x6B},15);
    assert(x42s_build_dual_emm_position(1,false,60,10,3200,
        2,true,30,10,1600,group,sizeof group,&n));
    expect_frame(group,n,(uint8_t[]){0,0xAA,0,31,
        1,0xFD,0,0,60,10,0,0,0x0C,0x80,2,1,0x6B,
        2,0xFD,1,0,30,10,0,0,0x06,0x40,2,1,0x6B,0x6B,
        0,0xFF,0x66,0x6B},35);
    x42s_position_request_t req[4]={{1,false,60,10,12800},{2,true,30,10,6400},{3,false,0,10,0},{4,true,12,10,2560}};
    uint8_t four[70];
    assert(x42s_build_four_position(req,four,sizeof four,&n)&&n==61U);
    assert(four[0]==0&&four[1]==0xAA&&four[3]==57&&four[4]==1&&four[17]==2&&four[30]==3&&four[43]==4);
    assert(memcmp(four+57,(uint8_t[]){0,0xFF,0x66,0x6B},4)==0);
    assert(!x42s_build_four_position(req,four,60,&n));
    req[3].address=3;assert(!x42s_build_four_position(req,four,sizeof four,&n));req[3].address=4;
    assert(x42s_build_stop_many(1,4,four,sizeof four,&n)&&n==25U&&four[4]==1&&four[9]==2&&four[14]==3&&four[19]==4);
    assert(x42s_build_stop_many(3,1,four,sizeof four,&n)&&n==10U&&four[4]==3);

    x42s_reply_t reply;
    const uint8_t ack[]={1,0xFE,0x02,0x6B};
    const uint8_t state[]={1,0x3C,0x03,0x83,0x6B};
    const uint8_t pos[]={1,0x36,0x01,0x00,0x00,0x00,0x10,0x6B};
    assert(x42s_parse_reply(ack,sizeof ack,&reply) && reply.kind==X42S_REPLY_ACK && reply.accepted);
    assert(x42s_parse_reply(state,sizeof state,&reply) && reply.kind==X42S_REPLY_COMBINED);
    assert(reply.home_flags==0x03 && reply.motor_flags==0x83);
    assert(x42s_parse_reply(pos,sizeof pos,&reply) && reply.kind==X42S_REPLY_POSITION);
    assert(reply.position_raw==-16);
    assert(x42s_parse_reply((uint8_t[]){1,0x3A,0x83,0x6B},4,&reply));
    assert(reply.kind==X42S_REPLY_STATUS && reply.motor_flags==0x83);
    assert(!x42s_parse_reply((uint8_t[]){1,0x3A,0x83,0},4,&reply));
    puts("x42s fixed-0x6B protocol vectors: PASS");
    return 0;
}
