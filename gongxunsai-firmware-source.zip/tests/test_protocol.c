#include "protocol.h"

#include <stdio.h>
#include <string.h>

#define CHECK(condition) do { \
    if (!(condition)) { \
        fprintf(stderr, "%s:%d: %s\n", __FILE__, __LINE__, #condition); \
        return 1; \
    } \
} while (0)

/* CRC and packet oracle computed independently using Python binascii.crc_hqx. */
static const uint8_t query_golden[32] = {
    0xA5, 0x5A, 0x01, 0x10, 0x34, 0x12, 0x00, 0x00,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0x58, 0x06
};

static void repair_crc(uint8_t *bytes)
{
    protocol_write_u16(bytes + 30, protocol_crc16(bytes, 30));
}

static unsigned feed_bytes(protocol_stream_t *stream, const uint8_t *bytes,
                           size_t count, uint32_t now, protocol_frame_t *frame)
{
    unsigned emitted = 0;
    size_t i;
    for (i = 0; i < count; ++i) {
        emitted += protocol_stream_feed(stream, bytes[i], now, frame) ? 1u : 0u;
    }
    return emitted;
}

static int test_wire_validation(void)
{
    uint8_t bytes[32];
    uint8_t le[4];
    protocol_frame_t input = {0};
    protocol_frame_t output;
    protocol_frame_t before;
    size_t i;

    CHECK(protocol_crc16((const uint8_t *)"123456789", 9) == 0x29B1u);
    CHECK(protocol_crc16(NULL, 0) == 0xFFFFu);
    protocol_write_u16(le, 0x1234);
    CHECK(le[0] == 0x34 && le[1] == 0x12);
    protocol_write_u32(le, 0x89ABCDEFu);
    CHECK(le[0] == 0xEF && le[1] == 0xCD && le[2] == 0xAB && le[3] == 0x89);
    CHECK(protocol_read_u16(le) == 0xCDEFu);
    CHECK(protocol_read_u32(le) == 0x89ABCDEFu);

    input.type = PROTO_IO_QUERY;
    input.sequence = 0x1234;
    memset(input.payload, 0xCC, sizeof(input.payload));
    CHECK(protocol_encode(&input, bytes));
    CHECK(memcmp(bytes, query_golden, sizeof(bytes)) == 0);
    CHECK(protocol_decode(query_golden, &output));
    CHECK(output.type == PROTO_IO_QUERY && output.sequence == 0x1234);
    CHECK(output.length == 0 && output.flags == 0);
    for (i = 0; i < sizeof(output.payload); ++i) CHECK(output.payload[i] == 0);

    input.type = PROTO_IO_STATUS;
    input.length = PROTOCOL_PAYLOAD_SIZE;
    for (i = 0; i < sizeof(input.payload); ++i) input.payload[i] = (uint8_t)i;
    CHECK(protocol_encode(&input, bytes));
    CHECK(protocol_decode(bytes, &output));
    CHECK(output.length == PROTOCOL_PAYLOAD_SIZE);
    CHECK(memcmp(output.payload, input.payload, sizeof(input.payload)) == 0);

    input.length = 23;
    CHECK(!protocol_encode(&input, bytes));
    input.length = 0;
    input.flags = 1;
    CHECK(!protocol_encode(&input, bytes));
    CHECK(!protocol_encode(NULL, bytes));
    CHECK(!protocol_encode(&input, NULL));
    CHECK(!protocol_decode(NULL, &output));
    CHECK(!protocol_decode(bytes, NULL));

    /* All rejected candidates must leave the caller's previous frame intact. */
    memset(&output, 0xE7, sizeof(output));
    before = output;
    for (i = 0; i < 7; ++i) {
        memcpy(bytes, query_golden, sizeof(bytes));
        switch (i) {
        case 0: bytes[0] = 0; repair_crc(bytes); break;
        case 1: bytes[1] = 0; repair_crc(bytes); break;
        case 2: bytes[2] = 2; repair_crc(bytes); break;
        case 3: bytes[6] = 23; repair_crc(bytes); break;
        case 4: bytes[7] = 1; repair_crc(bytes); break;
        case 5: bytes[8] = 1; repair_crc(bytes); break;
        default: bytes[30] ^= 1; break;
        }
        CHECK(!protocol_decode(bytes, &output));
        CHECK(memcmp(&output, &before, sizeof(output)) == 0);
    }
    return 0;
}

static int test_sequences(void)
{
    uint16_t last = 99;
    bool initialized = false;
    CHECK(protocol_seq_accept(65534, &last, &initialized));
    CHECK(last == 65534 && initialized);
    CHECK(!protocol_seq_accept(65534, &last, &initialized));
    CHECK(last == 65534);
    CHECK(protocol_seq_accept(65535, &last, &initialized));
    CHECK(protocol_seq_accept(0, &last, &initialized));
    CHECK(protocol_seq_accept(1, &last, &initialized));
    CHECK(!protocol_seq_accept(65535, &last, &initialized));
    CHECK(!protocol_seq_accept(32769, &last, &initialized));
    CHECK(last == 1);
    CHECK(protocol_seq_accept(32768, &last, &initialized));
    CHECK(!protocol_seq_accept(32767, &last, &initialized));
    CHECK(!protocol_seq_accept(0, NULL, &initialized));
    CHECK(!protocol_seq_accept(0, &last, NULL));
    return 0;
}

static int test_stream_noise_fragmentation(void)
{
    const uint8_t noise[] = {0, 0x5A, 0xA5, 0xA5, 0, 0xFE, 0xA5};
    uint8_t bad[32];
    protocol_stream_t stream;
    protocol_frame_t output;
    size_t i;
    protocol_stream_init(&stream);
    CHECK(feed_bytes(&stream, noise, sizeof(noise), 1, &output) == 0);
    CHECK(feed_bytes(&stream, query_golden, 5, 2, &output) == 0);
    CHECK(feed_bytes(&stream, query_golden + 5, 13, 4, &output) == 0);
    CHECK(feed_bytes(&stream, query_golden + 18, 14, 5, &output) == 1);
    CHECK(output.sequence == 0x1234 && stream.discarded == sizeof(noise));
    CHECK(stream.crc_errors == 0 && stream.timeouts == 0);
    CHECK(feed_bytes(&stream, query_golden, 32, 6, &output) == 1);

    memcpy(bad, query_golden, sizeof(bad));
    bad[12] ^= 0x10;
    CHECK(feed_bytes(&stream, bad, sizeof(bad), 7, &output) == 0);
    CHECK(stream.crc_errors == 1);
    CHECK(feed_bytes(&stream, query_golden, 32, 8, &output) == 1);

    /* Valid start embedded inside a corrupt candidate must survive the slide. */
    protocol_stream_init(&stream);
    CHECK(feed_bytes(&stream, query_golden, 12, 1, &output) == 0);
    CHECK(feed_bytes(&stream, query_golden, 32, 2, &output) == 1);
    CHECK(output.sequence == 0x1234 && stream.discarded == 12);

    /* Every truncation boundary recovers when a complete frame follows. */
    for (i = 1; i < 32; ++i) {
        protocol_stream_init(&stream);
        CHECK(feed_bytes(&stream, query_golden, i, 1, &output) == 0);
        CHECK(feed_bytes(&stream, query_golden, 32, 2, &output) == 1);
        CHECK(stream.used == 0 && output.type == PROTO_IO_QUERY);
    }
    return 0;
}

static int test_stream_timeout_and_wrap(void)
{
    protocol_stream_t stream;
    protocol_frame_t output;
    protocol_stream_init(&stream);
    CHECK(feed_bytes(&stream, query_golden, 10, 20, &output) == 0);
    protocol_stream_expire(&stream, 119);
    CHECK(stream.used == 10 && stream.timeouts == 0);
    protocol_stream_expire(&stream, 120);
    CHECK(stream.used == 0 && stream.timeouts == 1 && stream.discarded == 10);
    protocol_stream_expire(&stream, 200);
    CHECK(stream.timeouts == 1);
    CHECK(feed_bytes(&stream, query_golden, 32, 201, &output) == 1);

    protocol_stream_init(&stream);
    CHECK(feed_bytes(&stream, query_golden, 10, UINT32_MAX - 49u, &output) == 0);
    protocol_stream_expire(&stream, 49);
    CHECK(stream.used == 10 && stream.timeouts == 0);
    protocol_stream_expire(&stream, 50);
    CHECK(stream.used == 0 && stream.timeouts == 1);
    CHECK(feed_bytes(&stream, query_golden, 32, 51, &output) == 1);

    protocol_stream_init(&stream);
    CHECK(feed_bytes(&stream, query_golden, 8, 1, &output) == 0);
    CHECK(feed_bytes(&stream, query_golden, 32, 101, &output) == 1);
    CHECK(stream.timeouts == 1);
    return 0;
}

int main(void)
{
    if (test_wire_validation() || test_sequences() ||
        test_stream_noise_fragmentation() || test_stream_timeout_and_wrap()) return 1;
    puts("protocol: CRC, framing, replay, noise, truncation, timeout and wrap PASS");
    return 0;
}
