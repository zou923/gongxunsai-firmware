#include "app_state.h"
#include "io_spi.h"
#include "master_display.h"
#include "protocol.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    master_display_t display;
    master_display_build(&display, false, 0u);
    assert(strcmp(display.title, "MASTER") == 0);
    assert(strcmp(display.link, "IO: OFFLINE") == 0);
    assert(strcmp(display.fault, "FAULT: 00000000") == 0);
    master_display_build(&display, true, 0x12ABu);
    assert(strcmp(display.link, "IO: ONLINE ") == 0);
    assert(strcmp(display.fault, "FAULT: 000012AB") == 0);

    app_state_t app;
    app_health_t h = {false, true, true, false, 0};
    app_state_init(&app, 0);
    app_state_tick(&app, &h, true, false, false, false, 0);
    app_state_tick(&app, &h, true, false, false, false, 1001);
    assert(app.state == APP_FAULT && (app.faults & MASTER_FAULT_CONFIG));
    assert(!app_motion_permitted(&app));
    h.configuration_ok = true;
    app_state_tick(&app, &h, true, false, false, false, 1100);
    assert(app.state == APP_FAULT); /* Link recovery/start must not clear a fault. */
    app_state_tick(&app, &h, false, false, false, true, 1200);
    assert(app.state == APP_SELF_CHECK);
    app_state_tick(&app, &h, false, false, false, false, 1201);
    assert(app.state == APP_IDLE);
    app_state_tick(&app, &h, true, false, false, false, 1202);
    assert(app.state == APP_FAULT && (app.faults & MASTER_FAULT_NOT_IMPLEMENTED));
    app_state_tick(&app, &h, false, false, true, false, 1203);
    assert(app.state == APP_E_STOP && app.stop_requested);
    app_state_tick(&app, &h, true, false, false, false, 1204);
    assert(app.state == APP_E_STOP && !app_motion_permitted(&app));
    app_state_tick(&app, &h, true, false, false, true, 1205);
    assert(app.state == APP_E_STOP); /* Reset while START held is rejected. */
    app_state_tick(&app, &h, false, false, false, true, 1206);
    assert(app.state == APP_SELF_CHECK);
    app_state_tick(&app, &h, false, false, false, false, 1207);
    h.io_fresh = false;
    app_state_tick(&app, &h, false, false, false, false, 1507);
    assert(app.state == APP_FAULT && (app.faults & MASTER_FAULT_IO_LINK));

    io_link_t link;
    uint8_t request[PROTOCOL_FRAME_SIZE], reply[PROTOCOL_FRAME_SIZE];
    protocol_frame_t status = {0};
    io_link_init(&link);
    assert(io_link_build_servo(&link, 500u, request));
    {
        protocol_frame_t servo = {0};
        assert(protocol_decode(request, &servo));
        assert(servo.type == PROTO_IO_SERVO && servo.length == 2u);
        assert(protocol_read_u16(servo.payload) == 500u);
    }
    assert(!io_link_build_servo(&link, 499u, request));
    assert(!io_link_build_servo(&link, 1101u, request));
    assert(io_link_reported_faults(false, true, 0x15u) == 0u);
    assert(io_link_reported_faults(true, true, 0x15u) == 0x15u);
    assert(io_link_reported_faults(true, false, 0x15u) == 0u);
    assert(io_link_build(&link, PROTO_IO_QUERY, request));
    io_link_mark_sent(&link);
    status.type = PROTO_IO_STATUS;
    status.sequence = 0; /* Initial pipelined response predates our first request. */
    status.length = 22;
    assert(protocol_encode(&status, reply));
    assert(!io_link_accept(&link, reply, 10));
    assert(io_link_build(&link, PROTO_IO_QUERY, request));
    io_link_mark_sent(&link);
    status.sequence = 1;
    protocol_write_u16(status.payload, 0x7f);
    protocol_write_u16(status.payload + 4, 0x01);
    protocol_write_u16(status.payload + 6, IO_EVENT_DEBUG_LED_TOGGLE);
    protocol_write_u32(status.payload + 8, 1);
    assert(protocol_encode(&status, reply));
    assert(io_link_accept(&link, reply, 20));
    assert(link.status.raw == 0x7f && link.status.valid == 1 && link.status.faults == 1);
    assert((link.status.events & IO_EVENT_DEBUG_LED_TOGGLE) != 0u);
    assert(io_link_build(&link, PROTO_IO_QUERY, request));
    io_link_mark_sent(&link);
    status.sequence = 2;
    protocol_write_u16(status.payload + 14, 500u);
    assert(protocol_encode(&status, reply));
    assert(io_link_accept(&link, reply, 21));
    assert(link.status.servo_us == 500u);
    assert(io_link_fresh(&link, 270, 250));
    assert(!io_link_fresh(&link, 271, 250));
    puts("master safety gates: PASS");
    return 0;
}
