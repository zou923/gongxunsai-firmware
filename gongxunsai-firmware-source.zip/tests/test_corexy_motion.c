#include "corexy_motion.h"
#include <assert.h>
#include <stdio.h>

int main(void)
{
    corexy_config_t cfg={12800U,40000U,60U,10U,222000,208000,false,false};
    corexy_motion_t motion;
    corexy_plan_t plan;
    corexy_init(&motion,&cfg);
    assert(corexy_plan_absolute(&motion,100000,50000,&plan)==COREXY_NOT_HOMED);
    corexy_set_homed(&motion);
    assert(corexy_plan_absolute(&motion,100000,50000,&plan)==COREXY_OK);
    assert(plan.motor1_pulses==32000U); /* Motor 1 follows X: 100 mm. */
    assert(plan.motor2_pulses==16000U); /* Motor 2 follows Y: 50 mm. */
    assert(plan.motor1_rpm==60U && plan.motor2_rpm==30U);
    assert(!plan.motor1_ccw && !plan.motor2_ccw);
    corexy_commit(&motion,&plan);
    assert(motion.x_um==100000 && motion.y_um==50000);
    assert(corexy_plan_absolute(&motion,50000,100000,&plan)==COREXY_OK);
    assert(plan.motor1_pulses==16000U && plan.motor1_ccw);
    assert(plan.motor2_pulses==16000U && !plan.motor2_ccw);
    assert(corexy_plan_absolute(&motion,222000,208000,&plan)==COREXY_OK);
    assert(corexy_plan_absolute(&motion,222001,0,&plan)==COREXY_OUT_OF_RANGE);
    assert(corexy_plan_absolute(&motion,0,208001,&plan)==COREXY_OUT_OF_RANGE);
    assert(corexy_plan_absolute(&motion,-1,0,&plan)==COREXY_OUT_OF_RANGE);
    assert(corexy_plan_absolute(&motion,0,-1,&plan)==COREXY_OUT_OF_RANGE);
    assert(corexy_emm_position_to_um(100000,100000,40000U)==0);
    assert(corexy_emm_position_to_um(100000,919200,40000U)==500000);
    assert(corexy_emm_position_to_um(100000,-719200,40000U)==-500000);
    corexy_set_position(&motion,321000,123000);
    assert(motion.x_um==321000 && motion.y_um==123000 && motion.homed);
    puts("independent XY axes and speed scaling: PASS");
    return 0;
}
