#include "four_axis_limits.h"
#include <assert.h>
#include <stdio.h>
int main(void){four_axis_limits_t l;four_axis_limits_init(&l);
 assert(four_axis_limit_mask_for_axis(0)==0x20);assert(four_axis_limit_mask_for_axis(1)==0x40);
 assert(four_axis_limit_mask_for_axis(2)==0x04);assert(four_axis_limit_mask_for_axis(3)==0x08);
 assert(four_axis_limit_motor_for_axis(0)==1&&four_axis_limit_motor_for_axis(3)==4);
 four_axis_limits_update(&l,0x48);assert(four_axis_limits_pop(&l)==1);assert(four_axis_limits_pop(&l)==3);assert(four_axis_limits_pop(&l)<0);
 four_axis_limits_update(&l,0x48);assert(four_axis_limits_pop(&l)<0);
 four_axis_limits_update(&l,0);four_axis_limits_update(&l,0x04);assert(four_axis_limits_pop(&l)==2);
 four_axis_limits_requeue(&l,2);assert(four_axis_limits_pop(&l)==2);
 puts("four-axis limit routing: PASS");return 0;}
