#include "debug_trigger.h"
#include <assert.h>
#include <stdio.h>

int main(void)
{
    debug_trigger_t trigger;
    debug_trigger_init(&trigger);
    assert(!debug_trigger_led_active(&trigger, 0u));
    assert(!debug_trigger_feed(&trigger, '0', 10u));
    assert(debug_trigger_feed(&trigger, '1', 20u));
    assert(debug_trigger_led_active(&trigger, 20u));
    assert(debug_trigger_led_active(&trigger, 1019u));
    assert(!debug_trigger_led_active(&trigger, 1020u));
    assert(debug_trigger_feed(&trigger, '1', UINT32_MAX - 499u));
    assert(debug_trigger_led_active(&trigger, 499u));
    assert(!debug_trigger_led_active(&trigger, 500u));
    debug_trigger_init(&trigger);
    assert(!debug_trigger_sync_toggle(&trigger, false, 100u));
    assert(debug_trigger_sync_toggle(&trigger, true, 200u));
    assert(!debug_trigger_sync_toggle(&trigger, true, 300u));
    assert(debug_trigger_led_active(&trigger, 1199u));
    assert(!debug_trigger_led_active(&trigger, 1200u));
    assert(debug_trigger_sync_toggle(&trigger, false, 1300u));
    puts("debug trigger: UART '1' drives LED for exactly 1000 ms PASS");
    return 0;
}
