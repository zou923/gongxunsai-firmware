#include "four_axis_zero.h"
#include <assert.h>
#include <stdio.h>
int main(void){four_axis_zero_t z;int64_t out[4]={9,8,7,6};four_axis_zero_init(&z);four_axis_zero_begin(&z,100);
 for(unsigned i=0;i<4;i++){assert(four_axis_zero_expected_address(&z)==i+1);assert(four_axis_zero_accept(&z,(uint8_t)(i+1),(int64_t)(100+i)));}
 assert(four_axis_zero_commit(&z,out));assert(out[0]==100&&out[3]==103);
 four_axis_zero_begin(&z,200);assert(!four_axis_zero_accept(&z,2,1));assert(!four_axis_zero_commit(&z,out));assert(out[0]==100);
 four_axis_zero_begin(&z,300);four_axis_zero_timeout(&z);assert(four_axis_zero_failed(&z));
 puts("four-axis zero: PASS");return 0;}
