#include "motion.h"
#include "x42s_driver.h"
#include <assert.h>
#include <stdio.h>

static void test_real_driver_stays_locked_without_protocol(void)
{
    x42s_driver_init(X42S_MODE_HARDWARE_LOCKED);
    assert(x42s_move(0U, 1000, 0) == X42S_PROTOCOL_UNAVAILABLE);
    assert(x42s_home(0U) == X42S_PROTOCOL_UNAVAILABLE);
    assert(x42s_stop(0U) == X42S_PROTOCOL_UNAVAILABLE);
}

static void test_simulated_axis_commands_are_non_blocking(void)
{
    x42s_status_t status;
    x42s_driver_init(X42S_MODE_SIMULATED);
    assert(x42s_set_parameters(0U, 500U, 100U) == X42S_OK);
    assert(x42s_move(0U, 1200, 0) == X42S_OK);
    assert(x42s_get_status(0U, &status) == X42S_OK);
    assert(status.motion == X42S_MOTION_MOVING && status.position == 0);
    x42s_driver_tick(49U);
    assert(x42s_get_status(0U, &status) == X42S_OK);
    assert(status.motion == X42S_MOTION_MOVING);
    x42s_driver_tick(50U);
    assert(x42s_get_status(0U, &status) == X42S_OK);
    assert(status.motion == X42S_MOTION_IDLE && status.position == 1200);
}

static void test_homing_runs_three_axes_sequentially(void)
{
    motion_controller_t motion;
    x42s_status_t status;
    x42s_driver_init(X42S_MODE_SIMULATED);
    motion_init(&motion);
    assert(motion_start_homing(&motion, 100U) == X42S_OK);
    assert(motion_state(&motion) == MOTION_HOMING);

    motion_tick(&motion, 149U);
    assert(motion_state(&motion) == MOTION_HOMING);
    assert(motion_homing_axis(&motion) == 0U);
    motion_tick(&motion, 150U);
    assert(motion_homing_axis(&motion) == 1U);
    motion_tick(&motion, 200U);
    assert(motion_homing_axis(&motion) == 2U);
    motion_tick(&motion, 250U);
    assert(motion_state(&motion) == MOTION_READY);
    assert(motion_ready_controller(&motion));

    for (unsigned i = 0; i < 3U; ++i) {
        assert(x42s_get_status(i, &status) == X42S_OK);
        assert(status.homed && status.position == 0);
    }
}

static void test_homing_timeout_enters_fault(void)
{
    motion_controller_t motion;
    x42s_driver_init(X42S_MODE_SIMULATED);
    x42s_sim_set_completion_ms(0U, 1000U);
    motion_init(&motion);
    motion_set_home_timeout(&motion, 100U);
    assert(motion_start_homing(&motion, 0U) == X42S_OK);
    motion_tick(&motion, 101U);
    assert(motion_state(&motion) == MOTION_FAULT);
    assert(motion_fault(&motion) == MOTION_FAULT_HOME_TIMEOUT);
}

int main(void)
{
    test_real_driver_stays_locked_without_protocol();
    test_simulated_axis_commands_are_non_blocking();
    test_homing_runs_three_axes_sequentially();
    test_homing_timeout_enters_fault();
    puts("motion/x42s simulation: PASS");
    return 0;
}
