#include "io_app.h"
#include "io_indicator.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

/* Test fixture: all seven inputs confirmed active-low. This is not wiring
 * configuration and must never be copied into the board commissioning data. */
static io_config_t confirmed_config(void)
{
    io_config_t config = { IO_INPUT_ALL, IO_INPUT_ALL, true, true, true, 250u, 20u };
    return config;
}

static void packet(uint8_t wire[32], uint8_t type, uint16_t sequence, uint8_t length)
{
    protocol_frame_t frame = {0};
    frame.type = type;
    frame.sequence = sequence;
    frame.length = length;
    assert(protocol_encode(&frame, wire));
}

static bool command(io_app_t *app, uint8_t type, uint16_t sequence, uint32_t now)
{
    uint8_t wire[32];
    packet(wire, type, sequence, 0u);
    return io_app_receive(app, wire, now);
}

static bool servo_command(io_app_t *app, uint16_t sequence, uint16_t pulse_us,
                          uint8_t length, uint32_t now)
{
    uint8_t wire[32];
    protocol_frame_t frame = {0};
    frame.type = PROTO_IO_SERVO;
    frame.sequence = sequence;
    frame.length = length;
    protocol_write_u16(frame.payload, pulse_us);
    assert(protocol_encode(&frame, wire));
    return io_app_receive(app, wire, now);
}

static void ready(io_app_t *app)
{
    io_config_t config = confirmed_config();
    io_app_init(app, &config, 0u);
    io_app_tick(app, IO_INPUT_ALL, 0u);
    io_app_tick(app, IO_INPUT_ALL, 20u);
    assert(command(app, PROTO_IO_QUERY, 1u, 20u));
    assert(command(app, PROTO_IO_RESET, 2u, 21u));
    assert(app->last_command_result == IO_RESULT_OK);
    assert(app->safety.faults == 0u);
}

/* Catches treating the known START polarity as confirmation of other wiring. */
static void test_unconfirmed_configuration_stays_safe(void)
{
    io_app_t app;
    uint8_t wire[32];
    io_config_t config = { IO_INPUT_START, IO_INPUT_START, false, false, false, 250u, 20u };
    io_app_init(&app, &config, 0u);
    assert((app.safety.faults & IO_FAULT_CONFIG_UNCONFIRMED) != 0u);
    io_app_tick(&app, 0x007eu, 0u);
    io_app_tick(&app, 0x007eu, 20u);
    assert(app.raw_levels == 0x007eu);
    assert(app.active_inputs == IO_INPUT_START);
    assert(app.valid_inputs == IO_INPUT_START);
    assert(app.rising_events == 0u);
    assert(command(&app, PROTO_IO_QUERY, 1u, 21u));
    assert(command(&app, PROTO_IO_RESET, 2u, 22u));
    assert(app.last_command_result == IO_RESULT_RESET_BLOCKED);
    assert(app.output_bits == 0u && app.servo_us == 0u && !app.servo.enabled);

    io_app_debug_led_event(&app);
    io_app_status(&app, wire, 23u);
    {
        protocol_frame_t status;
        assert(protocol_decode(wire, &status));
        assert((protocol_read_u16(status.payload + 6u) & IO_EVENT_DEBUG_LED_TOGGLE) != 0u);
    }
}

static void test_single_confirmed_active_low_limit(void)
{
    io_app_t app;
    io_config_t config = {
        IO_INPUT_START | IO_INPUT_LIMIT3,
        IO_INPUT_START | IO_INPUT_LIMIT3,
        false, true, false, 250u, 20u
    };
    io_app_init(&app, &config, 0u);
    assert(!app.input_configuration_fault);
    assert(app.valid_inputs == (IO_INPUT_START | IO_INPUT_LIMIT3));
    io_app_tick(&app, IO_INPUT_ALL, 0u);
    io_app_tick(&app, IO_INPUT_ALL & (uint16_t)~IO_INPUT_LIMIT3, 1u);
    io_app_tick(&app, IO_INPUT_ALL & (uint16_t)~IO_INPUT_LIMIT3, 21u);
    assert((app.active_inputs & IO_INPUT_LIMIT3) != 0u);
}

/* Catches boot-held START firing, bounce counting, and event loss on replies. */
static void test_start_requires_release_and_debounce(void)
{
    io_app_t app;
    io_config_t config = confirmed_config();
    uint8_t wire[32];
    protocol_frame_t status;
    io_app_init(&app, &config, 0u);
    io_app_tick(&app, 0x007eu, 0u);
    io_app_tick(&app, 0x007eu, 25u);
    assert(app.rising_events == 0u);
    io_app_tick(&app, 0x007fu, 30u);
    io_app_tick(&app, 0x007fu, 49u);
    io_app_tick(&app, 0x007fu, 50u);
    io_app_tick(&app, 0x007eu, 55u);
    io_app_tick(&app, 0x007fu, 60u);
    io_app_tick(&app, 0x007eu, 61u);
    io_app_tick(&app, 0x007eu, 80u);
    assert(app.rising_events == 0u && (app.active_inputs & IO_INPUT_START) == 0u);
    io_app_tick(&app, 0x007eu, 81u);
    assert(app.rising_events == IO_INPUT_START);
    assert(app.active_inputs == IO_INPUT_START);
    io_app_status(&app, wire, 81u);
    assert(protocol_decode(wire, &status));
    assert(status.type == PROTO_IO_STATUS && status.length == 22u);
    assert(protocol_read_u16(status.payload + 6u) == IO_INPUT_START);
    io_app_status(&app, wire, 82u);
    assert(protocol_decode(wire, &status));
    assert(protocol_read_u16(status.payload + 6u) == IO_INPUT_START);
}

/* Catches subtraction/comparison mistakes when the millisecond tick wraps. */
static void test_debounce_and_timeout_wraparound(void)
{
    io_app_t app;
    io_config_t config = confirmed_config();
    uint32_t boot = UINT32_MAX - 10u;
    io_app_init(&app, &config, boot);
    io_app_tick(&app, IO_INPUT_ALL, boot);
    io_app_tick(&app, IO_INPUT_ALL, 9u);
    assert(command(&app, PROTO_IO_QUERY, 65535u, 9u));
    io_app_tick(&app, 0x007eu, 10u);
    io_app_tick(&app, 0x007eu, 29u);
    assert(app.rising_events == 0u);
    io_app_tick(&app, 0x007eu, 30u);
    assert(app.rising_events == IO_INPUT_START);
    assert(command(&app, PROTO_IO_QUERY, 0u, 30u));
    io_app_tick(&app, IO_INPUT_ALL, 279u);
    assert((app.safety.faults & IO_FAULT_COMM_TIMEOUT) == 0u);
    io_app_tick(&app, IO_INPUT_ALL, 280u);
    assert((app.safety.faults & IO_FAULT_COMM_TIMEOUT) != 0u);
}

/* Catches placing the STOP latch behind the debouncer or auto-clearing bounce. */
static void test_raw_stop_latches_before_debounce(void)
{
    io_app_t app;
    ready(&app);
    app.output_bits = 3u;
    app.outputs.bits = 3u;
    app.servo_us = 1500u;
    app.servo.pulse_us = 1500u;
    app.servo.enabled = true;
    io_app_tick(&app, 0x007du, 22u);
    assert((app.safety.faults & IO_FAULT_STOP_LATCH) != 0u);
    assert((app.active_inputs & IO_INPUT_STOP) == 0u);
    assert(app.output_bits == 0u && app.outputs.bits == 0u);
    assert(app.servo_us == 0u && app.servo.pulse_us == 0u && !app.servo.enabled);
    io_app_tick(&app, IO_INPUT_ALL, 23u);
    assert((app.safety.faults & IO_FAULT_STOP_LATCH) != 0u);
    assert(command(&app, PROTO_IO_RESET, 3u, 24u));
    assert(app.last_command_result == IO_RESULT_RESET_BLOCKED);
    io_app_tick(&app, IO_INPUT_ALL, 43u);
    assert(command(&app, PROTO_IO_RESET, 4u, 44u));
    assert(app.safety.faults == 0u && app.output_bits == 0u && app.servo_us == 0u);
}

/* Catches any invalid traffic refreshing the timeout or consuming good seq. */
static void test_rejected_packets_do_not_keep_communication_alive(void)
{
    io_app_t app;
    uint8_t wire[32];
    ready(&app); /* Last safe communication at 21 ms. */
    packet(wire, PROTO_IO_QUERY, 3u, 0u);
    wire[31] ^= 1u;
    assert(!io_app_receive(&app, wire, 200u));
    assert(app.last_command_result == IO_RESULT_BAD_FRAME);
    assert(!command(&app, PROTO_IO_QUERY, 2u, 220u));
    assert(app.last_command_result == IO_RESULT_BAD_SEQUENCE);
    assert(!command(&app, 0x44u, 3u, 240u));
    assert(app.last_command_result == IO_RESULT_BAD_COMMAND);
    packet(wire, PROTO_IO_SAFE, 3u, 1u);
    assert(!io_app_receive(&app, wire, 250u));
    assert(app.last_command_result == IO_RESULT_BAD_LENGTH);
    io_app_tick(&app, IO_INPUT_ALL, 270u);
    assert((app.safety.faults & IO_FAULT_COMM_TIMEOUT) == 0u);
    io_app_tick(&app, IO_INPUT_ALL, 271u);
    assert((app.safety.faults & IO_FAULT_COMM_TIMEOUT) != 0u);
    assert(command(&app, PROTO_IO_RESET, 3u, 272u));
    assert(app.last_command_result == IO_RESULT_RESET_BLOCKED);
    assert(command(&app, PROTO_IO_QUERY, 4u, 273u));
    assert((app.safety.faults & IO_FAULT_COMM_TIMEOUT) != 0u);
    assert(command(&app, PROTO_IO_RESET, 5u, 274u));
    assert(app.safety.faults == 0u);
}

/* Catches resetting with a held limit, stale comm, or held START. */
static void test_reset_interlocks_and_event_clear(void)
{
    io_app_t app;
    ready(&app);
    io_app_tick(&app, 0x007bu, 22u);
    assert((app.safety.faults & IO_FAULT_LIMIT_LATCH) != 0u);
    assert(command(&app, PROTO_IO_RESET, 3u, 23u));
    assert(app.last_command_result == IO_RESULT_RESET_BLOCKED);
    io_app_tick(&app, IO_INPUT_ALL, 24u);
    io_app_tick(&app, IO_INPUT_ALL, 44u);
    io_app_tick(&app, 0x007eu, 45u);
    io_app_tick(&app, 0x007eu, 65u);
    assert(command(&app, PROTO_IO_RESET, 4u, 66u));
    assert(app.last_command_result == IO_RESULT_RESET_BLOCKED);
    assert(app.rising_events == IO_INPUT_START);
    io_app_tick(&app, IO_INPUT_ALL, 67u);
    io_app_tick(&app, IO_INPUT_ALL, 87u);
    assert(command(&app, PROTO_IO_RESET, 5u, 88u));
    assert(app.rising_events == 0u && app.safety.faults == 0u);
    assert(!command(&app, PROTO_IO_RESET, 4u, 89u));
    assert(app.last_command_result == IO_RESULT_BAD_SEQUENCE);
    assert(app.output_bits == 0u && app.servo_us == 0u);
}

/* Catches unknown mask bits / impossible validation flags silently accepted. */
static void test_invalid_configuration_is_faulted(void)
{
    io_app_t app;
    io_config_t config = confirmed_config();
    config.valid_mask |= 0x8000u;
    io_app_init(&app, &config, 0u);
    assert((app.safety.faults & IO_FAULT_INPUT_FAULT) != 0u);
    assert((app.safety.faults & IO_FAULT_CONFIG_UNCONFIRMED) != 0u);
    io_app_init(&app, NULL, 0u);
    assert((app.safety.faults & IO_FAULT_CONFIG_UNCONFIRMED) != 0u);
    assert(app.output_bits == 0u && app.servo_us == 0u);
}

/* Catches accidental output command decoding and incomplete status packing. */
static void test_random_requests_never_enable_outputs_and_status(void)
{
    io_app_t app;
    uint8_t wire[32];
    protocol_frame_t status;
    unsigned type;
    ready(&app);
    for (type = 0u; type < 256u; ++type) {
        packet(wire, (uint8_t)type, (uint16_t)(type + 3u), 0u);
        (void)io_app_receive(&app, wire, 22u);
        assert(app.output_bits == 0u && app.servo_us == 0u && !app.servo.enabled);
    }
    assert(command(&app, PROTO_IO_QUERY, 500u, 23u));
    io_app_status(&app, wire, 24u);
    assert(protocol_decode(wire, &status));
    assert(status.sequence == 500u && status.type == 0x90u && status.length == 22u);
    assert(protocol_read_u16(status.payload) == 0x007fu);
    assert(protocol_read_u16(status.payload + 2u) == 0u);
    assert(protocol_read_u16(status.payload + 4u) == 0x007fu);
    assert(protocol_read_u32(status.payload + 8u) == 0u);
    assert(protocol_read_u16(status.payload + 12u) == 0u);
    assert(protocol_read_u16(status.payload + 14u) == 0u);
    assert(status.payload[16] == 0u && status.payload[17] == 1u);
    assert(protocol_read_u32(status.payload + 18u) == 24u);
}

static void test_remote_servo_command_range(void)
{
    io_app_t app;
    ready(&app);
    assert(servo_command(&app, 3u, 500u, 2u, 22u));
    assert(app.servo_target_us == 500u);
    assert(servo_command(&app, 4u, 1100u, 2u, 23u));
    assert(app.servo_target_us == 1100u);
    assert(servo_command(&app, 5u, 0u, 2u, 24u));
    assert(app.servo_target_us == 0u);
    assert(!servo_command(&app, 6u, 499u, 2u, 25u));
    assert(app.servo_target_us == 0u);
    assert(!servo_command(&app, 6u, 1101u, 2u, 26u));
    assert(!servo_command(&app, 6u, 500u, 1u, 27u));
}

int main(void)
{
    test_single_confirmed_active_low_limit();
    assert(io_indicator_led(false, 0u, 0u));
    assert(!io_indicator_led(false, 0u, 250u));
    assert(io_indicator_led(false, 1u, 100u));
    assert(!io_indicator_led(false, 1u, 250u));
    assert(io_indicator_led(true, 0u, 999u));
    assert(io_indicator_led(true, 1u, 999u));
    assert(!io_indicator_led(true, 1u, 1000u));
    assert(!io_indicator_led(true, 1u, 1999u));
    assert(io_indicator_led(true, 1u, 2000u));

    test_unconfirmed_configuration_stays_safe();
    test_start_requires_release_and_debounce();
    test_debounce_and_timeout_wraparound();
    test_raw_stop_latches_before_debounce();
    test_rejected_packets_do_not_keep_communication_alive();
    test_reset_interlocks_and_event_clear();
    test_invalid_configuration_is_faulted();
    test_random_requests_never_enable_outputs_and_status();
    test_remote_servo_command_range();
    puts("IO: 9 test groups passed");
    return 0;
}
