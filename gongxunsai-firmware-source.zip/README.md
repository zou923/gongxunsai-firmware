# 工训赛 STM32 双板控制固件与 PCB

包含 STM32F103C8T6 主从板固件、构建/测试脚本，以及嘉立创EDA专业版 PCB 源工程和连接参考资料。PCB文件版本说明与旧Gerber的限制见 [Hardware/PCB/README.md](Hardware/PCB/README.md)。
STM32F103C8T6 双 MCU 固件工程：U1 为 MASTER，U3 为 IO。从板负责输入采集、舵机 PWM 与状态回报；主板负责调试/视觉串口、SPI 通信、OLED 状态和 X42S 步进驱动协议。

这是面向指定自制硬件的实验工程。源码可编译、主机测试通过不等于整机已完成安全验收。手动串口命令会向 X42S 发运动报文；首次试机请先卸载夹具/负载、让运动部件处于安全范围、准备独立断电方式，并逐轴低速确认方向、限位极性和行程。不要把软件限位当作硬件急停。

## 当前实现

- 主板调试串口：115200、8N1；接受 `ZERO`、`HOME`、`XY x y`、`XYZS x y z s`、`R3 turns`、`R4 turns`、`STOP3`、`STOP4`、`STOPALL` 和 `Pdddd`。
- 电机地址约定为 1=X、2=Y、3=Z、4=S。`XYZS` 的坐标单位为 mm，最多三位小数。当前软件范围为 X 0–222 mm、Y 0–208 mm、Z/S 0–500 mm；Z/S 范围和机械标定仍需按实际结构校准。
- X/Y/Z/S 运动规划使用每转 12800 个命令计数、每转 40 mm、最高 60 RPM 的当前配置；这些参数必须与驱动器细分及实际传动匹配。
- `ZERO` 建立软件坐标原点；`HOME` 将已保存的坐标移动回零点，不是自动寻找所有轴的机械开关。Z 轴 CN3/PA1 限位触发时会发送停止命令，并把停止位置设为软件 Z=0。
- `P0500`–`P1100` 是舵机脉宽命令，主板转发给 IO 板。`SERVO FORWARD QUEUED` 只表示已排队/转发，不表示舵机已经到位。
- 视觉输入使用 USART1；调试串口使用 USART2；主从板通过 SPI1 通信；X42S 串口使用 USART3。默认串口速率为 115200、8N1。

上面说明的是当前固件配置与代码行为。PCB 源工程、参考网表和旧版 Gerber 已随包提供，版本关系及制造限制见 [Hardware/PCB/README.md](Hardware/PCB/README.md)；其他限位开关的机械对应关系、驱动器固件/参数、电源能力和整机行程仍须现场核对。主板 `ZERO` 当前默认采用软件零点模式（`BOARD_FOUR_AXIS_ZERO_QUERY_ENABLED=0`）。

## 构建与测试

需要 CMake 3.20+、Ninja、GNU Arm Embedded 工具链（`arm-none-eabi-gcc`、`objcopy`、`size`）和 Windows PowerShell。工具链目录加入 `PATH`，或将 `ARM_GNU_ROOT` 设为包含 `bin/` 的安装目录。

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\build.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\test.ps1
```

构建会生成 `build/gongxunsai.elf`、`build/sorter-master.elf` 和 `build/sorter-io.elf`，以及对应 HEX/BIN 文件。VS Code 可用 `Ctrl+Shift+B` 构建，也可从任务列表分别启动主板/从板烧录任务。

主机测试覆盖帧解析、CRC、视觉数据、输入消抖与限位、状态门控、运动规划、坐标范围和 X42S 协议编码。它们不验证实际电机、舵机、接线、机械方向或硬件急停。

## 烧录

安装 OpenOCD 并将 `openocd` 加入 `PATH`，或设置 `OPENOCD_EXE` 为其可执行文件。连接目标 MCU 的 GND、SWDIO=PA13、SWCLK=PA14，BOOT0 置低。主板和从板需分别烧录，确认板上 MCU 标号后再执行对应任务。

```powershell
# 主板 U1
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\flash.ps1 -Target sorter-master

# 从板 U3
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\flash.ps1 -Target sorter-io
```

CMSIS-DAP 使用 USB Bulk 后端；也可用 `-Probe stlink` 选择 ST-Link。烧录会覆盖目标 MCU 的应用区。此仓库不含工具链、OpenOCD 可执行文件或任何私有烧录器序列号。

## 目录

- `Master/`、`IO/`：主从 MCU 应用逻辑。
- `Shared/`：帧协议、视觉解析、串口命令解析。
- `Platform/`、`Core/`、`Hardware/`：板级驱动、启动及外设代码。
- `Config/board_config.h`：板卡引脚、限位、速度及行程配置。
- `docs/`：硬件审计、引脚表和协议说明；本包已移除作者电脑路径。
- `tests/`、`tools/vision_sim.py`：主机测试和视觉协议模拟工具。

## 许可证

项目自有代码、文档及自有 PCB 设计文件以 MIT License 发布，见 [LICENSE](LICENSE)。嵌入工程的第三方符号、封装和库文件可能另受其来源许可约束，详见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。STMicroelectronics CMSIS/HAL 文件仍按各自上游许可证分发，见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) 和 `Drivers/` 下的许可证文件。



