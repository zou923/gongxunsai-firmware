# PCB design files

- `source/ProPrj_工训赛_2026-10-30.epro` is the latest native EasyEDA Pro project found in the source directory (2026-10-30).
- `reference/Netlist_PCB1_2026-10-18.tel` is the latest available PCB netlist (2026-10-18), used by the firmware pin and connectivity audit. It predates the native project above; re-export and compare it before relying on it for the 10-30 design.
- `manufacturing/Gerber_PCB1_2026-10-11_LEGACY.zip` is an older manufacturing export. It predates both the 10-18 netlist and 10-30 native project. Do not use it to fabricate the current board without regenerating outputs from the 10-30 project and checking them.

The directory also contained older project backups, schematic netlists, and a 10-09 schematic PDF. They were not included to keep the release focused on the newest source and explicitly useful reference files. No independent BOM was found.

The root MIT license applies to project-authored design files and documentation. Embedded third-party symbols, footprints, and library assets may have separate terms; see the relevant asset/source terms before redistribution or reuse.
