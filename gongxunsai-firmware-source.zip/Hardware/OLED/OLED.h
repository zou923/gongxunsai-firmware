#ifndef GONGXUNSAI_OLED_H
#define GONGXUNSAI_OLED_H

#include <stdint.h>

void OLED_Init(void);
void OLED_Clear(void);
void OLED_SetCursor(uint8_t page, uint8_t column);
void OLED_ShowChar(uint8_t page, uint8_t column, char character);
void OLED_ShowString(uint8_t page, uint8_t column, const char *string);
void OLED_ShowString6x8(uint8_t page, uint8_t column, const char *string);

#endif
