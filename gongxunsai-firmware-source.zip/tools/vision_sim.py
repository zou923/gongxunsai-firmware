#!/usr/bin/env python3
"""NEW DRAFT PROTOCOL: offline packet utility; serial requires explicit --port."""

from __future__ import annotations

import argparse
import binascii
import json
import struct
import sys
import unittest
from dataclasses import asdict, dataclass

FRAME_SIZE = 32
PAYLOAD_SIZE = 22
VISION_TYPE = 0x20
ITEM_LAYOUT = struct.Struct("<IHiiHB")


@dataclass(frozen=True)
class VisionItem:
    recognition_id: int = 1
    class_id: int = 0
    x_um: int = 0
    y_um: int = 0
    confidence_permille: int = 0
    recognition_status: int = 0


def crc16(data: bytes) -> int:
    return binascii.crc_hqx(data, 0xFFFF)


def encode_frame(message_type: int, sequence: int, payload: bytes) -> bytes:
    if not 0 <= message_type <= 255 or not 0 <= sequence <= 65535:
        raise ValueError("type or sequence out of range")
    if len(payload) > PAYLOAD_SIZE:
        raise ValueError("payload exceeds 22 bytes")
    header = struct.pack("<2sBBHBB", b"\xA5\x5A", 1, message_type, sequence, len(payload), 0)
    body = header + payload.ljust(PAYLOAD_SIZE, b"\0")
    return body + struct.pack("<H", crc16(body))


def decode_frame(packet: bytes) -> dict:
    if len(packet) != FRAME_SIZE:
        raise ValueError("frame must contain exactly 32 bytes")
    magic, version, kind, sequence, length, flags = struct.unpack("<2sBBHBB", packet[:8])
    if magic != b"\xA5\x5A" or version != 1 or length > PAYLOAD_SIZE or flags != 0:
        raise ValueError("invalid magic, version, payload length or reserved flags")
    if struct.unpack("<H", packet[30:])[0] != crc16(packet[:30]):
        raise ValueError("CRC mismatch")
    if any(packet[8 + length:30]):
        raise ValueError("nonzero payload padding")
    result = {"type": kind, "sequence": sequence, "length": length,
              "flags": flags, "payload_hex": packet[8:8 + length].hex()}
    if kind == VISION_TYPE:
        if length != ITEM_LAYOUT.size:
            raise ValueError("vision item payload must contain exactly 17 bytes")
        item = VisionItem(*ITEM_LAYOUT.unpack(packet[8:25]))
        validate_item(item)
        result["item"] = asdict(item)
    return result


def validate_item(item: VisionItem) -> None:
    limits = {
        "recognition_id": (0, 0xFFFFFFFF), "class_id": (0, 5),
        "x_um": (-0x80000000, 0x7FFFFFFF), "y_um": (-0x80000000, 0x7FFFFFFF),
        "confidence_permille": (0, 1000), "recognition_status": (0, 2),
    }
    for name, (low, high) in limits.items():
        if not low <= getattr(item, name) <= high:
            raise ValueError(f"{name} must be in [{low}, {high}]")


def encode_item(item: VisionItem, sequence: int) -> bytes:
    validate_item(item)
    payload = ITEM_LAYOUT.pack(item.recognition_id, item.class_id, item.x_um,
                               item.y_um, item.confidence_permille, item.recognition_status)
    return encode_frame(VISION_TYPE, sequence, payload)


class ProtocolTests(unittest.TestCase):
    GOLDEN_QUERY = bytes.fromhex(
        "a55a011034120000000000000000000000000000000000000000000000005806"
    )

    def test_crc_and_fixed_packet_oracles(self):
        self.assertEqual(crc16(b"123456789"), 0x29B1)
        self.assertEqual(encode_frame(0x10, 0x1234, b""), self.GOLDEN_QUERY)
        self.assertEqual(decode_frame(self.GOLDEN_QUERY)["sequence"], 0x1234)

    def test_signed_coordinate_boundaries(self):
        item = VisionItem(0xFFFFFFFF, 5, -0x80000000, 0x7FFFFFFF, 1000, 2)
        packet = encode_item(item, 65535)
        self.assertEqual(decode_frame(packet)["item"], asdict(item))
        expected = bytes.fromhex("78563412050018fcffffd0070000e80302")
        sample = VisionItem(0x12345678, 5, -1000, 2000, 1000, 2)
        self.assertEqual(encode_item(sample, 1)[8:25], expected)

    def test_malformed_packets(self):
        for position, value in ((0, 0), (1, 0), (2, 2), (6, 23), (7, 1), (8, 1)):
            with self.subTest(position=position):
                packet = bytearray(self.GOLDEN_QUERY)
                packet[position] = value
                packet[30:] = struct.pack("<H", crc16(packet[:30]))
                with self.assertRaises(ValueError):
                    decode_frame(bytes(packet))
        packet = bytearray(self.GOLDEN_QUERY)
        packet[30] ^= 1
        with self.assertRaises(ValueError):
            decode_frame(bytes(packet))
        with self.assertRaises(ValueError):
            decode_frame(self.GOLDEN_QUERY[:-1])
        with self.assertRaises(ValueError):
            decode_frame(self.GOLDEN_QUERY + b"\0")

    def test_invalid_vision_fields_and_size(self):
        for field, value in (("class_id", 6), ("class_id", -1),
                             ("confidence_permille", 1001), ("recognition_status", 3),
                             ("x_um", -0x80000001), ("recognition_id", 0x100000000)):
            with self.subTest(field=field):
                with self.assertRaises(ValueError):
                    encode_item(VisionItem(**{field: value}), 0)
        for offset, value in ((4, 6), (14, 0xE9), (16, 3)):
            payload = bytearray(ITEM_LAYOUT.pack(1, 0, 0, 0, 1000, 0))
            payload[offset] = value
            with self.assertRaises(ValueError):
                decode_frame(encode_frame(VISION_TYPE, 0, bytes(payload)))
        for size in (16, 18):
            with self.assertRaises(ValueError):
                decode_frame(encode_frame(VISION_TYPE, 0, bytes(size)))

    def test_encode_limits(self):
        for kind, sequence, payload in ((256, 0, b""), (0, 65536, b""), (0, 0, bytes(23))):
            with self.assertRaises(ValueError):
                encode_frame(kind, sequence, payload)


def run_self_test() -> bool:
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ProtocolTests)
    return unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful()


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true", help="run offline tests and exit")
    parser.add_argument("--decode", metavar="HEX", help="decode one 32-byte hexadecimal packet")
    transport = parser.add_mutually_exclusive_group()
    transport.add_argument("--dry-run", action="store_true", help="print packet only (default)")
    transport.add_argument("--port", help="explicitly send ONE vision packet using pyserial, e.g. COM7")
    parser.add_argument("--baud", type=int, default=115200, help="proposed UART baud rate")
    parser.add_argument("--timeout", type=float, default=1.0, help="serial read/write timeout in seconds")
    parser.add_argument("--sequence", type=int, default=0)
    parser.add_argument("--recognition-id", type=int, default=1)
    parser.add_argument("--class-id", type=int, default=0)
    parser.add_argument("--x-um", type=int, default=0)
    parser.add_argument("--y-um", type=int, default=0)
    parser.add_argument("--confidence", type=int, default=0, help="confidence in permille: 0..1000")
    parser.add_argument("--status", type=int, default=0, help="draft recognition status: 0..2")
    args = parser.parse_args(argv)
    if args.self_test:
        return 0 if run_self_test() else 1
    if args.decode is not None:
        if args.port:
            parser.error("--decode cannot be combined with --port")
        try:
            print(json.dumps(decode_frame(bytes.fromhex(args.decode)), indent=2))
        except ValueError as exc:
            parser.error(str(exc))
        return 0
    if args.baud <= 0 or args.timeout <= 0:
        parser.error("--baud and --timeout must be positive")
    item = VisionItem(args.recognition_id, args.class_id, args.x_um, args.y_um,
                      args.confidence, args.status)
    try:
        packet = encode_item(item, args.sequence)
    except ValueError as exc:
        parser.error(str(exc))
    print("NEW DRAFT PROTOCOL: agree field meanings with the RK team before integration.")
    print("TX hex:", packet.hex())
    print(json.dumps(decode_frame(packet), indent=2))
    if not args.port:
        print("DRY RUN: no serial port opened.")
        return 0
    try:
        import serial  # Optional: never imported for dry runs, decode or self-test.
    except ImportError:
        parser.error("--port requires pyserial; offline commands need only the Python standard library")
    try:
        with serial.Serial(port=args.port, baudrate=args.baud, bytesize=8, parity="N",
                           stopbits=1, timeout=args.timeout, write_timeout=args.timeout) as connection:
            sent = connection.write(packet)
            if sent != FRAME_SIZE:
                raise OSError(f"short serial write: {sent}/{FRAME_SIZE}")
            connection.flush()
            reply = connection.read(FRAME_SIZE)
            print(f"Sent {sent} bytes; received {len(reply)} bytes.")
            if reply:
                print("RX hex:", reply.hex())
                try:
                    print(json.dumps(decode_frame(reply), indent=2))
                except ValueError as exc:
                    print(f"RX is not a complete valid frame: {exc}", file=sys.stderr)
    except (OSError, serial.SerialException) as exc:
        print(f"Serial error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
