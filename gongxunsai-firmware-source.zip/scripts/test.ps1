$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
Push-Location $projectRoot
try {
    $gcc = (Get-Command gcc -ErrorAction Stop).Source
    $cases = @(
        @{ Name='protocol'; Args=@('-std=c11','-Wall','-Wextra','-Werror','-pedantic','-IShared','tests/test_protocol.c','Shared/protocol.c','-o','build/test_protocol.exe') },
        @{ Name='vision'; Args=@('-std=c11','-Wall','-Wextra','-Werror','-pedantic','-IShared','tests/test_vision.c','Shared/protocol.c','Shared/vision_protocol.c','-o','build/test_vision.exe') },
        @{ Name='io'; Args=@('-std=c11','-Wall','-Wextra','-Werror','-pedantic','-IShared','-IIO/Inc','tests/test_io.c','Shared/protocol.c','IO/Src/button.c','IO/Src/limit_switch.c','IO/Src/output_ctrl.c','IO/Src/servo.c','IO/Src/safety.c','IO/Src/io_app.c','IO/Src/io_protocol.c','IO/Src/io_indicator.c','-o','build/test_io.exe') },
        @{ Name='master'; Args=@('-std=c11','-Wall','-Wextra','-Werror','-pedantic','-IShared','-IMaster/Inc','tests/test_master.c','Shared/protocol.c','Master/Src/app_state.c','Master/Src/io_spi.c','Master/Src/master_display.c','-o','build/test_master.exe') }
        @{ Name='motion'; Args=@('-std=c11','-Wall','-Wextra','-Werror','-pedantic','-IConfig','-IMaster/Inc','tests/test_motion.c','Master/Src/x42s_driver.c','Master/Src/motion.c','-o','build/test_motion.exe') }
        @{ Name='x42s_protocol'; Args=@('-std=c11','-Wall','-Wextra','-Werror','-pedantic','-IMaster/Inc','tests/test_x42s_protocol.c','Master/Src/x42s_protocol.c','-o','build/test_x42s_protocol.exe') },
        @{ Name='corexy_motion'; Args=@('-std=c11','-Wall','-Wextra','-Werror','-pedantic','-IMaster/Inc','tests/test_corexy_motion.c','Master/Src/corexy_motion.c','-o','build/test_corexy_motion.exe') }
        @{ Name='corexy_command'; Args=@('-std=c11','-Wall','-Wextra','-Werror','-pedantic','-IMaster/Inc','tests/test_corexy_command.c','Master/Src/corexy_command.c','-o','build/test_corexy_command.exe') }
        @{ Name='four_axis_command'; Args=@('-std=c11','-Wall','-Wextra','-Werror','-pedantic','-IMaster/Inc','tests/test_four_axis_command.c','Master/Src/four_axis_command.c','-o','build/test_four_axis_command.exe') }
        @{ Name='four_axis_motion'; Args=@('-std=c11','-Wall','-Wextra','-Werror','-pedantic','-IMaster/Inc','tests/test_four_axis_motion.c','Master/Src/four_axis_motion.c','-o','build/test_four_axis_motion.exe') }
        @{ Name='four_axis_zero'; Args=@('-std=c11','-Wall','-Wextra','-Werror','-pedantic','-IMaster/Inc','tests/test_four_axis_zero.c','Master/Src/four_axis_zero.c','-o','build/test_four_axis_zero.exe') }
        @{ Name='four_axis_limits'; Args=@('-std=c11','-Wall','-Wextra','-Werror','-pedantic','-IMaster/Inc','tests/test_four_axis_limits.c','Master/Src/four_axis_limits.c','-o','build/test_four_axis_limits.exe') }
        @{ Name='debug_trigger'; Args=@('-std=c11','-Wall','-Wextra','-Werror','-pedantic','-IShared','tests/test_debug_trigger.c','Shared/debug_trigger.c','-o','build/test_debug_trigger.exe') }
        @{ Name='servo_command'; Args=@('-std=c11','-Wall','-Wextra','-Werror','-pedantic','-IShared','tests/test_servo_command.c','Shared/servo_command.c','-o','build/test_servo_command.exe') }
    )
    foreach ($case in $cases) {
        & $gcc @($case.Args)
        if ($LASTEXITCODE -ne 0) { throw "$($case.Name) host compilation failed." }
        & ".\build\test_$($case.Name).exe"
        if ($LASTEXITCODE -ne 0) { throw "$($case.Name) host test failed." }
    }
    & python tools/vision_sim.py --self-test
    if ($LASTEXITCODE -ne 0) { throw 'Python protocol self-test failed.' }
}
finally { Pop-Location }
