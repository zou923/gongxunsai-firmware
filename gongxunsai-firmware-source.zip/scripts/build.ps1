$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot

# Windows Ninja/binutils do not consistently accept Chinese path arguments.
# Map this folder temporarily to an unused drive; all files stay in the project.
$usedDrives = [System.Environment]::GetLogicalDrives()
$drive = @('Z:', 'Y:', 'X:', 'W:', 'V:', 'U:', 'T:', 'S:', 'R:', 'Q:', 'P:') |
    Where-Object { $usedDrives -notcontains "$_\" } |
    Select-Object -First 1
if (-not $drive) { throw 'No free drive letter (P: through Z:) for the build.' }

& subst $drive $projectRoot
if ($LASTEXITCODE -ne 0) { throw 'Could not create the temporary build drive.' }
try {
    $sourceDir = "$drive/"
    $buildDir = "${sourceDir}build"
    $toolchain = "${sourceDir}cmake/arm-none-eabi-gcc.cmake"
    # Dependency paths from an earlier build may use a different drive mapping.
    $dependencyCache = Join-Path $projectRoot 'build\.ninja_deps'
    if (Test-Path -LiteralPath $dependencyCache) {
        Remove-Item -LiteralPath $dependencyCache
    }
    & cmake --fresh -S $sourceDir -B $buildDir -G Ninja "-DCMAKE_TOOLCHAIN_FILE=$toolchain"
    if ($LASTEXITCODE -ne 0) { throw "CMake configuration failed (exit $LASTEXITCODE)." }
    & cmake --build $buildDir --parallel
    if ($LASTEXITCODE -ne 0) { throw "Build failed (exit $LASTEXITCODE)." }

    # IntelliSense must still find source files after removing the drive mapping.
    $compileCommands = Join-Path $projectRoot 'build\compile_commands.json'
    $contents = [System.IO.File]::ReadAllText($compileCommands)
    $contents = $contents.Replace($sourceDir, ($projectRoot.Replace('\', '/') + '/'))
    $contents = $contents.Replace(($drive + '\\'), ($projectRoot.Replace('\', '/') + '/'))
    [System.IO.File]::WriteAllText($compileCommands, $contents, [System.Text.UTF8Encoding]::new($false))
}
finally {
    & subst $drive /D
}
