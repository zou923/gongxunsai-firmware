param(
    [ValidateSet('cmsis-dap', 'stlink')][string]$Probe = 'cmsis-dap',
    [Parameter(Mandatory = $true)]
    [ValidateSet('gongxunsai', 'sorter-master', 'sorter-io')][string]$Target
)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
& powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'build.ps1')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$openOcd = $env:OPENOCD_EXE
if (-not $openOcd) {
    $openOcd = (Get-Command openocd -ErrorAction Stop).Source
}
Push-Location -LiteralPath $projectRoot
try {
    # Keep tool arguments ASCII so the Chinese project folder is supported.
    if ($Probe -eq 'cmsis-dap') {
        # DAPLink/CMSIS-DAP v2 exposes the probe through USB Bulk.  Do not
        # force the HID backend: that makes OpenOCD fail during CMD_INFO on
        # otherwise correctly enumerated DAPLink probes.
        $openOcdArgs = @(
            '-f', "openocd/$Probe-stm32f103.cfg",
            '-c', 'cmsis-dap backend usb_bulk',
            '-c', 'adapter speed 1000',
            '-c', 'stm32f1x.cpu configure -work-area-size 0',
            '-c', 'gdb_port disabled',
            '-c', "program {build/$Target.elf} verify reset exit"
        )
        & $openOcd @openOcdArgs
    }
    else {
        & $openOcd -f "openocd/$Probe-stm32f103.cfg" -c "program {build/$Target.elf} verify reset exit"
    }
    if ($LASTEXITCODE -ne 0) { throw "OpenOCD failed (exit $LASTEXITCODE). Check power and SWD wiring." }
}
finally {
    Pop-Location
}
