$ErrorActionPreference = 'Stop'
$flashScript = Join-Path $PSScriptRoot 'flash.ps1'
& powershell -NoProfile -ExecutionPolicy Bypass -File $flashScript `
    -Probe cmsis-dap -Target sorter-master
exit $LASTEXITCODE
