#ifndef SORTER_BOARD_CONFIG_H
#define SORTER_BOARD_CONFIG_H

/* PCB source: Hardware/PCB/reference/Netlist_PCB1_2026-10-18.tel.
 * Policy defaults below are firmware choices, not measured hardware settings. */
#define BOARD_CLOCK_HZ 8000000U
#define BOARD_UART_BAUD 115200U
#define BOARD_SPI_POLL_MS 20U
#define BOARD_SPI_TRANSFER_TIMEOUT_MS 25U
#define BOARD_LINK_TIMEOUT_MS 250U
#define BOARD_INPUT_DEBOUNCE_MS 20U

/* epro 2026-10-11 labels CN1 as camera UART; H3/H6 as debug UART.
 * Pin connections agree with the latest netlist; external cabling is unverified.
 * 115200 8N1 is the NEW stage-2 firmware agreement. */
#define BOARD_VISION_UART_ENABLED 1
#define BOARD_DEBUG_UART_ENABLED 1

/* IO input bits: START plus active-low limit inputs.
 * CN3/PA1 is used as the Z upward reference switch by current firmware. */
#define BOARD_IO_VALID_INPUT_MASK 0x006DU /* START plus PA1/PB1/PB13/PB14 limits. */
#define BOARD_IO_ACTIVE_LOW_MASK 0x006DU  /* All confirmed inputs assert at GND. */
#define BOARD_IO_X_LIMIT_MASK 0x0020U     /* IO_STATUS bit 5: PB13 / X+. */
#define BOARD_IO_Y_LIMIT_MASK 0x0040U     /* IO_STATUS bit 6: PB14 / Y. */
#define BOARD_IO_Z_LIMIT_MASK 0x0004U     /* IO_STATUS bit 2: PA1 / CN3 / Z reference. */
#define BOARD_IO_S_LIMIT_MASK 0x0008U     /* IO_STATUS bit 3: PB1 / camera. */
#define BOARD_STOP_CONFIRMED 0
#define BOARD_LIMITS_CONFIRMED 1 /* PB13 is confirmed as the X+ limit. */
#define BOARD_OUTPUTS_CONFIRMED 0
#define BOARD_MACHINE_COMMISSIONED 0

#define BOARD_MOTOR_COUNT 4U
#define BOARD_MOTOR_ID_UNASSIGNED 0U

/* CoreXY provisional calibration. Keep disabled until the mechanism is installed
 * and pulley, belt, travel and motor direction have been measured. */
#define BOARD_COREXY_CONFIG_CONFIRMED 1
#define BOARD_COREXY_MOTOR1_ID 1U
#define BOARD_COREXY_MOTOR2_ID 2U
#define BOARD_Z_MOTOR_ID 3U
#define BOARD_S_MOTOR_ID 4U
#define BOARD_Z_AXIS_INVERT 1U /* Positive Z coordinate moves physically downward. */
/* Temporary bench mode while motors 1 and 2 are disconnected. ZERO establishes
 * a software origin without querying all four X42S encoders. Set to 1 after
 * addresses 1..4 are connected and responding. */
#define BOARD_FOUR_AXIS_ZERO_QUERY_ENABLED 0
#define BOARD_COREXY_PULSES_PER_REV 12800U /* 0.9-degree motors, X42S MStep=32. */
#define BOARD_COREXY_TRAVEL_UM_PER_REV 40000U /* TODO: belt pitch * pulley teeth. */
#define BOARD_COREXY_MAX_RPM 60U
#define BOARD_COREXY_ACCELERATION 10U
#define BOARD_COREXY_X_MAX_UM 222000
#define BOARD_COREXY_Y_MAX_UM 208000
#define BOARD_COREXY_MOTOR1_INVERT 1
#define BOARD_COREXY_MOTOR2_INVERT 1

/* Live EasyEDA verification: project 工训赛, schematic P1, 2026-10-18. */
#define BOARD_MASTER_X42S_TX_PIN 10U /* PB10 -> CN2.7 */
#define BOARD_MASTER_X42S_RX_PIN 11U /* PB11 -> CN2.8 */
#define BOARD_IO_START_PIN 0U        /* PB0, 10K pull-up, switch to GND. */
#define BOARD_IO_STOP_PIN 15U        /* PB15 -> CN8.2, 10K pull-up. */
#define BOARD_IO_SERVO_PWM_PIN 8U    /* PA8 -> R27 220R -> H1.3. */
#define BOARD_IO_IRQ_PIN 5U          /* IO PB5 -> MASTER PB0. */
/* CN3..CN7 pins are confirmed; their mechanical roles are not. */
#define BOARD_LIMIT_CN3_PIN 1U       /* PA1 / SPA1_NC */
#define BOARD_LIMIT_CN4_PIN 1U       /* PB1 / SPB1_NC */
#define BOARD_LIMIT_CN5_PIN 12U      /* PB12 / SPB12_NC */
#define BOARD_LIMIT_CN6_PIN 13U      /* PB13 / SPB13_NC */
#define BOARD_LIMIT_CN7_PIN 14U      /* PB14 / SPB14_NC */

#endif

