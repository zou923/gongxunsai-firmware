# Third-party notices

The project includes STMicroelectronics STM32F1 CMSIS and HAL sources under `Drivers/`. They retain their upstream license notices:

- CMSIS Core: `Drivers/CMSIS/LICENSE.txt`
- STM32F1 CMSIS device headers: `Drivers/CMSIS/Device/ST/STM32F1xx/License.md`
- STM32F1 HAL: `Drivers/STM32F1xx_HAL_Driver/LICENSE.md`

The root MIT License applies to project-authored code, documentation, and PCB design files. Third-party files remain subject to their respective license terms.

