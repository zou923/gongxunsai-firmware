#include "io_protocol.h"
#include "io_internal.h"
#include <string.h>

bool io_app_receive(io_app_t *app, const uint8_t request[PROTOCOL_FRAME_SIZE],
                    uint32_t now_ms)
{
    protocol_frame_t frame;
    io_app_refresh_safety(app, now_ms);
    if (!protocol_decode(request, &frame)) {
        app->last_command_result = IO_RESULT_BAD_FRAME;
        return false;
    }
    if (frame.type != PROTO_IO_QUERY && frame.type != PROTO_IO_SAFE &&
        frame.type != PROTO_IO_RESET && frame.type != PROTO_IO_SERVO) {
        app->last_command_result = IO_RESULT_BAD_COMMAND;
        return false;
    }
    if ((frame.type == PROTO_IO_SERVO && frame.length != 2u) ||
        (frame.type != PROTO_IO_SERVO && frame.length != 0u)) {
        app->last_command_result = IO_RESULT_BAD_LENGTH;
        return false;
    }
    if (!protocol_seq_accept(frame.sequence, &app->last_sequence,
                              &app->sequence_initialized)) {
        app->last_command_result = IO_RESULT_BAD_SEQUENCE;
        return false;
    }
    if (frame.type == PROTO_IO_SERVO) {
        uint16_t pulse_us = protocol_read_u16(frame.payload);
        if (pulse_us != 0u && (pulse_us < 500u || pulse_us > 1100u)) {
            app->last_command_result = IO_RESULT_BAD_COMMAND;
            return false;
        }
        app->servo_target_us = pulse_us;
    }
    if (frame.type == PROTO_IO_RESET) {
        /* Check the PREVIOUS safe communication before refreshing its age. */
        if (!io_safety_reset(&app->safety, io_app_inputs_released(app), now_ms)) {
            app->last_command_result = IO_RESULT_RESET_BLOCKED;
            return true;
        }
        app->rising_events = 0u;
    }
    io_safety_communication(&app->safety, now_ms);
    app->last_command_result = IO_RESULT_OK;
    return true;
}

void io_app_status(const io_app_t *app, uint8_t reply[PROTOCOL_FRAME_SIZE],
                   uint32_t now_ms)
{
    protocol_frame_t frame;
    io_safety_t reported = app->safety;
    uint16_t raw_active = app->inputs_sampled ? io_app_raw_active(app) : 0u;
    memset(&frame, 0, sizeof(frame));
    io_safety_tick(&reported, (raw_active & IO_INPUT_STOP) != 0u,
                   (raw_active & IO_INPUT_LIMITS) != 0u,
                   app->input_configuration_fault, now_ms);
    frame.type = PROTO_IO_STATUS;
    frame.sequence = app->last_sequence;
    frame.length = PROTOCOL_PAYLOAD_SIZE;
    protocol_write_u16(frame.payload, app->raw_levels);
    protocol_write_u16(frame.payload + 2u, app->active_inputs);
    protocol_write_u16(frame.payload + 4u, app->valid_inputs);
    protocol_write_u16(frame.payload + 6u, (uint16_t)(app->rising_events |
        (app->debug_led_toggle ? IO_EVENT_DEBUG_LED_TOGGLE : 0u)));
    protocol_write_u32(frame.payload + 8u, reported.faults);
    protocol_write_u16(frame.payload + 12u, app->output_bits);
    protocol_write_u16(frame.payload + 14u, app->servo_us);
    frame.payload[16] = reported.state;
    frame.payload[17] = app->last_command_result;
    protocol_write_u32(frame.payload + 18u, now_ms - app->boot_ms);
    (void)protocol_encode(&frame, reply);
}
