#include "board.h"
#include "board_config.h"
#include "io_app.h"
#include "io_indicator.h"
#include "protocol.h"
#include "servo_command.h"
#include "stm32f1xx.h"

int main(void)
{
    io_app_t app;
    const io_config_t config = {
        .valid_mask = BOARD_IO_VALID_INPUT_MASK,
        .active_low_mask = BOARD_IO_ACTIVE_LOW_MASK,
        .stop_confirmed = BOARD_STOP_CONFIRMED,
        .limits_confirmed = BOARD_LIMITS_CONFIRMED,
        .outputs_confirmed = BOARD_OUTPUTS_CONFIRMED,
        .communication_timeout_ms = BOARD_LINK_TIMEOUT_MS,
        .debounce_ms = BOARD_INPUT_DEBOUNCE_MS
    };
    uint8_t request[PROTOCOL_FRAME_SIZE];
    uint8_t reply[PROTOCOL_FRAME_SIZE];
    uint8_t spi_diag = 1U;
    uint16_t servo_applied_us = 0u;
    uint32_t next_servo_step_ms = 0u;
    servo_command_t servo_command;

    board_init();
    servo_command_init(&servo_command);
    static const uint8_t banner[] = "IO stage-2 safe framework\r\n";
    (void)board_uart_write(BOARD_UART_DEBUG, banner, sizeof banner - 1U);
    io_app_init(&app, &config, board_millis());
    io_app_tick(&app, board_read_inputs(), board_millis());
    io_app_status(&app, reply, board_millis());
    (void)board_spi_slave_arm(reply);

    for (;;) {
        uint32_t now = board_millis();
        uint8_t debug_byte;
        board_service(now);
        while (board_uart_read(BOARD_UART_DEBUG, &debug_byte)) {
            const bool standalone = !servo_command_active(&servo_command);
            const bool servo_ready = servo_command_feed(&servo_command, debug_byte,
                                                          &app.servo_target_us);
            if (debug_byte == (uint8_t)'1' && standalone) {
                static const uint8_t reply_text[] = "MASTER LED 1s\r\n";
                io_app_debug_led_event(&app);
                (void)board_uart_write(BOARD_UART_DEBUG, reply_text, sizeof reply_text - 1U);
            }
            if (servo_ready) {
                uint8_t text[] = "SERVO 0000us\r\n";
                if (app.servo_target_us == 0u) {
                    static const uint8_t off[] = "SERVO OFF\r\n";
                    board_force_safe_outputs();
                    (void)board_uart_write(BOARD_UART_DEBUG, off, sizeof off - 1U);
                } else {
                    text[6] = (uint8_t)('0' + app.servo_target_us / 1000u);
                    text[7] = (uint8_t)('0' + (app.servo_target_us / 100u) % 10u);
                    text[8] = (uint8_t)('0' + (app.servo_target_us / 10u) % 10u);
                    text[9] = (uint8_t)('0' + app.servo_target_us % 10u);
                    (void)board_uart_write(BOARD_UART_DEBUG, text, sizeof text - 1U);
                }
            }
        }
        io_app_tick(&app, board_read_inputs(), now);
        if (board_spi_take(request)) {
            protocol_frame_t check;
            if (request[0] != 0xA5U || request[1] != 0x5AU) {
                spi_diag = 3U; /* Wrong byte alignment or MOSI data. */
            } else if (request[2] != PROTOCOL_VERSION ||
                       (request[3] != PROTO_IO_QUERY && request[3] != PROTO_IO_SERVO)) {
                spi_diag = 4U; /* Header arrived, command fields differ. */
            } else if (!protocol_decode(request, &check)) {
                spi_diag = 5U; /* Header is right; CRC or padding is wrong. */
            } else {
                spi_diag = 6U; /* Wire frame is valid; app rejected it. */
            }
            (void)io_app_receive(&app, request, now);
            io_app_status(&app, reply, now);
            (void)board_spi_slave_arm(reply);
        }
        /* A reset can occur while MASTER holds NSS low.  The initial arm then
         * legitimately fails; retry during each idle gap instead of remaining
         * permanently offline until another reset happens at a lucky time. */
        (void)board_spi_slave_arm(reply);
        const bool communication_online = app.sequence_initialized &&
            (app.safety.faults & IO_FAULT_COMM_TIMEOUT) == 0U;
        if (!servo_output_permitted(app.servo_target_us,communication_online,
                                    BOARD_MACHINE_COMMISSIONED != 0)) {
            board_force_safe_outputs();
            servo_applied_us = 0u;
        } else {
            if (servo_applied_us == 0u) servo_applied_us = SERVO_PULSE_MIN_US;
            if ((int32_t)(now-next_servo_step_ms) >= 0) {
                servo_applied_us=servo_slew_step(servo_applied_us,app.servo_target_us,5u);
                next_servo_step_ms=now+20u;
            }
            (void)board_servo_write_us(servo_applied_us);
        }
        if (communication_online) {
            board_status_led(io_indicator_led(true, app.safety.faults, now));
        } else if (board_diagnostics.spi_rx_complete != 0U) {
            /* 3..6 short flashes identify the first rejected protocol layer. */
            const uint32_t phase = now % 6000U;
            board_status_led(phase < (uint32_t)spi_diag * 600U &&
                             (phase % 600U) < 300U);
        } else if (board_diagnostics.spi_nss_starts != 0U) {
            /* Two short flashes: NSS arrived, but 32 SPI bytes never completed. */
            const uint32_t phase = now % 1200U;
            board_status_led(phase < 100U || (phase >= 200U && phase < 300U));
        } else {
            /* One short flash: no NSS falling edge has reached the IO MCU. */
            board_status_led((now % 1200U) < 100U);
        }
        __WFI();
    }
}
