#include "io_app.h"
#include "io_internal.h"
#include <string.h>

void io_app_force_safe(io_app_t *app)
{
    io_output_ctrl_safe(&app->outputs);
    io_servo_disable(&app->servo);
    app->output_bits = app->outputs.bits;
    app->servo_us = app->servo.pulse_us;
}

uint16_t io_app_raw_active(const io_app_t *app)
{
    return (uint16_t)((app->raw_levels ^ app->config.active_low_mask) &
                       app->valid_inputs);
}

void io_app_refresh_safety(io_app_t *app, uint32_t now_ms)
{
    uint16_t raw_active = app->inputs_sampled ? io_app_raw_active(app) : 0u;
    io_safety_tick(&app->safety, (raw_active & IO_INPUT_STOP) != 0u,
                   (raw_active & IO_INPUT_LIMITS) != 0u,
                   app->input_configuration_fault, now_ms);
    io_app_force_safe(app);
}

bool io_app_inputs_released(const io_app_t *app)
{
    return app->inputs_sampled && io_app_raw_active(app) == 0u &&
           app->active_inputs == 0u && app->start.settled &&
           app->stop.settled && io_limits_settled(&app->limits);
}

void io_app_init(io_app_t *app, const io_config_t *config, uint32_t now_ms)
{
    bool confirmed;
    memset(app, 0, sizeof(*app));
    if (config != NULL) {
        app->config = *config;
    } else {
        app->config.communication_timeout_ms = 250u;
        app->config.debounce_ms = 20u;
    }
    app->boot_ms = now_ms;
    app->valid_inputs = (uint16_t)(app->config.valid_mask & IO_INPUT_ALL);
    if (!app->config.stop_confirmed) {
        app->valid_inputs &= (uint16_t)~IO_INPUT_STOP;
    }
    if (!app->config.limits_confirmed) {
        app->valid_inputs &= (uint16_t)~IO_INPUT_LIMITS;
    }
    app->input_configuration_fault =
        (app->config.valid_mask & (uint16_t)~IO_INPUT_ALL) != 0u ||
        (app->config.active_low_mask & (uint16_t)~app->config.valid_mask) != 0u ||
        (app->config.stop_confirmed &&
         (app->config.valid_mask & IO_INPUT_STOP) == 0u) ||
        (app->config.limits_confirmed &&
         (app->config.valid_mask & IO_INPUT_LIMITS) == 0u) ||
        app->config.communication_timeout_ms == 0u ||
        app->config.communication_timeout_ms > INT32_MAX ||
        app->config.debounce_ms == 0u || app->config.debounce_ms > INT32_MAX;
    confirmed = !app->input_configuration_fault &&
                app->valid_inputs == IO_INPUT_ALL &&
                app->config.stop_confirmed && app->config.limits_confirmed &&
                app->config.outputs_confirmed;
    io_button_init(&app->start, app->config.debounce_ms);
    io_button_init(&app->stop, app->config.debounce_ms);
    io_limits_init(&app->limits, app->config.debounce_ms);
    io_output_ctrl_init(&app->outputs);
    io_servo_init(&app->servo);
    io_safety_init(&app->safety, confirmed,
                   app->config.communication_timeout_ms, now_ms);
    io_app_refresh_safety(app, now_ms);
}

void io_app_tick(io_app_t *app, uint16_t raw_levels, uint32_t now_ms)
{
    uint16_t raw_active;
    app->raw_levels = raw_levels;
    app->inputs_sampled = true;
    raw_active = io_app_raw_active(app);
    /* A confirmed raw STOP/limit assertion latches before any debouncer. */
    io_app_refresh_safety(app, now_ms);
    if (io_button_tick(&app->start, (raw_active & IO_INPUT_START) != 0u, now_ms)) {
        app->rising_events |= IO_INPUT_START;
    }
    if (io_button_tick(&app->stop, (raw_active & IO_INPUT_STOP) != 0u, now_ms)) {
        app->rising_events |= IO_INPUT_STOP;
    }
    app->rising_events |= (uint16_t)((uint16_t)io_limits_tick(
        &app->limits, (uint8_t)(raw_active >> 2u), now_ms) << 2u);
    app->active_inputs = (uint16_t)((app->start.active ? IO_INPUT_START : 0u) |
        (app->stop.active ? IO_INPUT_STOP : 0u) | ((uint16_t)app->limits.active << 2u));
    app->active_inputs &= app->valid_inputs;
    app->rising_events &= app->valid_inputs;
}

void io_app_debug_led_event(io_app_t *app)
{
    if (app != NULL) app->debug_led_toggle = !app->debug_led_toggle;
}
