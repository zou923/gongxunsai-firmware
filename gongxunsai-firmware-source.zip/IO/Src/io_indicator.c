#include "io_indicator.h"
bool io_indicator_led(bool communication_online, uint32_t faults, uint32_t now_ms)
{
    if (!communication_online) return ((now_ms / 250u) & 1u) == 0u;
    if (faults == 0u) return true;
    return ((now_ms / 1000u) & 1u) == 0u;
}
