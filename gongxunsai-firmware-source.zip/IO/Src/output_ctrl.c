#include "output_ctrl.h"

void io_output_ctrl_safe(io_output_ctrl_t *outputs)
{
    outputs->bits = 0u;
}

void io_output_ctrl_init(io_output_ctrl_t *outputs)
{
    io_output_ctrl_safe(outputs);
}
