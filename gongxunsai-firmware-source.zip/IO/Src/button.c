#include "button.h"
#include <string.h>

void io_button_init(io_button_t *button, uint32_t debounce_ms)
{
    memset(button, 0, sizeof(*button));
    button->debounce_ms = debounce_ms;
}

bool io_button_tick(io_button_t *button, bool raw_active, uint32_t now_ms)
{
    bool rising = false;
    if (!button->initialized) {
        button->initialized = true;
        button->candidate_active = raw_active;
        button->active = raw_active;
        button->candidate_since_ms = now_ms;
        return false;
    }
    if (raw_active != button->candidate_active) {
        button->candidate_active = raw_active;
        button->candidate_since_ms = now_ms;
        button->settled = false;
    }
    if ((uint32_t)(now_ms - button->candidate_since_ms) >= button->debounce_ms) {
        button->settled = true;
        if (button->active != button->candidate_active) {
            button->active = button->candidate_active;
            rising = button->active && button->armed;
        }
        if (!button->active) {
            button->armed = true;
        }
    }
    return rising;
}
