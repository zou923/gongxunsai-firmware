#include "safety.h"

static void update_state(io_safety_t *safety)
{
    safety->state = safety->faults == 0u ? IO_SAFETY_DISABLED : IO_SAFETY_LATCHED;
}

void io_safety_init(io_safety_t *safety, bool configuration_confirmed,
                    uint32_t timeout_ms, uint32_t now_ms)
{
    safety->configuration_confirmed = configuration_confirmed;
    safety->timeout_ms = timeout_ms;
    safety->last_communication_ms = now_ms;
    safety->communication_seen = false;
    safety->faults = configuration_confirmed ? 0u : IO_FAULT_CONFIG_UNCONFIRMED;
    update_state(safety);
}

void io_safety_tick(io_safety_t *safety, bool raw_stop, bool raw_limit,
                    bool input_fault, uint32_t now_ms)
{
    if (!safety->configuration_confirmed) {
        safety->faults |= IO_FAULT_CONFIG_UNCONFIRMED;
    }
    if ((uint32_t)(now_ms - safety->last_communication_ms) >= safety->timeout_ms) {
        safety->faults |= IO_FAULT_COMM_TIMEOUT;
    }
    if (raw_stop) {
        safety->faults |= IO_FAULT_STOP_LATCH;
    }
    if (raw_limit) {
        safety->faults |= IO_FAULT_LIMIT_LATCH;
    }
    if (input_fault) {
        safety->faults |= IO_FAULT_INPUT_FAULT;
    }
    update_state(safety);
}

void io_safety_communication(io_safety_t *safety, uint32_t now_ms)
{
    safety->last_communication_ms = now_ms;
    safety->communication_seen = true;
}

bool io_safety_reset(io_safety_t *safety, bool released_and_settled,
                     uint32_t now_ms)
{
    if (!safety->configuration_confirmed || !released_and_settled ||
        !safety->communication_seen ||
        (uint32_t)(now_ms - safety->last_communication_ms) >= safety->timeout_ms) {
        return false;
    }
    safety->faults = 0u;
    update_state(safety);
    return true;
}
