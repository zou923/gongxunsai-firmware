#include "limit_switch.h"

void io_limits_init(io_limits_t *limits, uint32_t debounce_ms)
{
    unsigned i;
    limits->active = 0u;
    for (i = 0u; i < IO_LIMIT_COUNT; ++i) {
        io_button_init(&limits->channel[i], debounce_ms);
    }
}

uint8_t io_limits_tick(io_limits_t *limits, uint8_t raw_active, uint32_t now_ms)
{
    unsigned i;
    uint8_t rising = 0u;
    limits->active = 0u;
    for (i = 0u; i < IO_LIMIT_COUNT; ++i) {
        uint8_t mask = (uint8_t)(1u << i);
        if (io_button_tick(&limits->channel[i], (raw_active & mask) != 0u, now_ms)) {
            rising |= mask;
        }
        if (limits->channel[i].active) {
            limits->active |= mask;
        }
    }
    return rising;
}

bool io_limits_settled(const io_limits_t *limits)
{
    unsigned i;
    for (i = 0u; i < IO_LIMIT_COUNT; ++i) {
        if (!limits->channel[i].settled) {
            return false;
        }
    }
    return true;
}
