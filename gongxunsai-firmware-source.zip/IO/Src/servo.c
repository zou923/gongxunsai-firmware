#include "servo.h"

void io_servo_disable(io_servo_t *servo)
{
    servo->enabled = false;
    servo->pulse_us = 0u;
}

void io_servo_init(io_servo_t *servo)
{
    io_servo_disable(servo);
}
