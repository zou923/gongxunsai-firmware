#ifndef IO_SERVO_H
#define IO_SERVO_H
#include <stdbool.h>
#include <stdint.h>
typedef struct { bool enabled; uint16_t pulse_us; } io_servo_t;
/* Stage 2 has no enable API. Hardware PWM must also remain stopped. */
void io_servo_init(io_servo_t *servo);
void io_servo_disable(io_servo_t *servo);
#endif
