#ifndef IO_INTERNAL_H
#define IO_INTERNAL_H
#include "io_app.h"
/* Internal cross-module helpers; do not call from board code. */
void io_app_force_safe(io_app_t *app);
uint16_t io_app_raw_active(const io_app_t *app);
void io_app_refresh_safety(io_app_t *app, uint32_t now_ms);
bool io_app_inputs_released(const io_app_t *app);
#endif
