#ifndef IO_INDICATOR_H
#define IO_INDICATOR_H
#include <stdbool.h>
#include <stdint.h>
bool io_indicator_led(bool communication_online, uint32_t faults, uint32_t now_ms);
#endif
