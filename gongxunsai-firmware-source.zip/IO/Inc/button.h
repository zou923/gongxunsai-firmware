#ifndef IO_BUTTON_H
#define IO_BUTTON_H
#include <stdbool.h>
#include <stdint.h>
typedef struct {
    uint32_t debounce_ms;
    uint32_t candidate_since_ms;
    bool initialized;
    bool candidate_active;
    bool active;
    bool settled;
    bool armed;
} io_button_t;
void io_button_init(io_button_t *button, uint32_t debounce_ms);
/* True only on a debounced press after a debounced release, including boot. */
bool io_button_tick(io_button_t *button, bool raw_active, uint32_t now_ms);
#endif
