#ifndef IO_SAFETY_H
#define IO_SAFETY_H
#include <stdbool.h>
#include <stdint.h>
/* These values are part of the IO_STATUS wire contract. */
enum {
    IO_FAULT_CONFIG_UNCONFIRMED = 1u << 0,
    IO_FAULT_COMM_TIMEOUT = 1u << 1,
    IO_FAULT_STOP_LATCH = 1u << 2,
    IO_FAULT_INPUT_FAULT = 1u << 3,
    IO_FAULT_LIMIT_LATCH = 1u << 4
};
enum { IO_SAFETY_DISABLED = 0u, IO_SAFETY_LATCHED = 1u };
typedef struct {
    uint32_t faults;
    uint32_t timeout_ms;
    uint32_t last_communication_ms;
    bool communication_seen;
    bool configuration_confirmed;
    uint8_t state;
} io_safety_t;
void io_safety_init(io_safety_t *safety, bool configuration_confirmed,
                    uint32_t timeout_ms, uint32_t now_ms);
void io_safety_tick(io_safety_t *safety, bool raw_stop, bool raw_limit,
                    bool input_fault, uint32_t now_ms);
void io_safety_communication(io_safety_t *safety, uint32_t now_ms);
bool io_safety_reset(io_safety_t *safety, bool released_and_settled,
                     uint32_t now_ms);
#endif
