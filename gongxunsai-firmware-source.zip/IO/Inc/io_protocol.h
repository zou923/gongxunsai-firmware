#ifndef IO_PROTOCOL_H
#define IO_PROTOCOL_H
/* Public protocol entry points and wire contract are declared in io_app.h. */
#include "io_app.h"
#endif
