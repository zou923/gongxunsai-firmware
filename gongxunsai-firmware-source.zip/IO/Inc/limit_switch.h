#ifndef IO_LIMIT_SWITCH_H
#define IO_LIMIT_SWITCH_H
#include "button.h"
#define IO_LIMIT_COUNT 5u
typedef struct {
    io_button_t channel[IO_LIMIT_COUNT];
    uint8_t active;
} io_limits_t;
void io_limits_init(io_limits_t *limits, uint32_t debounce_ms);
uint8_t io_limits_tick(io_limits_t *limits, uint8_t raw_active, uint32_t now_ms);
bool io_limits_settled(const io_limits_t *limits);
#endif
