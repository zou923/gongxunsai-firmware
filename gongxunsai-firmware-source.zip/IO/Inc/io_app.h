#ifndef IO_APP_H
#define IO_APP_H
#include <stdbool.h>
#include <stdint.h>
#include "button.h"
#include "limit_switch.h"
#include "output_ctrl.h"
#include "servo.h"
#include "safety.h"
#include "protocol.h"

/* Raw connector order only; LIMIT0..4 do not imply axis assignments. */
#define IO_INPUT_START  ((uint16_t)(1u << 0)) /* PB0 */
#define IO_INPUT_STOP   ((uint16_t)(1u << 1)) /* PB15 */
#define IO_INPUT_LIMIT0 ((uint16_t)(1u << 2)) /* PA1 */
#define IO_INPUT_LIMIT1 ((uint16_t)(1u << 3)) /* PB1 */
#define IO_INPUT_LIMIT2 ((uint16_t)(1u << 4)) /* PB12 */
#define IO_INPUT_LIMIT3 ((uint16_t)(1u << 5)) /* PB13 */
#define IO_INPUT_LIMIT4 ((uint16_t)(1u << 6)) /* PB14 */
#define IO_INPUT_LIMITS ((uint16_t)0x007cu)
#define IO_INPUT_ALL    ((uint16_t)0x007fu)

typedef struct {
    uint16_t valid_mask;
    uint16_t active_low_mask;
    bool stop_confirmed;
    bool limits_confirmed;
    bool outputs_confirmed;
    uint32_t communication_timeout_ms;
    uint32_t debounce_ms;
} io_config_t;

/* last_command_result byte in IO_STATUS. */
enum {
    IO_RESULT_NONE = 0u,
    IO_RESULT_OK = 1u,
    IO_RESULT_BAD_FRAME = 2u,
    IO_RESULT_BAD_COMMAND = 3u,
    IO_RESULT_BAD_LENGTH = 4u,
    IO_RESULT_BAD_SEQUENCE = 5u,
    IO_RESULT_RESET_BLOCKED = 6u
};

typedef struct io_app_t {
    io_config_t config;
    io_button_t start;
    io_button_t stop;
    io_limits_t limits;
    io_output_ctrl_t outputs;
    io_servo_t servo;
    io_safety_t safety;
    uint32_t boot_ms;
    uint16_t raw_levels;
    uint16_t active_inputs;
    uint16_t rising_events;
    uint16_t valid_inputs;
    uint16_t output_bits;
    uint16_t servo_us;
    uint16_t servo_target_us;
    uint16_t last_sequence;
    uint8_t last_command_result;
    bool sequence_initialized;
    bool inputs_sampled;
    bool input_configuration_fault;
    bool debug_led_toggle;
} io_app_t;

void io_app_init(io_app_t *app, const io_config_t *config, uint32_t now_ms);
void io_app_tick(io_app_t *app, uint16_t raw_levels, uint32_t now_ms);
void io_app_debug_led_event(io_app_t *app);
/* True means a supported, correctly shaped new request was processed.
 * A blocked RESET is processed/echoed but does not refresh communication.
 * RESET requires an earlier fresh QUERY/SAFE and all inputs stably released.
 * Call tick with current raw inputs before receive in the board main loop. */
bool io_app_receive(io_app_t *app, const uint8_t request[PROTOCOL_FRAME_SIZE],
                    uint32_t now_ms);
/* STATUS payload offsets, all integers LE: raw16@0, active16@2, valid16@4,
 * latched rising16@6, faults32@8, outputs16@12, servo_us16@14, state8@16,
 * result8@17, uptime32@18. Sequence echoes last processed new request.
 * Events persist across replies; only successful RESET clears them.
 * SPI reply is returned on the NEXT transaction; master deduplicates events.
 * DISABLED means no faults, never an output-enable state in Stage 2. */
void io_app_status(const io_app_t *app, uint8_t reply[PROTOCOL_FRAME_SIZE],
                   uint32_t now_ms);
#endif
