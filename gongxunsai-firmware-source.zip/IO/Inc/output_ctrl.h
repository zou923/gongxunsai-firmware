#ifndef IO_OUTPUT_CTRL_H
#define IO_OUTPUT_CTRL_H
#include <stdint.h>
typedef struct { uint16_t bits; } io_output_ctrl_t;
/* No output-enable command exists before explicit future commissioning. */
void io_output_ctrl_init(io_output_ctrl_t *outputs);
void io_output_ctrl_safe(io_output_ctrl_t *outputs);
#endif
