#include "vision_protocol.h"
#include <limits.h>

static bool vision_item_valid(const vision_item_t *item)
{
    return item != NULL && item->class_id <= 5u &&
           item->confidence_permille <= 1000u && item->recognition_status <= 2u;
}

static int32_t read_i32(const uint8_t *data)
{
    uint32_t value = protocol_read_u32(data);
    /* Avoid implementation-defined conversion of uint32_t values above INT32_MAX. */
    return value <= (uint32_t)INT32_MAX
           ? (int32_t)value : -1 - (int32_t)(UINT32_MAX - value);
}

bool vision_decode_item(const protocol_frame_t *frame, vision_item_t *item)
{
    vision_item_t decoded;
    if (frame == NULL || item == NULL || frame->type != PROTO_VISION_ITEM ||
        frame->length != VISION_ITEM_PAYLOAD_SIZE || frame->flags != 0u) return false;
    decoded.recognition_id = protocol_read_u32(frame->payload);
    decoded.class_id = protocol_read_u16(frame->payload + 4);
    decoded.x_um = read_i32(frame->payload + 6);
    decoded.y_um = read_i32(frame->payload + 10);
    decoded.confidence_permille = protocol_read_u16(frame->payload + 14);
    decoded.recognition_status = frame->payload[16];
    if (!vision_item_valid(&decoded)) return false;
    *item = decoded;
    return true;
}

bool vision_encode_item(const vision_item_t *item, uint16_t sequence,
                        protocol_frame_t *frame)
{
    protocol_frame_t encoded = {0};
    if (frame == NULL || !vision_item_valid(item)) return false;
    encoded.type = PROTO_VISION_ITEM;
    encoded.sequence = sequence;
    encoded.length = VISION_ITEM_PAYLOAD_SIZE;
    protocol_write_u32(encoded.payload, item->recognition_id);
    protocol_write_u16(encoded.payload + 4, item->class_id);
    protocol_write_u32(encoded.payload + 6, (uint32_t)item->x_um);
    protocol_write_u32(encoded.payload + 10, (uint32_t)item->y_um);
    protocol_write_u16(encoded.payload + 14, item->confidence_permille);
    encoded.payload[16] = item->recognition_status;
    *frame = encoded;
    return true;
}
