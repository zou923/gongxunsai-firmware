#include "servo_command.h"

void servo_command_init(servo_command_t *parser)
{
    if (parser != 0) {
        parser->value = 0u;
        parser->digits = 0u;
    }
}

bool servo_command_active(const servo_command_t *parser)
{
    return parser != 0 && parser->digits != 0u;
}

bool servo_command_feed(servo_command_t *parser, uint8_t byte, uint16_t *pulse_us)
{
    uint16_t value;
    if (parser == 0 || pulse_us == 0) return false;
    if (byte == (uint8_t)'P') {
        parser->value = 0u;
        parser->digits = 1u;
        return false;
    }
    if (parser->digits == 0u) return false;
    if (byte < (uint8_t)'0' || byte > (uint8_t)'9') {
        parser->digits = 0u;
        return false;
    }
    parser->value = (uint16_t)(parser->value * 10u + (uint16_t)(byte - (uint8_t)'0'));
    if (++parser->digits <= 4u) return false;
    value = parser->value;
    parser->digits = 0u;
    if (value != 0u && (value < 500u || value > 1100u)) return false;
    *pulse_us = value;
    return true;
}

bool servo_output_permitted(uint16_t pulse_us,bool communication_online,bool machine_commissioned)
{
    return pulse_us != 0u && (communication_online || !machine_commissioned);
}

uint16_t servo_slew_step(uint16_t current_us,uint16_t target_us,uint16_t step_us)
{
    if(current_us<target_us){uint16_t distance=(uint16_t)(target_us-current_us);return distance<=step_us?target_us:(uint16_t)(current_us+step_us);}
    if(current_us>target_us){uint16_t distance=(uint16_t)(current_us-target_us);return distance<=step_us?target_us:(uint16_t)(current_us-step_us);}
    return current_us;
}
