#ifndef SORTER_VISION_PROTOCOL_H
#define SORTER_VISION_PROTOCOL_H

#include "protocol.h"

#define VISION_ITEM_PAYLOAD_SIZE 17u

typedef struct {
    uint32_t recognition_id;
    uint16_t class_id;
    int32_t x_um;
    int32_t y_um;
    uint16_t confidence_permille;
    uint8_t recognition_status;
} vision_item_t;

bool vision_decode_item(const protocol_frame_t *frame, vision_item_t *item);
bool vision_encode_item(const vision_item_t *item, uint16_t sequence,
                        protocol_frame_t *frame);

#endif
