#ifndef SORTER_SERVO_COMMAND_H
#define SORTER_SERVO_COMMAND_H
#include <stdbool.h>
#include <stdint.h>

#define SERVO_PULSE_MIN_US 500u
#define SERVO_PULSE_MAX_US 1100u

typedef struct {
    uint16_t value;
    uint8_t digits;
} servo_command_t;

void servo_command_init(servo_command_t *parser);
bool servo_command_feed(servo_command_t *parser, uint8_t byte, uint16_t *pulse_us);
bool servo_command_active(const servo_command_t *parser);
bool servo_output_permitted(uint16_t pulse_us,bool communication_online,bool machine_commissioned);
uint16_t servo_slew_step(uint16_t current_us,uint16_t target_us,uint16_t step_us);
#endif
