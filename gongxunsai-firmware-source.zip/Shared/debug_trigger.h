#ifndef SORTER_DEBUG_TRIGGER_H
#define SORTER_DEBUG_TRIGGER_H
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    uint32_t led_until_ms;
    bool armed;
    bool toggle_initialized;
    bool last_toggle;
} debug_trigger_t;

void debug_trigger_init(debug_trigger_t *trigger);
bool debug_trigger_feed(debug_trigger_t *trigger, uint8_t byte, uint32_t now_ms);
bool debug_trigger_led_active(debug_trigger_t *trigger, uint32_t now_ms);
bool debug_trigger_sync_toggle(debug_trigger_t *trigger, bool toggle, uint32_t now_ms);
#endif
