#ifndef SORTER_PROTOCOL_H
#define SORTER_PROTOCOL_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#define PROTOCOL_FRAME_SIZE 32u
#define PROTOCOL_PAYLOAD_SIZE 22u
#define PROTOCOL_VERSION 1u
#define PROTOCOL_STREAM_TIMEOUT_MS 100u

#define PROTO_IO_QUERY 0x10u
#define PROTO_IO_SAFE 0x11u
#define PROTO_IO_RESET 0x12u
#define PROTO_IO_SERVO 0x13u
#define PROTO_IO_STATUS 0x90u
#define PROTO_VISION_ITEM 0x20u
#define PROTO_APP_STATUS 0xA0u
#define PROTO_SORT_RESULT 0xA1u

/* High event bit is a state toggle. Each transition requests one MASTER LED pulse. */
#define IO_EVENT_DEBUG_LED_TOGGLE ((uint16_t)0x8000u)

typedef struct {
    uint8_t type;
    uint16_t sequence;
    uint8_t length;
    uint8_t flags;
    uint8_t payload[PROTOCOL_PAYLOAD_SIZE];
} protocol_frame_t;

typedef struct {
    uint8_t buffer[PROTOCOL_FRAME_SIZE];
    uint8_t used;
    uint32_t last_byte_ms;
    uint32_t crc_errors;
    uint32_t discarded;
    uint32_t timeouts;
} protocol_stream_t;

uint16_t protocol_crc16(const uint8_t *data, size_t length);
bool protocol_encode(const protocol_frame_t *frame,
                     uint8_t out[PROTOCOL_FRAME_SIZE]);
/* Failure leaves the output frame unchanged; canonical zero padding required. */
bool protocol_decode(const uint8_t in[PROTOCOL_FRAME_SIZE],
                     protocol_frame_t *frame);
uint16_t protocol_read_u16(const uint8_t *data);
uint32_t protocol_read_u32(const uint8_t *data);
void protocol_write_u16(uint8_t *data, uint16_t value);
void protocol_write_u32(uint8_t *data, uint32_t value);

/* Accept first sequence, then forward deltas 1..32767 modulo 65536. */
bool protocol_seq_accept(uint16_t sequence, uint16_t *last, bool *initialized);
void protocol_stream_init(protocol_stream_t *stream);
/* A frame is emitted only on the byte completing it. Caller owns sequence policy. */
bool protocol_stream_feed(protocol_stream_t *stream, uint8_t byte,
                          uint32_t now_ms, protocol_frame_t *frame);
void protocol_stream_expire(protocol_stream_t *stream, uint32_t now_ms);

#endif
