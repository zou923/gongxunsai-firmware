#include "debug_trigger.h"

void debug_trigger_init(debug_trigger_t *trigger)
{
    if (trigger != 0) {
        trigger->led_until_ms = 0u;
        trigger->armed = false;
        trigger->toggle_initialized = false;
        trigger->last_toggle = false;
    }
}

bool debug_trigger_sync_toggle(debug_trigger_t *trigger, bool toggle, uint32_t now_ms)
{
    if (trigger == 0) return false;
    if (!trigger->toggle_initialized) {
        trigger->toggle_initialized = true;
        trigger->last_toggle = toggle;
        return false;
    }
    if (trigger->last_toggle == toggle) return false;
    trigger->last_toggle = toggle;
    trigger->led_until_ms = now_ms + 1000u;
    trigger->armed = true;
    return true;
}

bool debug_trigger_feed(debug_trigger_t *trigger, uint8_t byte, uint32_t now_ms)
{
    if (trigger == 0 || byte != (uint8_t)'1') return false;
    trigger->led_until_ms = now_ms + 1000u;
    trigger->armed = true;
    return true;
}

bool debug_trigger_led_active(debug_trigger_t *trigger, uint32_t now_ms)
{
    if (trigger == 0 || !trigger->armed) return false;
    if ((int32_t)(now_ms - trigger->led_until_ms) >= 0) {
        trigger->armed = false;
        return false;
    }
    return true;
}
