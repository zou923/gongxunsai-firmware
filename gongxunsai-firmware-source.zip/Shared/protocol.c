#include "protocol.h"
#include <string.h>

uint16_t protocol_crc16(const uint8_t *data, size_t length)
{
    uint16_t crc = 0xFFFFu;
    size_t i;
    for (i = 0; i < length; ++i) {
        unsigned bit;
        crc ^= (uint16_t)((uint16_t)data[i] << 8);
        for (bit = 0; bit < 8; ++bit) {
            crc = (uint16_t)((crc & 0x8000u) != 0u
                            ? ((uint32_t)crc << 1) ^ 0x1021u
                            : (uint32_t)crc << 1);
        }
    }
    return crc;
}

uint16_t protocol_read_u16(const uint8_t *data)
{
    return (uint16_t)((uint16_t)data[0] | ((uint16_t)data[1] << 8));
}

uint32_t protocol_read_u32(const uint8_t *data)
{
    return (uint32_t)data[0] | ((uint32_t)data[1] << 8) |
           ((uint32_t)data[2] << 16) | ((uint32_t)data[3] << 24);
}

void protocol_write_u16(uint8_t *data, uint16_t value)
{
    data[0] = (uint8_t)value;
    data[1] = (uint8_t)(value >> 8);
}

void protocol_write_u32(uint8_t *data, uint32_t value)
{
    data[0] = (uint8_t)value;
    data[1] = (uint8_t)(value >> 8);
    data[2] = (uint8_t)(value >> 16);
    data[3] = (uint8_t)(value >> 24);
}

bool protocol_encode(const protocol_frame_t *frame,
                     uint8_t out[PROTOCOL_FRAME_SIZE])
{
    if (frame == NULL || out == NULL || frame->length > PROTOCOL_PAYLOAD_SIZE ||
        frame->flags != 0u) return false;
    memset(out, 0, PROTOCOL_FRAME_SIZE);
    out[0] = 0xA5;
    out[1] = 0x5A;
    out[2] = PROTOCOL_VERSION;
    out[3] = frame->type;
    protocol_write_u16(out + 4, frame->sequence);
    out[6] = frame->length;
    memcpy(out + 8, frame->payload, frame->length);
    protocol_write_u16(out + 30, protocol_crc16(out, 30));
    return true;
}

bool protocol_decode(const uint8_t in[PROTOCOL_FRAME_SIZE], protocol_frame_t *frame)
{
    protocol_frame_t decoded = {0};
    size_t i;
    if (in == NULL || frame == NULL || in[0] != 0xA5 || in[1] != 0x5A ||
        in[2] != PROTOCOL_VERSION || in[6] > PROTOCOL_PAYLOAD_SIZE ||
        in[7] != 0u || protocol_read_u16(in + 30) != protocol_crc16(in, 30)) {
        return false;
    }
    for (i = 8u + in[6]; i < 30u; ++i) {
        if (in[i] != 0u) return false;
    }
    decoded.type = in[3];
    decoded.sequence = protocol_read_u16(in + 4);
    decoded.length = in[6];
    memcpy(decoded.payload, in + 8, decoded.length);
    *frame = decoded;
    return true;
}

bool protocol_seq_accept(uint16_t sequence, uint16_t *last, bool *initialized)
{
    uint16_t delta;
    if (last == NULL || initialized == NULL) return false;
    if (*initialized) {
        delta = (uint16_t)(sequence - *last);
        if (delta == 0u || delta >= 0x8000u) return false;
    }
    *last = sequence;
    *initialized = true;
    return true;
}

void protocol_stream_init(protocol_stream_t *stream)
{
    if (stream != NULL) memset(stream, 0, sizeof(*stream));
}

static void stream_discard_first(protocol_stream_t *stream)
{
    --stream->used;
    ++stream->discarded;
    memmove(stream->buffer, stream->buffer + 1, stream->used);
}

void protocol_stream_expire(protocol_stream_t *stream, uint32_t now_ms)
{
    if (stream != NULL && stream->used != 0u &&
        (uint32_t)(now_ms - stream->last_byte_ms) >= PROTOCOL_STREAM_TIMEOUT_MS) {
        stream->discarded += stream->used;
        stream->used = 0;
        ++stream->timeouts;
    }
}

bool protocol_stream_feed(protocol_stream_t *stream, uint8_t byte,
                          uint32_t now_ms, protocol_frame_t *frame)
{
    if (stream == NULL || frame == NULL) return false;
    protocol_stream_expire(stream, now_ms);
    /* Every return leaves fewer than 32 bytes buffered. */
    stream->buffer[stream->used++] = byte;
    stream->last_byte_ms = now_ms;
    while (stream->used != 0u) {
        if (stream->buffer[0] != 0xA5) {
            stream_discard_first(stream);
            continue;
        }
        if (stream->used < 2u) return false;
        if (stream->buffer[1] != 0x5A) {
            stream_discard_first(stream);
            continue;
        }
        if (stream->used < PROTOCOL_FRAME_SIZE) return false;
        if (protocol_decode(stream->buffer, frame)) {
            stream->used = 0;
            return true;
        }
        if (protocol_read_u16(stream->buffer + 30) !=
            protocol_crc16(stream->buffer, 30)) ++stream->crc_errors;
        /* Retain embedded candidate starts instead of throwing away 32 bytes. */
        stream_discard_first(stream);
    }
    return false;
}
